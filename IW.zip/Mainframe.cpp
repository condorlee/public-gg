/*=============================================================================
 * Name			: MainFrame.cpp
 * Project		: IcyWeapon	
 * Function		: ��Ϸ��������Ϸ�����ʵ���ļ�
 * Abbreviation	:
 * Programmed	: Li Wenbin
 * Date			: 1999/09/20
******************************************************************************/

#include "stdafx.h"
#include "MainFrame.h"

/************************************* class CCmdIcon ************************/
//////////////////////////////////////////////////////////////////////////////
// message map
BEGIN_MESSAGE_MAP( CCmdIcon )
	MESSAGE_PROC( WM_KEYDOWN, OnKeyDown )
	MESSAGE_PROC( WM_KEYUP, OnKeyUp )
END_MESSAGE_MAP();

IMPLEMENT_VIEW( CCmdIcon ,CButton );

void CCmdIcon::OnKeyDown( WPARAM wParam, LPARAM lParam )
{	SetBtnState( PushDown );	}

void CCmdIcon::OnKeyUp( WPARAM wParam, LPARAM lParam )
{	
	if( GetState() & VS_DISABLE ) return ;
	if( !(GetBtnState()&PushDown) ) return;
	SetBtnState( PushDown, false );
	NotifyFather(  );			
}

void CCmdIcon::SetCmdIcon( SCmdIcon& cmdInfo )
{
	// �ָ�CmdIcon��Enable״̬
	EnableView( true );
	m_oCmdData = cmdInfo;
	SetButton( m_oCmdData.hIcon );
	EnableView( m_oCmdData.bEnable );
}

/******************************* class CMainFrame ****************************/
///////////////////////////////////////////////////////////////////////////////
// GVF Message Map 
BEGIN_MESSAGE_MAP( CMainFrame )
	// GVF Message
	MESSAGE_PROC( VM_CREATE, OnCreate )
	MESSAGE_PROC( VM_DESTROY, OnDestroy )
	MESSAGE_PROC( VM_QUIT, OnQuit )
	MESSAGE_PROC( VM_TIMER, OnTimer )
	MESSAGE_PROC( VM_NOTIFY, OnNotify )
	// ������Ϣ
	MESSAGE_PROC( WM_KEYDOWN, OnKeyDown )
	MESSAGE_PROC( WM_SYSKEYDOWN, OnKeyDown )
	MESSAGE_PROC( WM_KEYUP, OnKeyUp )
	MESSAGE_PROC( WM_SYSKEYUP, OnKeyUp )
	// �����Ϣ
	MESSAGE_PROC( WM_LBUTTONDOWN, OnLButtonDown )
	MESSAGE_PROC( WM_RBUTTONDOWN, OnRButtonDown )
	MESSAGE_PROC( WM_LBUTTONUP, OnLButtonUp )
	MESSAGE_PROC( WM_RBUTTONUP, OnRButtonUp )
	MESSAGE_PROC( WM_LBUTTONDBLCLK, OnLButtonDown )
	MESSAGE_PROC( WM_RBUTTONDBLCLK, OnRButtonDown )
END_MESSAGE_MAP(  );
// End Message Map
IMPLEMENT_VIEW( CMainFrame ,CFrame );


///////////////////////////////////////////////////////////////////////////////
// GVF Message Process
void CMainFrame::OnCreate( WPARAM wParam, LPARAM lParam )
{
	RECT rect;
	rect.top = rect.left = 0 ;
	rect.right = GetRect().right;
	rect.bottom = STATUSPANEL_HEIGHT-1;
	m_rcStatusPanel = rect;	// ״̬���ķ�Χ

	rect.top = rect.bottom +1;
	rect.bottom = GetRect().bottom - CONTROLPANEL_HEIGHT;
	m_rcWorldView = rect; // ��Ϸ�����λ��

	rect.top = rect.bottom+1;
	rect.bottom = GetRect().bottom;
	m_rcControlPanel = rect; // ���ư��λ��

	// ����ICON����,��������ȫ����Ϊ���ɼ�
	m_uVisibleIconCount = 0;
	for( UINT u = 0; u < _MAX_CMDICONS; u ++ )
	{
		GetApp()->CreateView( &m_oCmdIcons[u], NULL, &GetIconRect( u ), this );
		m_oCmdIcons[u].SetControl( ID_CMDICON_FIRST+u );
		m_oCmdIcons[u].SetPicSide( IwGetLocalID() );
		m_oCmdIcons[u].ShowView( false );
	}
	InvalidPaint(false);
	SetGameState( GS_TOMAINMENU );
}

void CMainFrame::OnDestroy( WPARAM wParam, LPARAM lParam )
{
	for( UINT u = 0; u < _MAX_CMDICONS; u ++ )
		GetApp()->DestroyView( &m_oCmdIcons[u] );
}

void CMainFrame::OnQuit( WPARAM wParam, LPARAM lParam )
{
	if( IsGameStart() )
	{
		GetSession()->EndGame();
		DestroyGameData( );
	}
}

void CMainFrame::OnNotify( WPARAM wParam, LPARAM lParam )
{
	CControl *pControl = GetControl(wParam);
	ASSERT( pControl );
	if( pControl->IsKindOf( GET_VIEWCLASS(CCmdIcon) ) )
	{
		// �����CCmdIcon������
		MSG msg = *GetCrntMsg();
		msg.message = VM_ICONCLK;
		msg.wParam = ((CCmdIcon *)pControl)->m_oCmdData.wParam;
		msg.pt = m_ptCrntPos;
		PutMsg( msg );
	}
}

///////////////////////////////////////////////////////////////////////////////
// Main Cycle
bool CMainFrame::MsgProc( MSG& msg ) // ������Ϣ�Ļ���, ��ÿһ��ѭ��ִֻ��һ����Ϣ
{
	// �����Ϸ���������
	if( IsGameStart() )
	{
		ASSERT( GetState() & VS_VALIDPAINT );
		// �Լ��̺������Ϣ���л���
		if( (GetGameState()&GS_MSGPROC) || 
			GetMessageType(msg.message) == VT_CONTROL )
			return CFrame::MsgProc(msg);
		PutMsg( msg ); // ������Ϣ����
		return false;
	}
	// ��Ϸû������,ֻ����ִ�п�����Ϣ
	if( GetMessageType( msg.message ) == VT_CONTROL )
		return CFrame::MsgProc( msg );
	return false;
}

void CMainFrame::WorldCmdProc( )
{
	ASSERT( IsGameStart() );
	ASSERT( GetGameState() & GS_WAITFORCMD );
	SetGameState( GS_WAITFORCMD, false );
	SPlayerCommand	playerCmd;
	int	id;

	while( GetSession()->GetPlayerCmd( playerCmd, id ) )
		IwGetPlayer( id )->CmdProc( playerCmd );
	IwGetWorld()->March( );	

	// �ж�Ҫ��������Ϸ
	if( GetGameState() & GS_WAITFORQUIT )
	{
		if( IwGetWorld()->GetTickCounter() >= m_dwQuitCount  
			+ 2*TICK_PER_SECOND )	
			EndGame();
	}
	else
	{	// �ж���û�б����
		if( !IwGetWorld()->PlayerAlive( IwGetLocalID() ) )
			GetSession()->OnDefeat();
		// �ж���û��ʤ��
		if( GetGameInfo()->nType == GI_MULTICOMPUTER )
		{
			if( IwGetDpNet()->GetPlayers() <= 1 )
				GetSession()->OnVictory();
		}
		else
		{
			bool bVictory = true;
			for( id = 0; id < int(GetGameInfo()->uPlayers); id ++ )
			{
				if( GetGameInfo()->btPlayerType[id] == PT_AI )
					if( IwGetWorld()->PlayerAlive( id ) )
						bVictory = false;
			}
			if( bVictory )
				GetSession()->OnVictory( );
		}
	}
}

void CMainFrame::OnTimer( WPARAM wParam, LPARAM lParam )
{
	if( GetGameState() & GS_TOMAINMENU )
	{ PopupMainMenu();	return;	}
	if( !IsGameStart() )	return;		// ��Ϸû������,�򷵻�
	
	SetGameState( GS_CYCLEBREAK, false ); // ���ѭ����ֹ��ֹλ
	if( GetGameState() & GS_WAITFORCMD ) 
	{
		if( GetSession()->IsCmdPkgFull() )
			WorldCmdProc( );
		else return ;	// û��ִ����һ��ѭ��������
	}
	if( GetGameState() & GS_CYCLEBREAK ) return;

	SPlayerCommand playerCmd;
	playerCmd.m_oUnitCmd.eType = CUnit::NullCmd;
	playerCmd.m_uDestCount = 0;

	if( GetApp()->GetActiveView() == this )
	{
		SetGameState( GS_MSGPROC );
		MSG msg; msg.message = WM_NULL;
		GetCursorPos( &m_ptCrntPos );	/* ȡ���Ĺ��λ�� */
		ScreenToView( m_ptCrntPos );
		while( GetMsg( msg ) )
		{	
			if( GetMessageType( msg.message ) != VT_CONTROL )	// ��Windows��Ϣ
			{
				m_ptCrntPos = msg.pt;
				ScreenToView( m_ptCrntPos );
			}
			MsgProc( msg );
			if( msg.message != WM_MOUSEMOVE )
				break;
		}
		if( GetGameState() & GS_CYCLEBREAK )	// ���ѡ���뿪��Ϸ,�����¿�ʼ,
			return;							// ����ǰ������ѭ��

		// ��������ͼ�������Ϸ�����ƫ��
		if( !m_bSelecting )
		{
			/* ����ڱ��ϣ��ƶ�����ͼ��ƫ���� */
			if( m_ptCrntPos.x == 0 )
				m_ptViewOffset.x -= TILE_WIDTH;	/* ����ƫ�� */
			else if( m_ptCrntPos.x == GetRect().right )
				m_ptViewOffset.x += TILE_WIDTH; /* ����ƫ�� */
			if( m_ptCrntPos.y == 0  )
				m_ptViewOffset.y -= TILE_HEIGHT;	/* ����ƫ�� */
			else if( m_ptCrntPos.y == GetRect().bottom )
				m_ptViewOffset.y += TILE_HEIGHT;	/* ����ƫ�� */
			ValidateOffsetPoint();
		}
		
		/* ���������״̬������ */
		m_oGameCursor.SetKind( CCursor::CommonCursor );
		if( GetMKState() & MK_LBUTTONDOWN )
		{
			if( PointInRect(  m_ptSelectedStart, m_rcWorldView ) )
			{
				if( m_bSelecting )
				{
					RECT rc;	BuildRect( rc, m_ptSelectedStart, m_ptCrntPos );
					ViewToWorld( rc );
					IwGetLocalPlayer()->OnSelect( GetMKState(), rc );
				}
				else
				{
					if( abs(m_ptSelectedStart.x-m_ptCrntPos.x) +
						abs(m_ptSelectedStart.y-m_ptCrntPos.y) > _MIN_SELRECTPERIMETER)
						BeginSelect( );
				}
			}
			else if( PointInRect( m_ptCrntPos, m_rcMiniMap ) )
			{
				POINT pt = m_ptCrntPos;		MiniMapToWorld( pt );
				pt.x -= GetRectWidth( m_rcWorldView )/2;
				pt.y -= GetRectHeight( m_rcWorldView )/2;
				m_ptViewOffset = pt;
				ValidateOffsetPoint( );
			}
		}
		
		/* ���������״̬û�б����� */
		else
		{
			if( msg.message == VM_ICONCLK )
				IwGetLocalPlayer()->MsgProc( msg, GetMKState(), playerCmd );
			else if( PointInRect(m_ptCrntPos,m_rcWorldView) ) // ����Ϸ�����е������
			{
				msg.pt = m_ptCrntPos;
				ViewToWorld( msg.pt );
				IwGetLocalPlayer()->MsgProc( msg, GetMKState(), playerCmd );
				m_oGameCursor.SetKind( IwGetLocalPlayer()->GetCrntCursor() );
			}
			else if( PointInRect( m_ptCrntPos, m_rcMiniMap ) ) // ��С��ͼ�ϵ������
			{
				//  ת������Ϸ���������
				POINT pt = m_ptCrntPos;
				pt.x -= m_rcMiniMap.left;
				pt.y -= m_rcMiniMap.top;
				if( pt.x <= 0 ) pt.x = 0;
				else if( pt.x >= IwGetWorld()->GetWidth() )
					pt.x = IwGetWorld()->GetWidth()-1;
				if( pt.y <= 0 ) pt.y = 0;
				else if( pt.y >= IwGetWorld()->GetHeight() )
					pt.y = IwGetWorld()->GetHeight()-1;

				pt.x *= IwGetWorld()->GetMiniMapRatio()*TILE_WIDTH;
				pt.y *= IwGetWorld()->GetMiniMapRatio()*TILE_HEIGHT;
				msg.pt = pt;
				IwGetLocalPlayer()->MsgProc( msg, GetMKState(), playerCmd );
				m_oGameCursor.SetKind( IwGetLocalPlayer()->GetCrntCursor() );
			}
		} // End LButton DOWN
		// ��ʼ��Ϣ����
		SetGameState( GS_MSGPROC, false );
		
		// Refresh Command Icon;
		SCmdIcon	oIcons[_MAX_CMDICONS];
		UINT		uCount;
		IwGetLocalPlayer()->GetCmdIcons( uCount, oIcons );
		for( UINT u = 0; u < uCount; u ++ )
		{
			// ���ò���ͬ��ICON
			if( memcmp(&m_oCmdIcons[u].m_oCmdData,
				&oIcons[u], sizeof(SCmdIcon)) != 0 )
				m_oCmdIcons[u].SetCmdIcon( oIcons[u] );
			m_oCmdIcons[u].ShowView( true );
		}
		// �رն����ICON
		oIcons[0].hIcon = INVALID_HPICTURE;
		for( u = uCount; u < m_uVisibleIconCount; u ++ )
		{
			m_oCmdIcons[u].ShowView( false );
			m_oCmdIcons[u].SetCmdIcon( oIcons[0] );
		}
		m_uVisibleIconCount = uCount;
		// Put Command And Wait
	} 
	// ������̨������
	else if( GetGameInfo()->nType == GI_SINGLECOMPUTER )
		return;
	else;
	int id = IwGetLocalID();
	GetSession()->PutPlayerCmd( playerCmd, id );
	// ��ʱ������AI��ҽ���ս�Ծ��ߣ�ִ�о��߽����Ԫ����
	for( id = 0; id < (int)(GetGameInfo()->uPlayers); id ++ )
		if( GetGameInfo()->btPlayerType[id] == PT_AI ){			
			// �޸��ߣ�	�
			// ���ڣ�	2000/03/03
			((CAIPlayer*)IwGetPlayer(id))->March(playerCmd);
			GetSession()->PutPlayerCmd( playerCmd, id );
		}
	// Display
	if( IwGetApp()->GetActiveView() == this )
	{
		GetApp()->SendGvfMsg( GetHView(), VM_PAINT );
		m_uHintElapse ++;
		m_uSessionMsgElapse ++;
		GetApp()->RefreshScreen( );
	}
	SetGameState( GS_WAITFORCMD );
};

void CMainFrame::InvalidPaint( bool bInvalid )
{
	CView::InvalidPaint( false );
}

void CMainFrame::OnDraw( )
{
	if( !IsGameStart() )	return; // ��Ϸ��û��ʼ,û��ʲô������ʾ��

	RECT rect;
	UINT u;
	IwGetWorld()->Display( m_ptViewOffset, m_rcWorldView );
	// ��ʾ״̬������
	ShowPic( StatusPanelBgUI, 0, GetRectCenterX(m_rcStatusPanel),
		GetRectCenterY(m_rcStatusPanel));
	// ��ʾ���ư屳��
	ShowPic( ControlPanelBgUI, 0, GetRectCenterX(m_rcControlPanel),
		GetRectCenterY(m_rcControlPanel));
	// ��ʾѡ�п�
	if( m_bSelecting )
	{
		BuildRect( rect, m_ptSelectedStart, m_ptCrntPos );
		IwGetMedia()->Rectangle( rect );
	}
	// ��ʾ��Ԫ��ʾ��Ϣ
	if( m_uHintElapse < _MAX_HINTELAPSE && m_szUnitHint[0] != '\x0' )
	{
		u = (GetRectWidth(m_rcWorldView)-strlen(m_szUnitHint)
			/2*SMALLFONT_SIZE)/2;
		IwGetMedia()->TextOut( u, m_rcWorldView.bottom-HINT_POSX-10, m_szUnitHint,
			RGB(255,255,0), CMedia::SmallFont );
	}
	
	// ��Ϸ�Ի���Ϣ
	if( m_uSessionMsgElapse < _MAX_HINTELAPSE && m_szSessionMsg[0] != '\x0' )
	{
		u = (GetRectWidth(m_rcWorldView)-strlen(m_szSessionMsg)
			/2*BIGFONT_SIZE)/2;
		IwGetMedia()->TextOut( u, m_rcWorldView.top+100, 
			m_szSessionMsg, RGB(255,255,255), CMedia::BigFont );
	}

	// ��ʾС��ͼ
	ShowPic( MiniMapUI, 0, m_rcMiniMap.left+GetRectWidth(m_rcMiniMap)/2,
		m_rcMiniMap.top+GetRectHeight(m_rcMiniMap)/2 );
	
	// ��ʾʱ��
	rect = m_rcWorldView;
	ViewToWorld( rect );
	WorldToMiniMap( rect );
	IwGetMedia()->Rectangle(rect);
	char	szTime[100];
	u = IwGetWorld()->GetTickCounter()/TICK_PER_SECOND;
	sprintf( szTime, "%02d:%02d:%02d", (u/3600)%24,(u/60)%60,u%60);
	IwGetMedia()->TextOut( m_rcWorldView.right-60,m_rcWorldView.top+5, szTime );

	sprintf( szTime, "%d", IwGetWorld()->GetPlayerMoney( IwGetLocalID() ) );
	IwGetMedia()->TextOut( m_rcStatusPanel.left+30, m_rcStatusPanel.top+5,
		szTime, RGB(255,255,0) );

	// ��ʾ�Ӵ���
	for( u = 0; u < GetChildCount(); u ++ )
		GetApp()->SendGvfMsg( GetChild(u), VM_PAINT );

	// ��ʾCommand Icon����ʾ
	u = GetIconFromPos( m_ptCrntPos );
	if( u != UINT_MAX )
	{
		rect = GetIconRect( u );
		IwGetMedia()->TextOut( m_rcWorldView.left+HINT_POSX, 
			m_rcWorldView.bottom-HINT_POSX-10,	m_oCmdIcons[u].m_oCmdData.sComment );
	}
	// ��ʾ��Ԫ״̬��Ϣ
	SUnitInfo unitInfo;
	if( IwGetLocalPlayer()->GetUnitInfo( unitInfo ) )
	{
		rect = m_rcControlPanel;
		rect.left += 7; rect.right = rect.left + 123;
		rect.top += 7;	rect.bottom = rect.top + 111;
		// ��ʾ����
		ShowPic( UnitInfoBgUI, 0,(rect.left+rect.right)/2, 
			(rect.top+rect.bottom)/2 );
		// ��ʾ���������
		IwGetMedia()->TextOut( rect.left+10, rect.top+10, unitInfo.sName );
		// ��ʾ����ͼ��
		ShowPic( unitInfo.hIcon, 0, rect.left+25, rect.top+55, 
			IwGetLocalPlayer()->GetSelectUnitSide() );
		// ��ʾ״̬����
		if( unitInfo.sProduceName )
		{
			IwGetMedia()->TextOut( rect.left + 60, rect.top + 40,
				"��������..." );
			IwGetMedia()->TextOut( rect.left + 60, rect.top + 60,
				unitInfo.sProduceName );
		}
		else
			IwGetMedia()->TextOut( rect.left + 60, rect.top + 40,
				"" );

		if( unitInfo.hProducePic != INVALID_HPICTURE )
			ShowPic( unitInfo.hProducePic, unitInfo.nProducePicOrder,
				rect.left + 62, rect.bottom-10 );

	}
	// ShowPic( CursorsUI, 1, m_ptCrntPos.x, m_ptCrntPos.y );
	m_oGameCursor.Display();
}

///////////////////////////////////////////////////////////////////////////////
// Keyboard Message Process Function
void CMainFrame::OnKeyDown( WPARAM wParam, LPARAM lParam )
{
	ASSERT( IsGameStart() );
	// ������ظ��İ������ٲ���Ӧ
	if( lParam & (1<<30) ) return;
	switch( wParam )
	{
	case VK_MENU:	// �����
		SetMKState( MK_ALTDOWN );
		break;
	case VK_SHIFT:
		SetMKState( MK_SHIFTDOWN );
		break;
	case VK_CONTROL:
		SetMKState( MK_CTRLDOWN );
		break;
	case VK_ESCAPE:	
		PopupGameMenu(); 
		break;
	// �������׼�
	case CHEAT_NO_FOG_KEY:
	case CHEAT_ADD_MONEY_KEY:
		/* �����������£�����Ϊ���׼�����������default���� */
		if ( (GetMKState() & CHEAT_SPEC_KEY) == CHEAT_SPEC_KEY)
		{
			if (wParam == CHEAT_NO_FOG_KEY)
				CWorld::CTileVisibleState::NoFog();
			if (wParam == CHEAT_ADD_MONEY_KEY)
				CWorld::GivePlayerMoney(CWorld::GetLocalPlayerId(), CHEAT_MONEY);
			break;
		}
	default:
		{
			if( IwGetLocalPlayer() -> OnKeyDown(GetMKState(), wParam) )
				return;
			if( GetMKState() & (MK_ALTDOWN|MK_CTRLDOWN) )
				return;
			for( UINT u = 0; u < m_uVisibleIconCount; u ++ )
				if( (WPARAM)(m_oCmdIcons[u].m_oCmdData.byHotkey) == wParam )
					{
						GetApp()->SendGvfMsg( m_oCmdIcons[u].GetHView(), *GetCrntMsg() );
						break;
					}
		} // End default
	}// end switch
}

void CMainFrame::OnKeyUp( WPARAM wParam, LPARAM lParam )
{
	ASSERT( IsGameStart() );
	switch( wParam )
	{
	case VK_MENU:	// �����
		SetMKState( MK_ALTDOWN, false );
		break;
	case VK_SHIFT:
		SetMKState( MK_SHIFTDOWN, false );
		break;
	case VK_CONTROL:
		SetMKState( MK_CTRLDOWN, false );
		break;
	default:
		{
			for( UINT u = 0; u < m_uVisibleIconCount; u ++ )
				if( (WPARAM)(m_oCmdIcons[u].m_oCmdData.byHotkey) == wParam )
				{
					GetApp()->SendGvfMsg( m_oCmdIcons[u].GetHView(), *GetCrntMsg() );
					break;
				}
		}// End default;
	}// end switch;
}

///////////////////////////////////////////////////////////////////////////////
// Mouse Message Process Function
void CMainFrame::OnLButtonDown( WPARAM wParam, LPARAM lParam )
{
	ASSERT( IsGameStart() );
	SetMKState( MK_LBUTTONDOWN );
	GetApp()->SetCaptureView( GetHView(), true );
	if( PointInRect( m_ptCrntPos, m_rcWorldView ) )
	{
		m_ptSelectedStart = m_ptCrntPos;
		RECT rc; BuildRect( rc, m_ptSelectedStart, m_ptCrntPos );
		ViewToWorld( rc );
		IwGetLocalPlayer()->OnSelect( GetMKState(), rc );
		ClipCursor( &m_rcWorldView );
	}
}

void CMainFrame::OnRButtonDown( WPARAM wParam, LPARAM lParam )
{
	ASSERT( IsGameStart() );
	SetMKState( MK_RBUTTONDOWN );
}

void CMainFrame::OnLButtonUp( WPARAM wParam, LPARAM lParam )
{
	ASSERT( IsGameStart() );
	SetMKState( MK_LBUTTONDOWN,false );
	GetApp()->SetCaptureView( GetHView(), false );
	if( PointInRect( m_ptSelectedStart, m_rcWorldView ) )
	{
		if( m_bSelecting  )
			EndSelect();

		RECT rc; BuildRect( rc, m_ptSelectedStart, m_ptCrntPos );
		ViewToWorld( rc );
		IwGetLocalPlayer()->OnSelect( GetMKState(), rc );
		m_ptSelectedStart.x = m_rcStatusPanel.left;
		m_ptSelectedStart.y = m_rcStatusPanel.top;
		ClipCursor( NULL );
	}
}

void CMainFrame::OnRButtonUp( WPARAM wParam, LPARAM lParam )
{
	ASSERT( IsGameStart() );
	SetMKState( MK_RBUTTONDOWN,false );
}

void CMainFrame::BeginSelect( )
{
	m_bSelecting = true;
	// ClipCursor( &m_rcWorldView );
	// ShowCursor( false );;
	m_oGameCursor.SetVisible( false );
}

void CMainFrame::EndSelect( )
{
	ASSERT( m_bSelecting == true );
	// ClipCursor( NULL );
	// ShowCursor( true );
	m_oGameCursor.SetVisible( true );
	m_bSelecting = false;
}

///////////////////////////////////////////////////////////////////////////////
// MainFrame Game Operations
GVFID CMainFrame::PopupMainMenu()
{
	SetGameState( GS_TOMAINMENU, false );
	// Pop up the main menu
	RECT rect;
	rect = GetRect( );
	GVFID id;
	bool	bEnd = false;
	CMainMenu mainMenu;

	while( !bEnd )
	{
		GetApp()->CreateView( &mainMenu, NULL, &rect, NULL ) ;
		id = mainMenu.DoModal( GetHView() );
		GetApp()->DestroyView( &mainMenu );
		switch( id )
		{
		case ID_CANCEL:
		case ID_EXITTOSYSTEM:
			CloseView( );
			bEnd = true; break;

		case ID_MULTIPLAYER:
		case ID_SINGLEPLAYER:
			StartGame( id );
			bEnd = true; break;

		default:
			break;
		}
	}
	return id;
}

GVFID CMainFrame::PopupGameMenu()
{
	// Pop up the main menu
	RECT rect; SIZE sz;
	IwGetMedia()->GetPicSize( GameMenuBgUI, 0, (int &)sz.cx, (int &)sz.cy );
	rect = GetCenterRect( sz );

	CGameMenu gameMenu;
	GetApp()->CreateView( &gameMenu,NULL, &rect, NULL );
	if( GetGameInfo()->nType == GI_MULTICOMPUTER )
	{
		CButton *pButton = ((CButton *)( gameMenu.GetControl( ID_RESTARTGAME )) );
		ASSERT( pButton );
		pButton->EnableView( false );
	}

	// Pause the Game
	ShowCursor( true );
	// m_oGameSession.Pause( true );
	GVFID id = gameMenu.DoModal( GetHView() );
	GetApp()->DestroyView( &gameMenu );
	// m_oGameSession.Pause( false );
	ShowCursor( false );

	switch( id )
	{
	case ID_QUITGAME:
		EndGame();
		break;
	case ID_RESTARTGAME:
		DestroyGameData();
		InitGameData();
		break;
	default:
		break;
	}
	SetGameState( GS_CYCLEBREAK );
	return id;
}

void CMainFrame::StartGame( GVFID id )
{
	ASSERT( !IsGameStart() );
	
	if( !GetSession()->BeginGame( id ) )
	{ 
		SetGameState( GS_TOMAINMENU );
		return;
	}

	InitGameData();
	TRACE( "Init Game Data Successfully!" );
	InvalidPaint( false );
	startlt( );
}

void CMainFrame::InitGameData( )
{
	for( UINT u = 0; u < GetGameInfo()->uPlayers; u ++ )
		IwGetApp()->CreatePlayer( GetGameInfo()->btPlayerType[u], u );

	// ��ʼ����Ϸ����
	GetGameInfo()->idLocalPlayer = IwGetLocalID();
	IwGetWorld()->Init( *GetGameInfo()  );
	SetCenterTile( IwGetLocalPlayer()->GetNextTown( ) );
	
	// ����script
	CEpisode::RunScript(CEpisode::DefaultScript);

	// ����С��ͼ�ķ�Χ
	RECT rect = m_rcControlPanel;
	rect.left = rect.right -_MAX_MINIMAP_WIDTH+1;

	int x,y;
	x = IwGetWorld()->GetWidth()/IwGetWorld()->GetMiniMapRatio();
	y = IwGetWorld()->GetHeight()/IwGetWorld()->GetMiniMapRatio();
	m_rcMiniMap.left = rect.left + ( _MAX_MINIMAP_WIDTH - x )/2;
	m_rcMiniMap.top = rect.top + ( _MAX_MINIMAP_HEIGHT - y )/2;
	m_rcMiniMap.right = rect.left + ( _MAX_MINIMAP_WIDTH + x )/2;
	m_rcMiniMap.bottom = rect.top + ( _MAX_MINIMAP_HEIGHT + y )/2;

	// ��ʼ����Ϸ��������
	// m_ptViewOffset.x = m_ptViewOffset.y = 0;
	for( u = 0; u < _MAX_CMDICONS; u ++ )
		m_oCmdIcons[u].SetPicSide( IwGetLocalID() );

	strcpy( m_szUnitHint, "");
	strcpy( m_szSessionMsg, "");
	m_uHintElapse = 0;
	m_uSessionMsgElapse = 0;

	m_ptSelectedStart.y = m_rcStatusPanel.top;
	m_ptSelectedStart.x = m_rcStatusPanel.left;
	m_dwMKState = 0;
	m_bSelecting = false;
	SetGameState( GS_START );
	ShowCursor( false );
	m_oGameCursor.SetKind( CCursor::CommonCursor );
	m_oGameCursor.SetVisible( true );
}


void CMainFrame::DestroyGameData( )
{
	// ȡ����Ϸ����ʱ���趨
	if( m_bSelecting )
		EndSelect();
	GetApp()->SetCaptureView( GetHView(), false );

	// �ͷ���Ϸ���еĶ��������
	for( UINT u = 0; u < GetGameInfo()->uPlayers; u ++ )
		IwGetApp()->DestroyPlayer( (int)u );

	// �趨��Ϸ��״̬
	m_dwQuitCount = -1;
	SetGameState( GS_START|GS_WAITFORCMD|GS_WAITFORQUIT, false );
	SetGameState( GS_CYCLEBREAK );
	m_oGameCursor.SetVisible( false );
	ShowCursor( true );
}



void CMainFrame::EndGame()
{
	ASSERT( IsGameStart() );
	GetSession()->EndGame( );
	DestroyGameData();
	SetGameState( GS_START, false );
	SetGameState( GS_TOMAINMENU );
}

///////////////////////////////////////////////////////////////////////////////
// Mainframe Attributes 
WORD CMainFrame::GetCenterTile( )
{
	int Width = m_ptViewOffset.x + (GetRectWidth( m_rcWorldView ))/2;
	int Height = m_ptViewOffset.y + (GetRectHeight( m_rcWorldView))/2;
	Width /= TILE_WIDTH;
	Height /= TILE_HEIGHT;
	return ( WORD_CO( Width, Height ) );
}

void CMainFrame::SetCenterTile( WORD wTile )
{
	m_ptViewOffset.x = X_CO( wTile ) * TILE_WIDTH;
	m_ptViewOffset.y = Y_CO( wTile ) * TILE_HEIGHT;
	m_ptViewOffset.x -= GetRectWidth( m_rcWorldView )/2;
	m_ptViewOffset.y -= GetRectHeight( m_rcWorldView )/2;
	ValidateOffsetPoint( );
}

void CMainFrame::UnitHint( LPSTR lpszHint )
{
	ASSERT( strlen(lpszHint) < _MAX_HINTLENGTH );
	strcpy( m_szUnitHint, lpszHint );
	m_uHintElapse = 0;
	return;
}

// Command Icon�Ĳ��ֲο�����
static const	RECT	g_rcTopIcon =	{ 149,7,199, 57 };
static const	RECT	g_rcBottomIcon ={ 149,72,199,122 };

RECT CMainFrame::GetIconRect( UINT uNum )
{
	RECT	rcRet;
	if( uNum  < _MAX_CMDICONS/ 2 )
		rcRet = g_rcTopIcon;
	else
		rcRet = g_rcBottomIcon, uNum -= _MAX_CMDICONS/2;
	OffsetRect( &rcRet, m_rcControlPanel.left+uNum*57, m_rcControlPanel.top );
	return rcRet;
}

UINT CMainFrame::GetIconFromPos( POINT pt )
{
	ASSERT( IsGameStart() );
	ViewToScreen( pt );
	HVIEW hView = GetChildFromPos( pt );
	if( hView != INVALID_HVIEW )
		for( UINT u = 0; u < m_uVisibleIconCount; u++ )
			if( m_oCmdIcons[u].GetHView() == hView )
				return u;

	return UINT_MAX;
}

///////////////////////////////////////////////////////////////////////////////
// ��Ϣ��������غ���
bool CMainFrame::GetMsg( MSG& msg )
{
	if( !IsQueueEmpty() )
	{
		msg = m_aMsgQueue[m_uQueueHead];
		NextPos( m_uQueueHead );
		return true;
	}
	return false;
}

bool CMainFrame::PutMsg( MSG& msg )
{
	if( !IsQueueFull() )
	{
		m_aMsgQueue[m_uQueueTail] = msg;
		NextPos( m_uQueueTail );
		return true;
	}
	return false;
}

///////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
CMainFrame::CMainFrame()	
{ 
	m_dwGameState = GS_DEFAULT;
	m_bSelecting = false;

	// ��Ϣ����������
	EmptyMsgQueue();
}

CMainFrame::~CMainFrame()
{ 
}

/***************************** class CMainMenu *******************************/
BEGIN_MESSAGE_MAP( CMainMenu )
	MESSAGE_PROC(VM_CREATE,OnCreate)
END_MESSAGE_MAP(  );

BEGIN_DIALOG( CMainMenu )
	DIALOG_ITEM( ID_SINGLEPLAYER, CButton, 300,150,556,198 )
	DIALOG_ITEM( ID_MULTIPLAYER, CButton, 300,270,556,318 )
	DIALOG_ITEM( ID_EXITTOSYSTEM, CButton, 300,390,556,438 )
END_DIALOG();

IMPLEMENT_DIALOG( CMainMenu, CDialog );


void CMainMenu::EndDialog( GVFID id )
{
	if( id != ID_CANCEL && id != ID_OK )
		CDialog::EndDialog( id );
}


void CMainMenu::OnCreate( WPARAM wParam, LPARAM lParam )
{
	CDialog::OnCreate( wParam, lParam );
	CControl *pControl = GetControl( ID_SINGLEPLAYER );
	((CButton *)(pControl))->SetButton( SinglePlayerUI );
	pControl = GetControl( ID_MULTIPLAYER );
	((CButton *)(pControl))->SetButton( MultiPlayerUI );
	pControl = GetControl( ID_EXITTOSYSTEM );
	((CButton *)(pControl))->SetButton( ExitToSystemUI );
	SetBackPic( MainMenuBgUI, 0 );
}

/***************************** class CGameMenu *******************************/
BEGIN_MESSAGE_MAP( CGameMenu )
	MESSAGE_PROC(VM_CREATE,OnCreate)
END_MESSAGE_MAP(  );

BEGIN_DIALOG( CGameMenu )
	DIALOG_ITEM( ID_QUITGAME, CButton, 55,50,255,120 )
	DIALOG_ITEM( ID_RESTARTGAME, CButton, 55,170,255,240 )
	DIALOG_ITEM( ID_RETURN, CButton, 55,290,255,360 )
END_DIALOG();

IMPLEMENT_DIALOG( CGameMenu, CDialog );

static char *g_szGameButtonText[] = {
	"�˳���Ϸ",
	"���¿�ʼ",
	"������Ϸ"						};

void CGameMenu::OnCreate( WPARAM wParam, LPARAM lParam )
{
	CDialog::OnCreate( wParam, lParam );
	CButton *pButton = NULL;
	for( UINT u = 0; u < GetChildCount(); u ++ )
	{
		pButton = (CButton *)(GetApp()->GetView(GetChild(u)));
		pButton->SetButton( ButtonBgUI, g_szGameButtonText[u] );
	}
	SetBackPic( GameMenuBgUI );
}
