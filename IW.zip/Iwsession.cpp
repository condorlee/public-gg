/*=============================================================================
 * Name			: NetSession.h
 * Project		: IcyWeapon
 * Function		: ��Ϸ��������ͻ���֮��Ի���������ʵ���ļ�
 * Abbreviation	: 
 * Programmed	: Li Wenbin
 * Date			: 1999/11/03
******************************************************************************/
#include "stdafx.h"
#include "IwSession.h"
#include "MainFrame.h"

/***************************** class CIwSession *****************************/
bool CIwSession::BeginGame( GVFID idType )
{	
	
	if( idType == ID_MULTIPLAYER )
	{
		GetGameInfo()->nType = GI_MULTICOMPUTER;
		if( IwGetDpNet()->GetDpState() == DPS_NETINVALID )
			return false;
		RECT rect = IwGetMainFrame()->GetRect();
		CSessionDlg sessionDlg;
		GetApp()->CreateView( &sessionDlg, NULL, &rect );
		GVFID id = sessionDlg.DoModal( );
		GetApp()->DestroyView( &sessionDlg );
		if( id == ID_CANCEL )
			return false;
		else if( id == ID_CREATESESSION )
			return CreateSession( );
		else if( id >= ID_GAMESESSION0 && id <= ID_GAMESESSION9 )
			return JoinSession( id-ID_GAMESESSION0 );
		else { ASSERT(false); return false; };
	}
	else if( idType == ID_SINGLEPLAYER )
	{
		GetGameInfo()->uRandSeed = timeGetTime();
		GetGameInfo()->nType = GI_SINGLECOMPUTER;
		GetGameInfo()->uPlayers = 2;
		GetGameInfo()->btPlayerType[0] = PT_HUMAN;
		GetGameInfo()->btPlayerType[1] = PT_AI;
		// ��ʼ��Session��
		InitCmdPkg( );
		return true;
	}
	else ASSERT( false );
	return false;
}

void CIwSession::EndGame( )
{
	if( GetGameInfo()->nType == GI_MULTICOMPUTER )
	{
		IwGetDpNet()->LeaveSession();
	}

	SetISState( NS_GAMESTART,false );
	SetISState( NS_GAMEREADY, false );
}

void CIwSession::OnDefeat( )
{
	IwGetMedia()->PlaySound( GameOverSound );
	IwGetMainFrame()->SetQuit( );
	IwGetMainFrame()->PutGameMsg( 
		"�治��,�㱻�����!" );
	if( GetGameInfo()->nType == GI_MULTICOMPUTER )
		SendNetMsg( "������ˣ�" );
}

void CIwSession::OnVictory( )
{
	IwGetMedia()->PlaySound( GameOverSound );
	IwGetMainFrame()->SetQuit();
	IwGetMainFrame()->PutGameMsg(
		"��ʤ���ˣ�" );
}

bool CIwSession::CreateSession( )
{
	CGameConfigDlg ConfigDlg;
	ConfigDlg.m_pSession = this;
	// Create Session On Network
	IwGetDpNet()->CreateSession();	
	// Create Config Dialog
	GetApp()->CreateView( &ConfigDlg,NULL );	
	GVFID id = ConfigDlg.DoModal( );
	GetApp()->DestroyView( &ConfigDlg );

	if( id == ID_CANCEL )	
	{
		IwGetDpNet()->LeaveSession( );
		return false;
	}
	IwGetDpNet()->DisableJoin( );
	
	UINT u;
	GetGameInfo()->uRandSeed = timeGetTime();
	GetGameInfo()->uPlayers = IwGetDpNet()->GetPlayers();
	ASSERT( GetGameInfo()->uPlayers > 1 );
	for( u = 0; u < GetGameInfo()->uPlayers; u ++ )
		GetGameInfo()->btPlayerType[u] = PT_HUMAN;

	GetSelfBuffer()->m_dwType = MAKELONG( ST_GAMEINFO,
		SF_NULL );
	GetSelfBuffer()->m_dwSize = sizeof( SSessionPkg );
	GetSelfBuffer()->m_oGameInfo = *(GetGameInfo());
	Broadcast( );

	// ��ʼ��Session��
	InitCmdPkg( );
	// ASSERT( m_dpNet.IsHost() );
	TRACE("I am a Host!" );
	return true;
}

bool CIwSession::JoinSession(UINT  index )
{
	CGameConfigDlg ConfigDlg;
	ConfigDlg.m_pSession = this;
	GetApp()->GetDpNet( )->JoinSession( index );
	GetApp()->CreateView( &ConfigDlg,NULL );
	GVFID id = ConfigDlg.DoModal( );
	GetApp()->DestroyView( &ConfigDlg );

	if( id == ID_CANCEL )	
	{
		IwGetDpNet()->LeaveSession( );
		SetISState( NS_GAMEREADY, false );
		return false;
	}

	// ��ʼ��Session��
	InitCmdPkg( );
	return true;
}

void CIwSession::OnReceive( CDpInterface *pDpNet, UINT uMsgCount )
{
	ASSERT( uMsgCount && pDpNet );
	SSessionPkg *pPkg = NULL;
	for( UINT u =0; u < uMsgCount; u ++ )
	{
		if( pDpNet->Receive( (LPDpDataPkg &)pPkg ) )
		{
			if( LOWORD(pPkg->m_dwType) == ST_GAMEINFO )
			{
				m_oGameInfo = pPkg->m_oGameInfo;
				SetISState( NS_GAMEREADY );
			}
			else if( LOWORD( pPkg->m_dwType ) == ST_COMMAND )
			{
				UINT uNum = m_uCrntBufferNum;
				if( m_lpPkgBuffer[uNum][pPkg->m_idBuilder]->m_dwType 
					!= MAKELONG(ST_NULL,SF_NULL) )
				{
					uNum = GetNextBuffer();
					ASSERT( m_lpPkgBuffer[uNum][pPkg->m_idBuilder]->m_dwType 
						== MAKELONG(ST_NULL,SF_NULL) );
				}
				CopyMemory( m_lpPkgBuffer[uNum][pPkg->m_idBuilder],
					pPkg, pPkg->m_dwSize );
				m_uCmdPkgCount ++;
			}
			else if ( LOWORD( pPkg->m_dwType ) == ST_MESSAGE )
			{
				IwGetMainFrame()->PutGameMsg( 
					(char *)( pPkg->m_dwExData ) );
			}
			else ASSERT( false );
		}
		else ASSERT( false );
	}	
}


void CIwSession::SendNetMsg( char *pMsg )
{
	// ��һ�����еĻ�����.
	SSessionPkg *pPkg = GetFreeBuffer();
	pPkg->m_dwType = MAKELONG( ST_MESSAGE, SF_GAMEMSG );
	pPkg->m_idBuilder = IwGetLocalID();
	// ����������,
	strcpy( (char*)(pPkg->m_dwExData), IwGetDpNet()->
		GetPlayerName( IwGetLocalID() ) );
	strcat( (char*)(pPkg->m_dwExData), "��" );
	strcat( (char*)(pPkg->m_dwExData), pMsg );
	
	pPkg->m_dwSize = strlen( (char*) (pPkg->m_dwExData) )
		+sizeof( SSessionPkg );
	// ��������
	IwGetDpNet()->Broadcast( (SDpDataPkg *)pPkg );
	// �ÿջ�����
	pPkg->m_dwType = MAKELONG( ST_NULL, SF_NULL );
}


bool CIwSession::PutPlayerCmd(  SPlayerCommand& playerCmd, int& id )
{
	// �Զ�����Player's Command
	if( playerCmd.m_oUnitCmd.eType == CUnit::NullCmd )
		playerCmd.m_uDestCount = 0;
	ASSERT( m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwType == 
		MAKELONG( ST_NULL, SF_NULL ) );

	m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwType = MAKELONG( ST_COMMAND,
		SF_NULL );
	m_lpPkgBuffer[m_uCrntBufferNum][id]->m_idBuilder = id;
	m_lpPkgBuffer[m_uCrntBufferNum][id]->m_oCmdPkg.m_oUnitCmd = 
		playerCmd.m_oUnitCmd;
	m_lpPkgBuffer[m_uCrntBufferNum][id]->m_oCmdPkg.m_dwUnits = 
		playerCmd.m_uDestCount;
	for( UINT u = 0; u < playerCmd.m_uDestCount; u ++ )
		m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwExData[u] = 
			(DWORD)( playerCmd.m_hDestUnits[u] );

	m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwSize = sizeof( SSessionPkg ) 
		+ sizeof(HUNIT)*playerCmd.m_uDestCount;
	if( GetGameInfo()->nType == GI_MULTICOMPUTER )
		Broadcast();

	m_uCmdPkgCount ++;
	return true;
}

bool CIwSession::GetPlayerCmd( SPlayerCommand& playerCmd, int& id )
{
	// ���ҵ�ǰ����û�п��õ��������ݰ�
	for( id = 0; id < _MAX_PLAYERS; id ++ )
		if( m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwType !=
			MAKELONG( ST_NULL, SF_NULL ) )
		{
			ASSERT( LOWORD(m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwType) == ST_COMMAND );
			playerCmd.m_oUnitCmd = 
				m_lpPkgBuffer[m_uCrntBufferNum][id]->m_oCmdPkg.m_oUnitCmd;
			playerCmd.m_uDestCount = 
				m_lpPkgBuffer[m_uCrntBufferNum][id]->m_oCmdPkg.m_dwUnits;
			for( UINT u = 0; u < playerCmd.m_uDestCount; u ++ )
				playerCmd.m_hDestUnits[u] = 
				(HUNIT)(m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwExData[u]);
			m_lpPkgBuffer[m_uCrntBufferNum][id]->m_dwType = MAKELONG( ST_NULL, SF_NULL );
			m_uCmdPkgCount --;
			return true;
		}
	// û�����ݰ����л�������
	m_uCrntBufferNum = GetNextBuffer();
	return false;
}

///////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
CIwSession::CIwSession()
{
	m_dwISState = NS_DEFAULT;
	for( UINT u0 = 0; u0 < 2; u0 ++ )
		for( UINT u1 = 0; u1 < _MAX_PLAYERS; u1 ++ )
		{
			m_lpPkgBuffer[u0][u1] = (SSessionPkg* )GlobalAllocPtr( GHND,
				sizeof(SSessionPkg) + MAX_EXDATASIZE );
			if( m_lpPkgBuffer[u0][u1] == NULL )
				throw EXCEPTION( InsufficientMemory );
		}
	m_uCmdPkgCount = 0;
}

CIwSession::~CIwSession()
{
	for( UINT u0 = 0; u0 < 2; u0 ++ )
		for( UINT u1 = 0; u1 < _MAX_PLAYERS; u1 ++ )
		{
			GlobalFreePtr(m_lpPkgBuffer[u0][u1]);
			m_lpPkgBuffer[u0][u1] = NULL;
		}
}

/***************************** class CSessionDlg *****************************/
BEGIN_MESSAGE_MAP( CSessionDlg )
	MESSAGE_PROC(VM_CREATE,OnCreate)
END_MESSAGE_MAP(  );

BEGIN_DIALOG( CSessionDlg )
	DIALOG_ITEM( ID_GAMESESSION0, CButton, 125,50, 325,100 )
	DIALOG_ITEM( ID_GAMESESSION1, CButton, 125,130,325,180 )
	DIALOG_ITEM( ID_GAMESESSION2, CButton, 125,210,325,260 )
	DIALOG_ITEM( ID_GAMESESSION3, CButton, 125,290,325,340 )
	DIALOG_ITEM( ID_GAMESESSION4, CButton, 125,370,325,420 )
	DIALOG_ITEM( ID_GAMESESSION5, CButton, 400,50, 600,100 )
	DIALOG_ITEM( ID_GAMESESSION6, CButton, 400,130,600,180 )
	DIALOG_ITEM( ID_GAMESESSION7, CButton, 400,210,600,260 )
	DIALOG_ITEM( ID_GAMESESSION8, CButton, 400,290,600,340 )
	DIALOG_ITEM( ID_GAMESESSION9, CButton, 400,370,600,420 )

	DIALOG_ITEM( ID_REFRESHSESSION, CButton, 50,500,250,550 )
	DIALOG_ITEM( ID_CREATESESSION,	CButton, 300,500,500,550 )
	DIALOG_ITEM( ID_CANCEL,			CButton, 550,500,750,550 )
END_DIALOG();

IMPLEMENT_DIALOG( CSessionDlg, CDialog );

static char *g_szSessionButtonText[] = {
	"Session0",
	"Session1",
	"Session2",
	"Session3",
	"Session4",
	"Session5",
	"Session6",
	"Session7",
	"Session8",
	"Session9",

	"ˢ����Ϸ",
	"������Ϸ",
	"���ز˵�",						};

void CSessionDlg::OnCreate( WPARAM wParam, LPARAM lParam )
{
	CDialog::OnCreate( wParam, lParam );
	CButton *pButton = NULL;
	for( UINT u = 0; u < GetChildCount(); u ++ )
	{
		pButton = (CButton *)(GetApp()->GetView(GetChild(u)));
		pButton->SetButton( ButtonBgUI, g_szSessionButtonText[u] );
	}
	SetBackPic( GameSettingUI );
	for( GVFID id = ID_GAMESESSION0; id <= ID_GAMESESSION9; id ++ )
		GetControl(id)->EnableView( false );
}

void CSessionDlg::OnNotify( WPARAM wParam, LPARAM lParam )
{
	if( wParam == ID_REFRESHSESSION )
		RefreshSession();
	else
		CDialog::OnNotify( wParam, lParam );
}

#ifndef _WINUSER_
#error This is a error
#endif

void CSessionDlg::RefreshSession( )
{
	LPSTR lpSessionName;
	DWORD dwCount = 0;
	CButton*	pButton;

	HCURSOR hCur = NULL;
	hCur = SetCursor(LoadCursor(NULL, IDC_WAIT));
	GetApp()->GetDpNet()->GetSessions( lpSessionName, dwCount );
	for( GVFID id = ID_GAMESESSION0; id < dwCount+ID_GAMESESSION0; id ++ )
	{
		pButton = (CButton *)( GetControl(id) );
		pButton->EnableView( true );
		pButton->SetButton( ButtonBgUI, lpSessionName+
			(id-ID_GAMESESSION0)*_MAX_DPNAME );
	}
	for( ; id <= ID_GAMESESSION9; id ++ )
	{
		pButton = (CButton *)( GetControl(id) );
		pButton->EnableView( false );
	}
	if( hCur )
	{
		hCur = SetCursor( hCur );
		if( hCur )
			DestroyCursor( hCur );
	}
}

void CSessionDlg::OnDraw( )
{
	static char szWelcome[] = "��ѡ�������һ����Ϸ�����";
	static char szNoSession[] = "û�з��ֿ��Լ������Ϸ��,�롰ˢ����Ϸ���򡰴�����Ϸ��";
	char* pString;

	if( ((CButton *)GetControl(ID_GAMESESSION0))
		->GetState() & VS_DISABLE )
		pString = szNoSession;
	else
		pString = szWelcome;

	int x = (GetWidth()-strlen(pString)/2*MIDDLEFONT_SIZE)/2;
	IwGetMedia()->TextOut(x,10,pString, RGB(255, 255, 0), CMedia::MiddleFont );
}

/**************************** class CGameConfigDlg ****************************/
BEGIN_MESSAGE_MAP( CGameConfigDlg )
	MESSAGE_PROC(VM_CREATE,OnCreate)
	MESSAGE_PROC(VM_TIMER, OnTimer )
END_MESSAGE_MAP(  );

BEGIN_DIALOG( CGameConfigDlg )
	DIALOG_ITEM( ID_STARTGAME,	CButton, 150,500,350,550 )
	DIALOG_ITEM( ID_CANCEL,		CButton, 450,500,650,550 )
END_DIALOG();

IMPLEMENT_DIALOG( CGameConfigDlg, CDialog );


static char *g_szConfigButtonText[] = {
	"��ʼ��Ϸ",
	"�������˵�",						};

void CGameConfigDlg::OnCreate( WPARAM wParam, LPARAM lParam )
{
	CDialog::OnCreate( wParam, lParam );
	CButton *pButton = NULL;
	for( UINT u = 0; u < GetChildCount(); u ++ )
	{
		pButton = (CButton *)(GetApp()->GetView(GetChild(u)));
		pButton->SetButton( ButtonBgUI, g_szConfigButtonText[u] );
	}
	SetBackPic( GameSettingUI );
	int x,y;
	IwGetMedia()->GetPicSize( GameSettingUI, 0, x, y );
	SetRect( 0,0,x-1,y-1 );
	// Disable or Hide the starting Button;
	if( IwGetDpNet()->IsHost() )
		GetControl(ID_STARTGAME)->EnableView( false );
	else
	{
		GetControl(ID_STARTGAME)->ShowView( false );
		GetControl(ID_CANCEL)->ShowView( false );
	}
}

void CGameConfigDlg::OnTimer( WPARAM wParam, LPARAM lParam )
{
	if( IwGetDpNet()->IsHost() )
	{
		if( IwGetDpNet()->GetPlayers() > 1 )
		{
			GetControl(ID_STARTGAME)->EnableView( true );
			GetControl(ID_CANCEL)->EnableView( false );
		}
	}
	else if( m_pSession->GetISState() & NS_GAMEREADY )
		EndDialog( ID_STARTGAME );
}

void CGameConfigDlg::OnDraw()
{
	static char *pMessage[] = {
		"����û�з����������,��ȴ�������Ҽ���...",
		"����%d����Ҽ���,�롰��ʼ��Ϸ��������ȴ�������Ҽ��롣",
		"���ڵȴ�������ʼ��Ϸ,����Ϸ������һ����%d�����..."
	};
	char temp[1024];
	if( IwGetDpNet()->IsHost() )
	{
		if( IwGetDpNet()->GetPlayers() > 1 )
			sprintf( temp,pMessage[1],IwGetDpNet()->GetPlayers()-1 );
		else	strcpy( temp, pMessage[0] );
	}
	else
		sprintf( temp, pMessage[2], IwGetDpNet()->GetPlayers() );
	int nLen = strlen(temp) ;
	int x = ( GetWidth() - nLen*MIDDLEFONT_SIZE/2 ) /2;
	int y = ( GetHeight() - MIDDLEFONT_SIZE )/2;
	IwGetMedia()->TextOut( x, y,temp, RGB(255,255,255), CMedia::MiddleFont );
}


