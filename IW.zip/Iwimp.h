#ifndef __IWIMP_H
#define __IWIMP_H

#include "Player.h"
#include "AIPlayer.h"

/***************************** class CIcyWeaponApp ***************************/
///////////////////////////////////////////////////////////////////////////////
// class CIcyWeaponApp Inline Functions
GVF_INLINE CPlayer* CIcyWeaponApp::CreatePlayer( BYTE btType, int id )
{
	ASSERT( m_lpPlayers[id] == NULL );
	if( btType == PT_HUMAN )
		m_lpPlayers[id] = new CHumanPlayer;
	else
		m_lpPlayers[id] = new CAIPlayer;
	if( !m_lpPlayers[id] )
		throw EXCEPTION( ErrorNewObject );
	m_uPlayerObjCount ++;
	m_lpPlayers[id]->SetPlayerID( id );
	return m_lpPlayers[id];
}

GVF_INLINE void CIcyWeaponApp::DestroyPlayer( int id )
{
	ASSERT_PLAYERID( id );
	ASSERT( m_lpPlayers[id] );
	delete m_lpPlayers[id];
	m_lpPlayers[id] = NULL;
	m_uPlayerObjCount --;
}

GVF_INLINE CHumanPlayer* CIcyWeaponApp::GetLocalPlayer( )
{
	ASSERT( m_lpPlayers[IwGetLocalID()] );
	return ((CHumanPlayer *)m_lpPlayers[IwGetLocalID()]);
}

#endif
