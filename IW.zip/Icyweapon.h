/*********************************************************************
// Name			: IcyWeapon.h
// Project		: IcyWeapon
// Function		: �������ѭ������WindowsӦ�ó���ӿڡ�
// Abbreviation	: IcyWeapon = Iw; Message = Msg; Application = App;
// Programmed	: Li Wenbin 1999/09/20
*********************************************************************/

#if !defined(__ICYWEAPON_H)
#define	__ICYWEAPON_H

class CMainFrame;
class CMedia;
class CWorld;
class CPlayer;
class CHumanPlayer;

class CIcyWeaponApp : public CGameApp
{
private:
	virtual	bool	InitGame();
	virtual	bool	StartGame();
	virtual	bool	DestroyGame();
	
	virtual	void	RefreshScreen();


// Global Interface
public:
	GVF_INLINE	CMedia*		GetMedia();
	GVF_INLINE	CWorld*		GetWorld();
	GVF_INLINE	CMainFrame*	GetMainFrame();

	// ��ҵĲ���
	GVF_INLINE	CPlayer*	GetPlayer( int id );
	GVF_INLINE	UINT		GetPlayerObjCount( );
	GVF_INLINE	CPlayer*	CreatePlayer( BYTE btType, int id );
	GVF_INLINE	void		DestroyPlayer( int id );
	GVF_INLINE	CHumanPlayer* GetLocalPlayer( );

protected:
	static	CMedia		m_oMedia;
	static	CWorld		m_oWorld;
	static	CMainFrame	m_oMainFrame;
	static	CPlayer*	m_lpPlayers[_MAX_PLAYERS];
	static	UINT		m_uPlayerObjCount;

// Construction/Destruction
public:
	CIcyWeaponApp();
	~CIcyWeaponApp() {};
};

/************************** IcyWeapon Inline Functions ***********************/
GVF_INLINE	CMedia* CIcyWeaponApp::GetMedia( )		{
	return &m_oMedia;								}

GVF_INLINE	CWorld* CIcyWeaponApp::GetWorld( )		{
	return &m_oWorld;								}

GVF_INLINE CMainFrame* CIcyWeaponApp::GetMainFrame(){
	return &m_oMainFrame;							}

GVF_INLINE CPlayer*	CIcyWeaponApp::GetPlayer(
	int id )									{
	ASSERT_PLAYERID( id );
	ASSERT( m_lpPlayers[id] );
	return m_lpPlayers[id];								}

GVF_INLINE UINT	CIcyWeaponApp::GetPlayerObjCount( )	{
	return m_uPlayerObjCount;						}


#endif // !defined(__ICYWEAPON_H)
