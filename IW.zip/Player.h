/*=============================================================================
 * Name			: player.h
 * Project		: IcyWeapon
 * Function		: ���������Ķ���ͷ�ļ�
 * Abbreviation	: UM - Unit Message.
 * Programmed	: Li Wenbin 1999/09/20
******************************************************************************/

#ifndef __PLAYER_H
#define __PLAYER_H

#if _MSC_VER > 1000
#pragma once
#endif

#include "world.h"


#define	INVALID_HUNIT			NULL
#define	UNIT_COMMAND			CUnit::CmdInfo
#define	SCmdIcon				CUnit::CmdIcon
#define	SUnitInfo				CUnit::UnitInfo

#define	_MAX_SELECTIONS			SELECTED_UNIT_MAX_NUM
#define	_MAX_GROUPS				10 // 0 - 9
#define	_MAX_AICOMMANDS			(UINT)0x100

#define	INVALID_GROUPID			INVALID_GROUP_ID
#define	INVALID_PLAYERID		INVALID_SIDE


/* ��ҵ����� */
#define	PT_HUMAN	((BYTE)0)
#define	PT_AI	((BYTE)1)


struct	SPlayerCommand
{
	UINT			m_uDestCount;
	UNIT_COMMAND	m_oUnitCmd;
	HUNIT			m_hDestUnits[SELECTED_UNIT_MAX_NUM];
};
/***************************** class CPlayer *********************************/
// ������Ϸ��������º���
// void		CWorld::ExecuteCommand( HUNIT hUnits[], COMMMAND cmd );
// HUNIT	CWorld::GetTileUnitHandle( WORD wTile )
// CUnit*	CWorld::GetUnit( HUNIT hUnit );

// ����CUnit���º���
// HUNIT	CUnit::GetHandle();
// void		CUnit::GetCmdIcon(int &nIconNum, CmdIcon stCmdIcon[CMD_ICON_MAX_NUM]);
// void		CUnit::OnIconClicked( WORD wId, CmdInfo& stCmdInfo );
// void		CUnit::GetMsgCmd( MsgInfo stMsgInfo, CmdInfo& stCmdInfo );
// char		CUnit::GetUnitSide( );
// POINT	CObject::GetTileCoord( );

class CPlayer  
{
public:
	GVF_INLINE	void		CmdProc( SPlayerCommand& cmd );
	GVF_INLINE	DWORD		GetSelectCount();
	GVF_INLINE	HUNIT*		GetSelect();
	GVF_INLINE	CUnit*		GetUnit( HUNIT hUnit );
	GVF_INLINE	int	GetPlayerID( );
	GVF_INLINE	void		SetPlayerID( int id );
	GVF_INLINE	void		RemoveGroupUnit( HUNIT hUnit );
	GVF_INLINE	bool		GetUnitInfo( SUnitInfo& unitInfo );
	GVF_INLINE	int	GetSelectUnitSide( );

	GVF_INLINE	WORD		GetNextTown( );
	GVF_INLINE	CCursor::CursorKind	GetCrntCursor( );

public:
	// ��Ԫ����֪ͨ
	virtual void	OnUnitCreated(HUNIT hUnit, DWORD dwParam = NULL);
	// ��Ԫ����֪ͨ
	virtual void	OnUnitDead(HUNIT hUnit, DWORD dwParam = NULL);

protected:
	void		SelectUnits( RECT rect, bool bSelectComplete );	// ��Ϸ��������ϵ
	void		SetGroup( GROUPID id, UINT uCount, HUNIT* hUnits );
	GVF_INLINE	HUNIT*	GetGroup( GROUPID id, UINT* pCount = NULL );

	UINT		m_uSelectedCount;
	HUNIT		m_hSelected[_MAX_SELECTIONS];

	int	m_idSelf;	/* �����ľ�� */
	HUNIT		m_hGroups[_MAX_GROUPS][_MAX_SELECTIONS];
	UINT		m_uGroupCount[_MAX_GROUPS];

	CCursor::CursorKind	m_nCursorType;

	// ���캯��
public:
	CPlayer();
};

/**************************** class  CLocalPlayer ****************************/
class CHumanPlayer : public CPlayer
{
public:
	/* ��������Ϣ����Ϊ��Ԫ���� */
	bool	MsgProc( MSG& msg, DWORD dwMKState, SPlayerCommand& playCmd);
	
	bool	GetCmdIcons( UINT& uCount, SCmdIcon  aCmds[] );
	void	OnSelect( DWORD dwKeyState, RECT rect );		/* ������µļ������״̬�Լ���ǰ�ľ��� */
	bool	OnKeyDown( DWORD dwKeyState, WPARAM vk );

public:

protected:
	SCmdIcon	m_oCrntCmd[_MAX_CMDICONS];
	UINT		m_uCrntCmdCount;
};


/***************************** Inline Functions ******************************/
// CPlayer Inline Function
GVF_INLINE CCursor::CursorKind CPlayer::
			GetCrntCursor( )				{
	return m_nCursorType ;					}


GVF_INLINE int CPlayer::GetPlayerID( )	{
	return m_idSelf;						}

GVF_INLINE void CPlayer::SetPlayerID( int id ){
	m_idSelf = id ;									}

GVF_INLINE HUNIT* CPlayer::GetGroup( GROUPID id, UINT *pCount )	{
	if( pCount != NULL )
		*pCount = m_uGroupCount[id];
	return m_hGroups[id];								}

GVF_INLINE	DWORD CPlayer::GetSelectCount()	{
	return m_uSelectedCount;				}

GVF_INLINE	HUNIT* CPlayer::GetSelect()		{
	return m_hSelected;						}

GVF_INLINE void CPlayer::CmdProc( SPlayerCommand& cmd )	{
	IwGetWorld()->UnitsExecuteCommand(cmd.m_hDestUnits,	\
		cmd.m_uDestCount, cmd.m_oUnitCmd,  m_idSelf);		}

GVF_INLINE	CUnit* CPlayer::GetUnit( HUNIT hUnit )	{
	ASSERT( hUnit != INVALID_HUNIT );
	return IwGetWorld()->GetUnitPointer( hUnit );	}

GVF_INLINE bool CPlayer::GetUnitInfo( SUnitInfo& unitInfo )
{
	if( m_uSelectedCount <= 0 ) return false;
	GetUnit( m_hSelected[0] )->GetUnitInfo( unitInfo );
	return true;
}


GVF_INLINE int CPlayer::GetSelectUnitSide()
{
	if( m_uSelectedCount <= 0 )
		return INVALID_PLAYERID;
	else 
		return GetUnit( m_hSelected[0] ) -> GetUnitSide( );
}


GVF_INLINE WORD CPlayer::GetNextTown()
{
	HUNIT hUnit = IwGetWorld()->GetPlayerNextTown
		( m_idSelf );
	if( hUnit )
		return GetUnit( hUnit )->GetWordTileCoord();
	else
		return WORD_CO(0,0);
}


#endif
