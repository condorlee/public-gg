/*=============================================================================
 * Name			: MainFrame.h
 * Project		: IcyWeapon
 * Function		: ��Ϸ��������ϷҪ��ܵĶ���
 * Abbreviation	: Assis	= Assistant
 * Programmed	: Li Wenbin
 * Date			: 1999/09/20
******************************************************************************/

#if !defined(AFX_MAINFRAME_H__A543BF61_773C_11D3_A68A_0000E83EE37C__INCLUDED_)
#define AFX_MAINFRAME_H__A543BF61_773C_11D3_A68A_0000E83EE37C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Episode.h"
#include "Player.h"
#include "IwSession.h"
#include "Cursor.h"
#include "IwImp.h"

// Game Menu Button ID
#define	ID_RESTARTGAME	0x0104
#define	ID_QUITGAME		0x0105
#define	ID_OPTION		0x0106
#define	ID_RETURN		0x0107

#define	ID_CMDICON_FIRST	0x1000

#define	_MAX_MSGBUFFERSIZE		0x100
#define	_MAX_SESSIONMSGELAPSE	0x2000		// two second


#define	HINT_POSX			10
#define	HINT_POSY			10

#define	_MAX_MINIMAP_WIDTH	MINIMAP_WIDTH
#define	_MAX_MINIMAP_HEIGHT	MINIMAP_WIDTH


// Game State
#define	GS_DEFAULT		0x0000		// ��Ϸ״̬��Ĭ����ֵ
#define	GS_START		0x0001		// ��Ϸ����
#define GS_TOMAINMENU	0x0002		// ��Ҫ�������˵�
#define	GS_CYCLEBREAK	0x0004		// ��ǰ������ǰ��Ϸѭ��
#define	GS_MSGPROC		0x0008		// ���ڴ�����Ϣ
#define	GS_WAITFORCMD	0x0010		// ���ڵȴ�����
#define	GS_WAITFORQUIT	0x0020		// ��ҽ�Ҫ�˳���Ϸ


/**************************** class CCmdIcon *********************************/
class CCmdIcon : public CButton
{
	DECLARE_VIEW( CCmdIcon );

protected:
	proc_function( OnKeyDown );
	proc_function( OnKeyUp );

public:		/* ��Ϊ���ݵĴ�ŵء�*/
	SCmdIcon	m_oCmdData;

public:
	void	SetCmdIcon( SCmdIcon& cmdInfo );
};


/******************************* class CMainFrame ****************************/
class CMainFrame : public CFrame
{
	DECLARE_VIEW ( CMainFrame );

///////////////////////////////////////////////////////////////////////////////
// Message Process Function
public:
	proc_function( OnCreate );
	proc_function( OnDestroy );
	proc_function( OnQuit );
	proc_function( OnNotify );
	virtual	void	OnDraw( );
	virtual	void	InvalidPaint( bool bInvalid );

	/* ������Ϣ */
	proc_function( OnKeyDown );
	proc_function( OnKeyUp );

	/* �����Ϣ */
	proc_function( OnLButtonDown );
	proc_function( OnLButtonUp );
	proc_function( OnRButtonDown );
	proc_function( OnRButtonUp );

public:
	CMainFrame();
	virtual ~CMainFrame();
///////////////////////////////////////////////////////////////////////////////
// MainFrame Operations
protected:
	GVFID	PopupMainMenu();
	GVFID	PopupGameMenu();
	void	StartGame( GVFID id );	// ��ͼ��ʼ��Ϸ,��һ���ɹ�,ֻ��ͨ��IsGameStart()���ж�
	void	EndGame();				// ��ͼ������Ϸ,��һ���ɹ�,ֻ��ͨ��IsGameStart()���ж�

	void	InitGameData( );
	void	DestroyGameData( );	
	GVF_INLINE	void	SetGameState( DWORD dwState, bool bSet = true );
	GVF_INLINE	DWORD	GetGameState( );
	GVF_INLINE	bool	IsGameStart();

public:
	GVF_INLINE	void	SetQuit( );

private:
	DWORD		m_dwGameState;			/* ��Ϸ��״̬��,��:��û�п�ʼ��Ϸ */
	DWORD		m_dwQuitCount;			// ��Ҫ�˳���Ϸʱ�ļ�����


///////////////////////////////////////////////////////////////////////////////
// Mainframe ControlPanel Operation And Its Attributes
// Command Icon Operations
protected:
	bool		IconOnKey( WPARAM vk );		/* �����»��ͷ�ĳ����ʱ,Icons�Ƿ���Ӧ */
	RECT		GetIconRect( UINT uNum );	/* ���ָ����ICONλ�� */
	UINT		GetIconFromPos( POINT pt );	/* ��һ��λ����һ����Ч��ICON */

// Attributes
private:
	CCmdIcon	m_oCmdIcons[_MAX_CMDICONS];	/* ���ư���CmdIcon��������� */
	UINT		m_uVisibleIconCount;		/* ��ǰ��ʾ��CmdIcon����Ŀ */

private:
	bool		m_bSelecting;
	void		BeginSelect( void );
	void		EndSelect( void );

///////////////////////////////////////////////////////////////////////////////
// MainFrame Main Cycle
public:
	proc_function( OnTimer );
	void		WorldCmdProc( );
	GVF_INLINE	void		PutGameMsg( char *pMsg );
	GVF_INLINE	CIwSession*	GetSession( void );
	GVF_INLINE	SGameInfo*	GetGameInfo( void );

private:
	CIwSession	m_oIwSession;
	char		m_szSessionMsg[_MAX_SESSIONMSG];
	UINT		m_uSessionMsgElapse;
	char		m_szUnitHint[_MAX_HINTLENGTH];	/* ��Ԫ����ʾ��Ϣ */
	UINT		m_uHintElapse;					/* ��Ԫ��ʾ��Ϣ��ʾ��ʱ�� */



///////////////////////////////////////////////////////////////////////////////
// MainFrame Attributes
public:
	GVF_INLINE	bool		GetCursorWorldPos( POINT& pt );
	GVF_INLINE	int			GetWorldWidth();
	GVF_INLINE	int			GetWorldHeight();
	GVF_INLINE	void		ViewToWorld( RECT& rect );
	GVF_INLINE	void		WorldToView( RECT& rect );

	GVF_INLINE	void		ViewToWorld( POINT& pt );
	GVF_INLINE	void		WorldToView( POINT& pt );

	GVF_INLINE	void		MiniMapToWorld( RECT& rect );
	GVF_INLINE	void		WorldToMiniMap( RECT& rect );

	GVF_INLINE	void		MiniMapToWorld( POINT& pt );
	GVF_INLINE	void		WorldToMiniMap( POINT& pt );

	GVF_INLINE	void		ValidateWorldPoint( int& x, int& y );
	GVF_INLINE	void		ValidateOffsetPoint( );

	WORD		GetCenterTile();			/* �����Ļ���ĵ�ĵ�ש���� */
	void		SetCenterTile( WORD wTile);	/* ������Ļ���ĵ�ĵ�ש���� */
	void		UnitHint( LPSTR lpszHint ); /* ��Ԫ����ʾ��Ϣ */

private:
	POINT		m_ptSelectedStart;			/* ѡ�п����� */
	POINT		m_ptCrntPos;				/* ��ǰ�Ĺ���λ�� */
	POINT		m_ptViewOffset;				/* ��ʾ�������Ϸ��ƫ���� */
	RECT		m_rcWorldView;				/* ��Ϸ������ʾ�ķ�Χ */
	RECT		m_rcStatusPanel;			/* ״̬���ķ�Χ */
	RECT		m_rcMiniMap;
	RECT		m_rcControlPanel;			/* ���ư�ķ�Χ */

	CCursor		m_oGameCursor;

///////////////////////////////////////////////////////////////////////////////
// ��Ϸ�����еļ��̺�����״̬
private:
	DWORD	m_dwMKState;
	GVF_INLINE	void	SetMKState( DWORD dw, bool bSet = true );

public:
	GVF_INLINE	DWORD	GetMKState( );		/* ��õ�ǰ��Ч�ļ��̺�����״̬ */


///////////////////////////////////////////////////////////////////////////////
// ��Ϣ����������
public:
	virtual	bool MsgProc( MSG& msg );
protected:
	bool	GetMsg( MSG& msg );
	bool	PutMsg( MSG& msg );
	GVF_INLINE	void	EmptyMsgQueue( );
	GVF_INLINE	bool	IsQueueEmpty();
	GVF_INLINE	bool	IsQueueFull();
	
// ��Ϣ����������
private:
	MSG		m_aMsgQueue[_MAX_MSGBUFFERSIZE+1];	//����Ϣ�������
	UINT	m_uQueueHead, m_uQueueTail;

	GVF_INLINE	void	NextPos( UINT& u );
};

/***************************** Inline Functions ******************************/
// Message Queue Function.
GVF_INLINE	bool CMainFrame::IsQueueEmpty( )	{
	return ( m_uQueueHead == m_uQueueTail ? true:false );	}

GVF_INLINE	bool CMainFrame::IsQueueFull()		{
	return ( m_uQueueTail == m_uQueueHead-1 ||	\
		m_uQueueTail == m_uQueueHead+_MAX_MSGBUFFERSIZE-1? true:false );	}

GVF_INLINE	void CMainFrame::EmptyMsgQueue( )	{
	m_uQueueTail = m_uQueueHead = 0;	}

GVF_INLINE	void CMainFrame::NextPos( UINT &u ){
	u == _MAX_MSGBUFFERSIZE ? u = 0 : u++ ;	}

// Mouse and Key State Function
GVF_INLINE DWORD CMainFrame::GetMKState( )	{
	return m_dwMKState;						}

GVF_INLINE void CMainFrame::SetMKState( DWORD	\
	dw, bool bSet )						{
	if( bSet )	m_dwMKState |= dw;
	else		m_dwMKState &= ~dw;		}

GVF_INLINE	int	CMainFrame::GetWorldWidth()			{
	return IwGetWorld()->GetWidth()*TILE_WIDTH;		}

GVF_INLINE	int CMainFrame::GetWorldHeight()		{
	return IwGetWorld()->GetHeight()*TILE_HEIGHT;	}

// ת������ܵ����굽��Ϸ����
GVF_INLINE void CMainFrame::ViewToWorld( RECT& rect )		{
	OffsetRect(&rect ,m_ptViewOffset.x-m_rcWorldView.left, 
			m_ptViewOffset.y-m_rcWorldView.top );			}

GVF_INLINE void CMainFrame::ViewToWorld( POINT& pt )		{
	pt.x += m_ptViewOffset.x-m_rcWorldView.left;
	pt.y += m_ptViewOffset.y-m_rcWorldView.top ;			}

GVF_INLINE void CMainFrame::WorldToView( RECT& rect )		{
	OffsetRect(&rect ,m_rcWorldView.left-m_ptViewOffset.x, 
			m_rcWorldView.top-m_ptViewOffset.y );			}

GVF_INLINE void CMainFrame::WorldToView( POINT& pt )		{
	pt.x += m_rcWorldView.left-m_ptViewOffset.x;
	pt.y += m_rcWorldView.top-m_ptViewOffset.y;				}

GVF_INLINE bool CMainFrame::GetCursorWorldPos( POINT& pt )	{
	pt = m_ptCrntPos;
	if( !(PointInRect(pt, m_rcWorldView)) )
		return false;
	ViewToWorld( pt );
	return true;											}

// ת��С��ͼ�����굽��Ϸ����
GVF_INLINE	void CMainFrame::MiniMapToWorld( RECT& rect )	{
	OffsetRect(&rect,-m_rcMiniMap.left, -m_rcMiniMap.top);		
	EnlargeRect(rect ,IwGetWorld()->GetMiniMapRatio()*TILE_WIDTH,
			IwGetWorld()->GetMiniMapRatio()*TILE_HEIGHT );	}

GVF_INLINE	void CMainFrame::WorldToMiniMap( RECT& rect )		{
	EnlargeRect(rect ,-IwGetWorld()->GetMiniMapRatio()*TILE_WIDTH,
			-IwGetWorld()->GetMiniMapRatio()*TILE_HEIGHT );		
	OffsetRect(&rect,m_rcMiniMap.left,m_rcMiniMap.top);			}

GVF_INLINE	void CMainFrame::MiniMapToWorld( POINT& pt )	{
	pt.x -= m_rcMiniMap.left;
	pt.x *= IwGetWorld()->GetMiniMapRatio()*TILE_WIDTH;
	pt.y -= m_rcMiniMap.top;
	pt.y *= IwGetWorld()->GetMiniMapRatio()*TILE_HEIGHT;	}

GVF_INLINE	void CMainFrame::WorldToMiniMap( POINT& pt )	{
	pt.x /= IwGetWorld()->GetMiniMapRatio()*TILE_WIDTH;
	pt.x += m_rcMiniMap.left;
	pt.y /= IwGetWorld()->GetMiniMapRatio()*TILE_HEIGHT;
	pt.y += m_rcMiniMap.top;								}

GVF_INLINE void CMainFrame::ValidateWorldPoint( int& x, int& y ){
	if( x < 0 )	x = 0;	
	else if( x >= GetWorldWidth() ) x = GetWorldWidth()-1;
	if( y < 0 ) y = 0;
	else if( y >= GetWorldHeight())y = GetWorldHeight()-1;		}


GVF_INLINE void CMainFrame::ValidateOffsetPoint( )					{
	if( m_ptViewOffset.x < 0 )	 m_ptViewOffset.x = 0;
	else if( m_ptViewOffset.x > GetWorldWidth()-GetRectWidth(m_rcWorldView) )
		m_ptViewOffset.x = GetWorldWidth()-GetRectWidth(m_rcWorldView);
	if( m_ptViewOffset.y < 0 )	 m_ptViewOffset.y = 0;
	else if( m_ptViewOffset.y > GetWorldHeight()-GetRectHeight(m_rcWorldView) )
		m_ptViewOffset.y = GetWorldHeight()-GetRectHeight(m_rcWorldView);			}

// ��Ϸ״̬
GVF_INLINE void CMainFrame::SetGameState( 
	DWORD dwState, bool bSet )					{
	if( bSet ) m_dwGameState |= dwState;
	else m_dwGameState &= ~dwState;				}

GVF_INLINE	DWORD CMainFrame::GetGameState(	)	{
	return m_dwGameState;						}

GVF_INLINE bool	CMainFrame::IsGameStart()		{
	return GetGameState()&GS_START? true:false;	}

GVF_INLINE void CMainFrame::SetQuit( )			{
	SetGameState( GS_WAITFORQUIT );
	m_dwQuitCount = IwGetWorld()
		->GetTickCounter();						}

// Game Session
GVF_INLINE CIwSession* CMainFrame::GetSession( )			{
	return &m_oIwSession;									}

GVF_INLINE SGameInfo* CMainFrame::GetGameInfo( )			{
	return GetSession()->GetGameInfo();						}

GVF_INLINE void CMainFrame::PutGameMsg( char *pMsg )		{
	ASSERT( strlen(pMsg) < _MAX_SESSIONMSG );
	strcpy( m_szSessionMsg, pMsg );
	m_uSessionMsgElapse = 0;								}

/******************************** class CMainMenu ****************************/
class CMainMenu : public CDialog
{
	DECLARE_DIALOG ( CMainMenu );

protected:
	proc_function( OnCreate );
	virtual	void	EndDialog( GVFID id );
};

/******************************** class CGameMenu ****************************/
class CGameMenu : public CDialog
{
	DECLARE_DIALOG ( CMainMenu );
protected:
	proc_function( OnCreate );	
};
#endif // !defined(AFX_MAINFRAME_H__A543BF61_773C_11D3_A68A_0000E83EE37C__INCLUDED_)
