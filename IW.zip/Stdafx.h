/*============================================================================
 * Name			: stdafx.h
 * Project		: IcyWeapon
 * Function		: ����Ŀ��Ԥ����ͷ�ļ�
 * Abbreviation	: 
 * Programmed	: Li Wenbin 1999/09/20
 * Modified-1st	: Li Hua	1999/09/21
******************************************************************************/
#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	OEMRESOURCE
// Windows Header Files:
#include <windows.h>
#include <windowsx.h>

// C RunTime Library Header Files:
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <limits.h>
#include <time.h>
#include <math.h>


// Assert Function Header Files:
#include <crtdbg.h>
#define ASSERT		_ASSERT

#define ASSERT_RANGE(v, min, max) ASSERT((v > min) && (v < max))
#define INLINE __inline


#pragma warning( disable : 4800 )

// Our Precompile Header Files
#include "Resource.h"
#include "GlobalDefine.h"
#include "Exception.h"
#include "DpInterface.h"
#include "DxInterface.h"
#include "Package.h"
#include "Media.h"
#include "Cursor.h"
#include "View.h"
#include "IcyWeapon.h"

// Global Functions and Its Macro
#define	IwGetApp()			((CIcyWeaponApp	*)(GetApp()))
#define	IwGetMedia()		(IwGetApp()->GetMedia())
#define	IwGetWorld()		(IwGetApp()->GetWorld())
#define IwGetMainFrame()	(IwGetApp()->GetMainFrame())
#define	IwGetDpNet()		(IwGetApp()->GetDpNet())
#define	IwGetLocalID()		(IwGetDpNet()->GetSelfID())
#define IwGetPlayer(id)		(IwGetApp()->GetPlayer(id))
#define	IwGetLocalPlayer()	(IwGetApp()->GetLocalPlayer())


#endif// !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
