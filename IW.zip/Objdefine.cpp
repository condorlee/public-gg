/*
	�ļ���	:	ObjDefine.CPP  
	��Ŀ	:	IcyWeapon
	ģ��	:	����ģ��
	����	:
	����Ա	:	��  ��
	����	:	1999/10/09
	�޸�1	:	1999/10/18

	�ļ����ܣ�	Ϊ��������������������������Ԥ��ֵ
*/


#include "stdafx.h"

#include "unit.h"
#include "world.h"

/* �������������� */
CWeapon::WeaponInfo	CWeapon::m_stAllWeaponInfo[EndWeapon - NullWeapon] =
{
	//NullWeapon,
	{StaticTrack},
		
	//Axe,
	{
		StaticTrack,		//BYTE		byTrack;
		50,					//WORD		wPower;
		YARD_PER_TILE / 4,	//WORD		wError;
		0,					//WORD		wSpeed;
		6,					//WORD		wEffectStart;
		8,					//WORD		wEffectLast;
		YARD_PER_TILE / 2,	//int			nEffectRadius;
		YARD_PER_TILE * 2,	//int			nRange;
		NULL,				//HPICTURE		hPicture;
		false,				//bool			bPictureDir;
		NULL,				//HSOUND		hFireSound;
		AxeEffectSound,			//HSOUND		hEffectSound;
		NullObjectKind		//ObjectKind	eBombSmogKind;
	},

	//LightSword,
	{
		StaticTrack,		//BYTE		byTrack;
		25,					//WORD		wPower;
		YARD_PER_TILE / 8,	//WORD		wError;
		0,					//WORD		wSpeed;
		6,					//WORD		wEffectStart;
		8,					//WORD		wEffectLast;
		YARD_PER_TILE / 4,	//int			nEffectRadius;
		YARD_PER_TILE * 2,	//int			nRange;
		NULL,				//HPICTURE		hPicture;
		false,				//bool			bPictureDir;
		NULL,				//HSOUND		hFireSound;
		SwordEffectSound,	//HSOUND		hEffectSound;
		NullObjectKind		//ObjectKind	eBombSmogKind;
	},

	//HeavySword,
	{
		StaticTrack,		//BYTE		byTrack;
		35,					//WORD		wPower;
		YARD_PER_TILE / 6,	//WORD		wError;
		0,					//WORD		wSpeed;
		6,					//WORD		wEffectStart;
		8,					//WORD		wEffectLast;
		YARD_PER_TILE / 3,	//int			nEffectRadius;
		YARD_PER_TILE * 2,	//int			nRange;
		NULL,				//HPICTURE		hPicture;
		false,				//bool			bPictureDir;
		NULL,				//HSOUND		hFireSound;
		SwordEffectSound,	//HSOUND		hEffectSound;
		NullObjectKind		//ObjectKind	eBombSmogKind;
	},

	//LightArrow,
	{
		StraightTrack,		//BYTE		byTrack;
		80,					//WORD		wPower;
		YARD_PER_TILE / 6,	//WORD		wError;
		YARD_PER_TILE,		//WORD		wSpeed;
		1,					//WORD		wEffectStart;
		3,					//WORD		wEffectLast;
		YARD_PER_TILE / 2,	//int			nEffectRadius;
		YARD_PER_TILE * 12,	//int			nRange;
		ArrowPs,			//HPICTURE		hPicture;
		true,				//bool			bPictureDir;
		LightArrowEmitSound,//HSOUND		hFireSound;
		NULL,				//HSOUND		hEffectSound;
		NullObjectKind		//ObjectKind	eBombSmogKind;
	},
	//HeavyArrow,
	{
		StraightTrack,		//BYTE		byTrack;
		100,				//WORD		wPower;
		YARD_PER_TILE / 5,	//WORD		wError;
		YARD_PER_TILE,		//WORD		wSpeed;
		1,					//WORD		wEffectStart;
		3,					//WORD		wEffectLast;
		YARD_PER_TILE * 2 / 3,//int			nEffectRadius;
		YARD_PER_TILE * 12,	//int			nRange;
		ArrowPs,			//HPICTURE		hPicture;
		true,				//bool			bPictureDir;
		HeavyArrowEmitSound,//HSOUND		hFireSound;
		NULL,				//HSOUND		hEffectSound;
		CObject::LittleBombSmog//ObjectKind	eBombSmogKind;
	}
};


/* ���ֱ�ը�Ƶ����� */
CObject::ObjProperty CBombSmog::m_stAllBombSmogProperty[EndBombSmog - NullBombSmog] =
{
	//NullBombSmog,
	{false},

	//LittleBombSmog,	
	{
		false,				//bool		bLongLife;
		false,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		false,				//bool		bHaveSide;

		LittleBombPs,		//HPICTURE	hPicture;
		10,					//WORD		wPicCount;
		1,					//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//BigBombSmog,
	{
		false,				//bool		bLongLife;
		false,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		false,				//bool		bHaveSide;

		BigBombPs,			//HPICTURE	hPicture;
		10,					//WORD		wPicCount;
		1,					//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	}
};


/* ���ֵر������������ */
CObject::ObjProperty COverlay::m_stAllOverlayProperty[EndOverlay - NullOverlay] =
{
	//NullOverlay,
	{false},

	//VillagerCorpse
	{
		false,				//bool		bLongLife;
		true,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		VillagerCorpsePs,	//HPICTURE	hPicture;
		48,					//WORD		wPicCount;
		MOBILE_CORPSE_LAST,	//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//AxemanCorpse,
	{
		false,				//bool		bLongLife;
		true,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		AxemanCorpsePs,		//HPICTURE	hPicture;
		48,					//WORD		wPicCount;
		MOBILE_CORPSE_LAST,	//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//SwordmanCorpse,
	{
		false,				//bool		bLongLife;
		true,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		SwordmanCorpsePs,	//HPICTURE	hPicture;
		48,					//WORD		wPicCount;
		MOBILE_CORPSE_LAST,	//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//CavalryCorpse,
	{
		false,				//bool		bLongLife;
		true,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		CavalryCorpsePs,	//HPICTURE	hPicture;
		48,					//WORD		wPicCount;
		MOBILE_CORPSE_LAST,	//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//CrossbowCorpse,
	{
		false,				//bool		bLongLife;
		true,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		CrossbowCorpsePs,	//HPICTURE	hPicture;
		24,					//WORD		wPicCount;
		MOBILE_CORPSE_LAST,	//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},

	//BuildingCorpse1,
	{
		false,				//bool		bLongLife;
		false,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		BuildingCorpse1Ps,	//HPICTURE	hPicture;
		1,					//WORD		wPicCount;
		BUILDING_CORPSE_LAST,//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//BuildingCorpse2,
	{
		false,				//bool		bLongLife;
		false,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		BuildingCorpse2Ps,	//HPICTURE	hPicture;
		1,					//WORD		wPicCount;
		BUILDING_CORPSE_LAST,//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},
	//BuildingCorpse3,
	{
		false,				//bool		bLongLife;
		false,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		true,				//bool		bHaveSide;

		BuildingCorpse3Ps,	//HPICTURE	hPicture;
		1,					//WORD		wPicCount;
		BUILDING_CORPSE_LAST,//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},

	//MoveTargetCursor
	{
		false,				//bool		bLongLife;
		false,				//bool		bDirVision;
		false,				//bool		bRandomVision;
		false,				//bool		bHaveSide;

		MoveTargetCursorUI,	//HPICTURE	hPicture;
		6,					//WORD		wPicCount;
		1,					//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	},

	//Smudge
	{
		true,				//bool		bLongLife;
		false,				//bool		bDirVision;
		true,				//bool		bRandomVision;
		false,				//bool		bHaveSide;

		SmudgePs,			//HPICTURE	hPicture;
		4,					//WORD		wPicCount;
		1,					//WORD		wStateLast;

		1,					//WORD		wFullBlood;
		NULL,				//WORD		wMovable;
		NULL				//DWORD		dwAbility;
	}
};


/* ������Ȼ���������ɫ */
BYTE CNature::m_byAllNatureColor[EndNature - NullNature] =
{
	0,
	54,
	100
};


/* ������Ȼ������� */
CObject::ObjProperty CNature::m_stAllNatureProperty[EndNature - NullNature] =
{
	//NullNature,
	{false},

	//MoneyTree
	{
		true,			//bool		bLongLife;
		false,			//bool		bDirVision;
		false,			//bool		bRandomVision;
		false,				//bool		bHaveSide;

		MoneyTreePs,	//HPICTURE	hPicture;
		1,				//WORD		wPicCount;
		1,				//WORD		wStateLast;

		MONEY_TREE_MONEY,//WORD		wFullBlood;
		CWorld::CPath::LandMovable,	//WORD		wMovable;

		CanProvideMoney	//DWORD		dwAbility;
	},

	//Tree
	{
		true,			//bool		bLongLife;
		false,			//bool		bDirVision;
		true,			//bool		bRandomVision;
		false,			//bool		bHaveSide;

		TreePs,			//HPICTURE	hPicture;
		2,				//WORD		wPicCount;
		1,				//WORD		wStateLast;

		1,				//WORD		wFullBlood;
		CWorld::CPath::LandMovable,	//WORD		wMovable;

		NULL			//DWORD		dwAbility;
	}
};


/**************************/
/* ��Ԫ��ʾ��Ϣ�ַ������� */
/**************************/

char* CUnit::m_sUnitHints[EndUnitHint] =
{
	"",						//NullUnitHint,
	"��Ǯ����",				//GiveMoney,
	"�һ���",				//Created,
	"����",					//Selected,
	"�յ�����",				//CmdReceived,
	"�������",				//CmdCompleted,
	"�����޷�ִ��",			//CmdAborted,
	"ȡ����ǰ����",			//CmdCanceled,

	"Ǯ����",				//NotEnoughMoney,

	"�����Ҽ�ָ���ƶ���Ŀ�ĵ�",		//AssignMoveTarget,
	"�����Ҽ�ָ��������Ŀ�굥Ԫ",	//AssignAttackTarget,
	"�����Ҽ�ָ������ص�",			//AssignBuildTarget,
	"�����Ҽ�ָ��Ҫ�����Ľ�����",	//AssignRepairTarget,
	"�����Ҽ�ָ��Ҫ����Ľ�����",	//AssignDerepairTarget,
	"�����Ҽ�ָ��Ҫ�ɼ���ҡǮ��",	//AssignHarvestTarget,
	"�����Ҽ�ָ�����Ǯ�ĳ�������",	//AssignSaveTarget,
	"�����Ҽ�ָ�����ϵص�",			//AssignRallyTarget

									//NullSideHint,
	"���ֵ���",						//EncounterEnemy,
	"��Ա��Ŀ�ﵽ����",				//MobileNumberOverflow,
	"��������Ŀ�ﵽ����",			//BuildingNumberOverflow,
	"�±�û������ռ�",		//NoRoomForNewMobile,

									//EndSideHint

									//EndLocalHint
	"������",						//Died,
	"����������",					//HalfHurted,
	"",								//Repair,
	"",								//Derepair,
	""								//Harvest,
};


/***********************************/
/* ����CUnit����������Խṹ������ */
/***********************************/

CUnit::LeafClassProperty	CUnit::m_stAllLeafClassProperty[CUnit::EndUnit - CUnit::NullUnit] =
{
	//	NullUnit = EndNature,
	//		NullMobile = NullUnit,
	{""},

	//				Villager,
	{
		"ũ��",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		0,				//BYTE		byNeedTech;
		0,				//BYTE		byProvideTech;
		125,			//WORD		wPrice;

		NullWeapon,		//ObjectKind	eWeaponKind;
		1000,			//WORD			wHitpoint;
		YARD_PER_TILE / 12,//WORD			wSpeed;
		0,				//BYTE			wFireRate;
		0,				//BYTE			byTurnSpeed;
		4,				//BYTE			byEyeshot;
						
		CUnit::CanRepair| CUnit::CanHarvest, 					//WORD	wAbility;						
		CWorld::CPath::LandMovable,								//WORD	wMovable;

		{NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Town,

		CAN_BUGOUT,		//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			LEGAL_STATE,	//Bugout,

			LEGAL_STATE,	//Pause,
			LEGAL_STATE,	//Move,
			ILLEGAL_STATE,	//GotoAttack,			
			ILLEGAL_STATE,	//Attack,

			LEGAL_STATE,	//GotoRepair,
			LEGAL_STATE,	//Repair,
			LEGAL_STATE,	//GotoDerepair,
			LEGAL_STATE,	//Derepair,
			LEGAL_STATE,	//GotoHarvest,
			LEGAL_STATE,	//Harvest,
			LEGAL_STATE,	//GotoSave,
			LEGAL_STATE,	//Save,

			ILLEGAL_STATE,	//BeBuilt,
			ILLEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			VillagerStandbyPs,	//Standby,
			VillagerBugoutPs,	//Bugout,

			VillagerStandbyPs,	//Pause,
			VillagerMovePs,		//Move,
			NULL,				//GotoAttack,			
			NULL,				//Attack,

			VillagerMovePs,		//GotoRepair,
			VillagerRepairPs,	//Repair,
			VillagerMovePs,		//GotoDerepair,
			VillagerRepairPs,	//Derepair,
			VillagerMovePs,		//GotoHarvest,
			VillagerHarvestPs,	//Harvest,
			VillagerMovePs,		//GotoSave,
			VillagerStandbyPs,	//Save,

			NULL,				//BeBuilt,
			NULL,				//Produce,

			VillagerDeadPs		//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			MoneyInSound,			//GiveMoney
			UnitCreatedSound,		//Created,
			VillagerAcknowledgeSound,//Selected,
			VillagerAcknowledgeSound,//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NotEnoughMoneySound,	//NotEnoughMoney,

			NULL		,			//AssignMoveTarget,
			NULL		,			//AssignAttackTarget,
			NULL		,			//AssignBuildTarget,
			NULL		,			//AssignRepairTarget,
			NULL		,			//AssignDerepairTarget,
			NULL		,			//AssignHarvestTarget,
			NULL		,			//AssignSaveTarget,
			NULL		,			//AssignRallyTarget,
			NULL		,			//EncounterEnemy,
			NULL		,			//MobileNumberOverflow,
			PopulationOverflowSound,//BuildingNumberOverflow,
			NULL		,			//NoRoomForNewMobile,
									//EndLocalHint

			VillagerDeadSound,		//Died,
			NULL,					//HalfHurted
			VillagerRepairSound,	//Repair,
			VillagerRepairSound,	//Derepair,
			VillagerHarvestSound	//Harvest,
		},

		VillagerIconUI,	//HPICTURE	hIcon;

		BloodSlot24UI,	//HPICTURE	hBloodSlot;
		24,				//BYTE		byBloodSlotSegNum;
		Ellipse24,		//BYTE		byChoiceEllipseSize;
		VillagerCorpse,	//ObjectKind	eCorpseKind;
		NullBombSmog,	//ObjectKind	eBombSmogKind;

		24,				//WORD		wBodyWidth;
		42,				//WORD		wBodyHeight;

		OneTileShape	//BuildingShapeKind eShapeKind;
	},
	
	//				Axeman,
	{
		"����",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		5,				//BYTE		byNeedTech;
		0,				//BYTE		byProvideTech;
		135,			//WORD		wPrice;

		Axe,			//ObjectKind	eWeaponKind;
		2500,			//WORD		wHitpoint;
		YARD_PER_TILE / 12,//WORD		wSpeed;
		40,				//BYTE		wFireRate;
		0,				//BYTE		byTurnSpeed;
		4,				//BYTE		byEyeshot;
						
		NULL,						//WORD	wAbility;						
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Barrack,

		CAN_BUGOUT,		//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			LEGAL_STATE,	//Bugout,

			LEGAL_STATE,	//Pause,
			LEGAL_STATE,	//Move,
			LEGAL_STATE,	//GotoAttack,
			LEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			ILLEGAL_STATE,	//BeBuilt,
			ILLEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			AxemanStandbyPs,	//Standby,
			AxemanBugoutPs,		//Bugout,

			AxemanStandbyPs,	//Pause,
			AxemanMovePs,		//Move,
			AxemanMovePs,		//GotoAttack,
			AxemanAttackPs,		//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			NULL,				//BeBuilt,
			NULL,				//Produce,

			AxemanDeadPs		//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			ManAcknowledgeSound,	//Selected,
			ManAcknowledgeSound,	//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NULL       ,		//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			EncounterEnemySound,	//EncounterEnemy,
			NULL		,			//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NULL       ,		//NoRoomForNewMobile,
									//EndLocalHint
			ManDeadSound,			//Died,
			NULL,					//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		AxemanIconUI,	//HPICTURE	hIcon;

		BloodSlot24UI,	//HPICTURE	hBloodSlot;
		24,				//BYTE		byBloodSlotSegNum;
		Ellipse24,		//BYTE		byChoiceEllipseSize;
		AxemanCorpse,	//ObjectKind	eCorpseKind;
		NullBombSmog,	//ObjectKind	eBombSmogKind;

		24,				//WORD		wBodyWidth;
		36,				//WORD		wBodyHeight;

		OneTileShape	//BuildingShapeKind eShapeKind;
	},

	//				Swordman,
	{
		"����",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		5,				//BYTE		byNeedTech;
		0,				//BYTE		byProvideTech;
		135,			//WORD		wPrice;

		LightSword,			//ObjectKind	eWeaponKind;
		2000,			//WORD		wHitpoint;
		YARD_PER_TILE / 9,//WORD		wSpeed;
		20,				//BYTE		wFireRate;
		0,				//BYTE		byTurnSpeed;
		5,				//BYTE		byEyeshot;
						
		NULL, 						//WORD	wAbility;						
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Barrack,

		CAN_BUGOUT,		//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			LEGAL_STATE,	//Bugout,

			LEGAL_STATE,	//Pause,
			LEGAL_STATE,	//Move,
			LEGAL_STATE,	//GotoAttack,
			LEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			ILLEGAL_STATE,	//BeBuilt,
			ILLEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			SwordmanStandbyPs,	//Standby,
			SwordmanBugoutPs,	//Bugout,

			SwordmanStandbyPs,	//Pause,
			SwordmanMovePs,		//Move,
			SwordmanMovePs,		//GotoAttack,
			SwordmanAttackPs,	//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			NULL,				//BeBuilt,
			NULL,				//Produce,

			SwordmanDeadPs		//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			ManAcknowledgeSound,	//Selected,
			ManAcknowledgeSound,	//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NULL       ,		//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			EncounterEnemySound,	//EncounterEnemy,
			NULL		,			//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NULL       ,		//NoRoomForNewMobile,
									//EndLocalHint
			ManDeadSound,			//Died,
			NULL,					//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		SwordmanIconUI,	//HPICTURE	hIcon;

		BloodSlot24UI,	//HPICTURE	hBloodSlot;
		24,				//BYTE		byBloodSlotSegNum;
		Ellipse24,		//BYTE		byChoiceEllipseSize;
		SwordmanCorpse,	//ObjectKind	eCorpseKind;
		NullBombSmog,	//ObjectKind	eBombSmogKind;

		24,				//WORD		wBodyWidth;
		34,				//WORD		wBodyHeight;

		OneTileShape	//BuildingShapeKind eShapeKind;
	},

	//				Cavalry,
	{
		"���",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		7,				//BYTE		byNeedTech;
		0,				//BYTE		byProvideTech;
		310,			//WORD		wPrice;

		HeavySword,		//ObjectKind	eWeaponKind;
		3000,			//WORD		wHitpoint;
		YARD_PER_TILE / 6,//WORD		wSpeed;
		20,				//BYTE		wFireRate;
		2,				//BYTE		byTurnSpeed;
		7,				//BYTE		byEyeshot;
						
		NULL,						//WORD	wAbility;
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Cavalry,

		CAN_BUGOUT,		//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			LEGAL_STATE,	//Bugout,

			LEGAL_STATE,	//Pause,
			LEGAL_STATE,	//Move,
			LEGAL_STATE,	//GotoAttack,
			LEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			ILLEGAL_STATE,	//BeBuilt,
			ILLEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			CavalryStandbyPs,	//Standby,
			CavalryBugoutPs,	//Bugout,

			CavalryStandbyPs,	//Pause,
			CavalryMovePs,		//Move,
			CavalryMovePs,		//GotoAttack,
			CavalryAttackPs,	//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			NULL,				//BeBuilt,
			NULL,				//Produce,

			CavalryDeadPs		//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			CavalrySelectedSound,	//Selected,
			CavalryCmdReceivedSound,//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NULL       ,		//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			EncounterEnemySound,	//EncounterEnemy,
			NULL		,			//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NULL       ,		//NoRoomForNewMobile,
									//EndLocalHint
			CavalryDeadSound,		//Died,
			NULL,					//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		CavalryIconUI,	//HPICTURE	hIcon;

		BloodSlot32UI,	//HPICTURE	hBloodSlot;
		32,				//BYTE		byBloodSlotSegNum;
		Ellipse48,		//BYTE		byChoiceEllipseSize;
		CavalryCorpse,	//ObjectKind	eCorpseKind;
		NullBombSmog,	//ObjectKind	eBombSmogKind;

		40,				//WORD		wBodyWidth;
		50,				//WORD		wBodyHeight;

		OneTileShape	//BuildingShapeKind eShapeKind;
	},

	//				Crossbow,
	{
		"��",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		7,				//BYTE		byNeedTech;
		0,				//BYTE		byProvideTech;
		300,			//WORD		wPrice;

		HeavyArrow,		//ObjectKind	eWeaponKind;
		4000,			//WORD		wHitpoint;
		YARD_PER_TILE / 12,//WORD		wSpeed;
		50,				//BYTE		wFireRate;
		4,				//BYTE		byTurnSpeed;
		6,				//BYTE		byEyeshot;
						
		NULL, 						//WORD	wAbility;
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Workshop,

		CANNOT_BUGOUT,	//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			ILLEGAL_STATE,	//Bugout,

			LEGAL_STATE,	//Pause,
			LEGAL_STATE,	//Move,
			LEGAL_STATE,	//GotoAttack,
			LEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			ILLEGAL_STATE,	//BeBuilt,
			ILLEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			CrossbowStandbyPs,	//Standby,
			NULL,				//Bugout,

			CrossbowStandbyPs,	//Pause,
			CrossbowMovePs,		//Move,
			CrossbowMovePs,		//GotoAttack,
			CrossbowStandbyPs,	//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			NULL,				//BeBuilt,
			NULL,				//Produce,

			CrossbowDeadPs		//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			CrossbowSelectedSound,	//Selected,
			CrossbowCmdReceivedSound,//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NULL       ,		//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			EncounterEnemySound,	//EncounterEnemy,
			NULL		,			//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NULL       ,		//NoRoomForNewMobile,
									//EndLocalHint
			CrossbowDeadSound,		//Died,
			NULL,					//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		CrossbowIconUI,	//HPICTURE	hIcon;

		BloodSlot48UI,	//HPICTURE	hBloodSlot;
		48,				//BYTE		byBloodSlotSegNum;
		Ellipse48,		//BYTE		byChoiceEllipseSize;
		CrossbowCorpse,	//ObjectKind	eCorpseKind;
		NullBombSmog,	//ObjectKind	eBombSmogKind;

		56,				//WORD		wBodyWidth;
		26,				//WORD		wBodyHeight;

		OneTileShape	//BuildingShapeKind eShapeKind;
	},

	//		EndMobile,
	//		NullBuilding = EndMobile,
	{""},

	//			Tower,
	{
		"����",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		5,				//BYTE		byNeedTech;
		7,				//BYTE		byProvideTech;
		250,			//WORD		wPrice;

		LightArrow,		//ObjectKind	eWeaponKind;
		15000,			//WORD		wHitpoint;
		NULL,			//WORD		wSpeed;
		50,				//BYTE		wFireRate;
		NULL,			//BYTE		byTurnSpeed;
		12,				//BYTE		byEyeshot;
						
		NULL,						//WORD	wAbility;						
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Villager,

		CANNOT_BUGOUT,	//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			ILLEGAL_STATE,	//Bugout,

			ILLEGAL_STATE,	//Pause,
			ILLEGAL_STATE,	//Move,
			ILLEGAL_STATE,	//GotoAttack,
			LEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			LEGAL_STATE,	//BeBuilt,
			ILLEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			TowerPs,			//Standby,
			NULL,				//Bugout,

			NULL,				//Pause,
			NULL,				//Move,
			NULL,				//GotoAttack,
			TowerPs,			//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			Built2Ps,			//BeBuilt,
			NULL,				//Produce,

			NULL				//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			TowerSelectedSound,		//Selected,
			NULL       ,			//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NULL       ,		//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			EncounterEnemySound,	//EncounterEnemy,
			NULL		,			//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NULL       ,		//NoRoomForNewMobile,
									//EndLocalHint
			BuildingDeadSound,		//Died,
			BuildingHurtedSound,	//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		TowerIconUI,	//HPICTURE	hIcon;

		BloodSlot64UI,	//HPICTURE	hBloodSlot;
		64,				//BYTE		byBloodSlotSegNum;
		Ellipse96,		//BYTE		byChoiceEllipseSize;
		BuildingCorpse2,//ObjectKind	eCorpseKind;
		LittleBombSmog,	//ObjectKind	eBombSmogKind;

		72,				//WORD		wBodyWidth;
		96,				//WORD		wBodyHeight;

		Diamond2Shape	//BuildingShapeKind eShapeKind;
	},
	
	//			Town,
	{
		"����",			//char	sClassName[UNIT_CLASS_NAME_LEN];

		7,				//BYTE		byNeedTech;
		0,				//BYTE		byProvideTech;
		500,			//WORD		wPrice;

		NullWeapon,		//ObjectKind	eWeaponKind;
		20000,			//WORD		wHitpoint;
		NULL,			//WORD		wSpeed;
		NULL,			//BYTE		wFireRate;
		NULL,			//BYTE		byTurnSpeed;
		7,				//BYTE		byEyeshot;
						
		CUnit::CanStoreMoney, 		//WORD	wAbility;
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{Villager, NullMobile},		//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Villager,

		CANNOT_BUGOUT,	//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			ILLEGAL_STATE,	//Bugout,

			ILLEGAL_STATE,	//Pause,
			ILLEGAL_STATE,	//Move,
			ILLEGAL_STATE,	//GotoAttack,
			ILLEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			LEGAL_STATE,	//BeBuilt,

			LEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			TownPs,				//Standby,
			NULL,				//Bugout,

			NULL,				//Pause,
			NULL,				//Move,
			NULL,				//GotoAttack,
			NULL,				//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			Built3Ps,			//BeBuilt,
			TownPs,				//Produce,

			NULL				//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			TownSelectedSound,		//Selected,
			NULL       ,			//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NotEnoughMoneySound,	//NotEnoughMoney,

			
			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			NULL,					//EncounterEnemy,
			PopulationOverflowSound,//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NoRoomForNewMobileSound,//NoRoomForNewMobile,
									//EndLocalHint
			BuildingDeadSound,		//Died
			BuildingHurtedSound,	//HalfHurted
			NULL		,		//Repair,
			NULL		,		//Derepair,
			NULL				//Harvest,
		},

		TownIconUI,		//HPICTURE	hIcon;

		BloodSlot128UI,	//HPICTURE	hBloodSlot;
		128,			//BYTE		byBloodSlotSegNum;
		Ellipse192,		//BYTE		byChoiceEllipseSize;
		BuildingCorpse3,//ObjectKind	eCorpseKind;
		BigBombSmog,	//ObjectKind	eBombSmogKind;

		192,			//WORD		wBodyWidth;
		85,				//WORD		wBodyHeight;

		Diamond3Shape	//BuildingShapeKind eShapeKind;
	},

	//			Barrack,
	{
		"��Ӫ",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		0,				//BYTE		byNeedTech;
		5,				//BYTE		byProvideTech;
		400,			//WORD		wPrice;

		NullWeapon,		//ObjectKind	eWeaponKind;
		12000,			//WORD		wHitpoint;
		NULL,			//WORD		wSpeed;
		NULL,			//BYTE		wFireRate;
		NULL,			//BYTE		byTurnSpeed;
		7,				//BYTE		byEyeshot;
						
		NULL, 						//WORD	wAbility;						
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{Axeman, Swordman, NullMobile},	//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Villager,

		CANNOT_BUGOUT,	//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			ILLEGAL_STATE,	//Bugout,

			ILLEGAL_STATE,	//Pause,
			ILLEGAL_STATE,	//Move,
			ILLEGAL_STATE,	//GotoAttack,
			ILLEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			LEGAL_STATE,	//BeBuilt,

			LEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			BarrackPs,			//Standby,
			NULL,				//Bugout,

			NULL,				//Pause,
			NULL,				//Move,
			NULL,				//GotoAttack,
			NULL,				//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			Built3Ps,			//BeBuilt,
			BarrackPs,			//Produce,

			NULL				//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			BarrackSelectedSound,	//Selected,
			NULL       ,			//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NotEnoughMoneySound,	//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			NULL,					//EncounterEnemy,
			PopulationOverflowSound,//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NoRoomForNewMobileSound,//NoRoomForNewMobile,
									//EndLocalHint
			BuildingDeadSound,		//Died
			BuildingHurtedSound,	//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		BarrackIconUI,	//HPICTURE	hIcon;

		BloodSlot128UI,	//HPICTURE	hBloodSlot;
		128,			//BYTE		byBloodSlotSegNum;
		Ellipse192,		//BYTE		byChoiceEllipseSize;
		BuildingCorpse3,//ObjectKind	eCorpseKind;
		BigBombSmog,	//ObjectKind	eBombSmogKind;

		192,			//WORD		wBodyWidth;
		75,				//WORD		wBodyHeight;

		Diamond3Shape	//BuildingShapeKind eShapeKind;
	},

	//			Workshop,
	{
		"����",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		7,				//BYTE		byNeedTech;
		7,				//BYTE		byProvideTech;
		700,			//WORD		wPrice;

		NullWeapon,		//ObjectKind	eWeaponKind;
		16000,			//WORD		wHitpoint;
		NULL,			//WORD		wSpeed;
		NULL,			//BYTE		wFireRate;
		NULL,			//BYTE		byTurnSpeed;
		7,				//BYTE		byEyeshot;
						
		NULL, 						//WORD	wAbility;						
		CWorld::CPath::LandMovable,	//WORD	wMovable;

		{Crossbow, NullMobile},		//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Villager,

		CANNOT_BUGOUT,	//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			ILLEGAL_STATE,	//Bugout,

			ILLEGAL_STATE,	//Pause,
			ILLEGAL_STATE,	//Move,
			ILLEGAL_STATE,	//GotoAttack,
			ILLEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			LEGAL_STATE,	//BeBuilt,

			LEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			WorkshopPs,			//Standby,
			NULL,				//Bugout,

			NULL,				//Pause,
			NULL,				//Move,
			NULL,				//GotoAttack,
			NULL,				//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			Built3Ps,			//BeBuilt,
			WorkshopPs,			//Produce,

			NULL				//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			WorkshopSelectedSound,	//Selected,
			NULL       ,			//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NotEnoughMoneySound,	//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			NULL       ,		//EncounterEnemy,
			PopulationOverflowSound,//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NoRoomForNewMobileSound,//NoRoomForNewMobile,
									//EndLocalHint
			BuildingDeadSound,		//Died
			BuildingHurtedSound,	//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		WorkshopIconUI,	//HPICTURE	hIcon;

		BloodSlot128UI,	//HPICTURE	hBloodSlot;
		128,			//BYTE		byBloodSlotSegNum;
		Ellipse192,		//BYTE		byChoiceEllipseSize;
		BuildingCorpse3,//ObjectKind	eCorpseKind;
		BigBombSmog,	//ObjectKind	eBombSmogKind;

		192,			//WORD		wBodyWidth;
		96,				//WORD		wBodyHeight;

		Diamond3Shape	//BuildingShapeKind eShapeKind;
	},

	//			Stable,
	{
		"����",			//char	sClassName[UNIT_CLASS_NAME_LEN]

		5,				//BYTE		byNeedTech;
		7,				//BYTE		byProvideTech;
		700,			//WORD		wPrice;

		NullWeapon,		//ObjectKind	eWeaponKind;
		12000,			//WORD		wHitpoint;
		NULL,			//WORD		wSpeed;
		NULL,			//BYTE		wFireRate;
		NULL,			//BYTE		byTurnSpeed;
		7,				//BYTE		byEyeshot;
						
		NULL, 							//WORD	wAbility;						
		CWorld::CPath::LandMovable,		//WORD	wMovable;

		{Cavalry, NullMobile},			//ObjectKind	eProduceMobileKind[MAX_PRODUCE_NUM];
		Villager,

		CANNOT_BUGOUT,	//bool		bCanBugout;
						//bool		bLegalState[EndUnitState];
		{
			ILLEGAL_STATE,	//NullUnitState,

			LEGAL_STATE,	//Standby,
			ILLEGAL_STATE,	//Bugout,

			ILLEGAL_STATE,	//Pause,
			ILLEGAL_STATE,	//Move,
			ILLEGAL_STATE,	//GotoAttack,
			ILLEGAL_STATE,	//Attack,

			ILLEGAL_STATE,	//GotoRepair,
			ILLEGAL_STATE,	//Repair,
			ILLEGAL_STATE,	//GotoDerepair,
			ILLEGAL_STATE,	//Derepair,

			ILLEGAL_STATE,	//GotoHarvest,
			ILLEGAL_STATE,	//Harvest,
			ILLEGAL_STATE,	//GotoSave,
			ILLEGAL_STATE,	//Save,

			LEGAL_STATE,	//BeBuilt,

			LEGAL_STATE,	//Produce,

			LEGAL_STATE		//Dead,
		},
		
						//HPICTURE	hStatePicture[EndUnitState];
						//˵��������Goto״̬��ͼ������ΪNULL, ʹ��Move״̬��ͼ��
		{
			NULL,				//NullUnitState,

			StablePs,			//Standby,
			NULL,				//Bugout,

			NULL,				//Pause,
			NULL,				//Move,
			NULL,				//GotoAttack,
			NULL,				//Attack,

			NULL,				//GotoRepair,
			NULL,				//Repair,
			NULL,				//GotoDerepair,
			NULL,				//Derepair,
			NULL,				//GotoHarvest,
			NULL,				//Harvest,
			NULL,				//GotoSave,
			NULL,				//Save,

			Built3Ps,			//BeBuilt,
			StablePs,			//Produce,

			NULL				//Dead,
		},

						//HSOUND		hHintSound[EndUnitHint];
		{
			NULL,				//NullUnitHint = 0,

			NULL,					//GiveMoney
			UnitCreatedSound,		//Created,
			StableSelectedSound,	//Selected,
			NULL       ,			//CmdReceived,
			NULL       ,			//CmdCompleted,
			CmdAbortedSound,		//CmdAborted,
			NULL		,			//CmdCanceled,

			NotEnoughMoneySound,	//NotEnoughMoney,

			NULL       ,		//AssignMoveTarget,
			NULL       ,		//AssignAttackTarget,
			NULL       ,		//AssignBuildTarget,
			NULL       ,		//AssignRepairTarget,
			NULL       ,		//AssignDerepairTarget,
			NULL       ,		//AssignHarvestTarget,
			NULL       ,		//AssignSaveTarget,		
			NULL		,			//AssignRallyTarget,
			NULL       ,		//EncounterEnemy,
			PopulationOverflowSound,//MobileNumberOverflow,
			NULL		,			//BuildingNumberOverflow,
			NoRoomForNewMobileSound,//NoRoomForNewMobile,
									//EndLocalHint
			BuildingDeadSound,		//Died
			BuildingHurtedSound,	//HalfHurted
			NULL		,			//Repair,
			NULL		,			//Derepair,
			NULL					//Harvest,
		},

		StableIconUI,	//HPICTURE	hIcon;

		BloodSlot128UI,	//HPICTURE	hBloodSlot;
		128,			//BYTE		byBloodSlotSegNum;
		Ellipse192,		//BYTE		byChoiceEllipseSize;
		BuildingCorpse3,//ObjectKind	eCorpseKind;
		BigBombSmog,	//ObjectKind	eBombSmogKind;

		192,			//WORD		wBodyWidth;
		96,				//WORD		wBodyHeight;

		Diamond3Shape	//BuildingShapeKind eShapeKind;
	}

	//		EndBuilding,
	//	EndUnit = EndBuilding
};



/******************************/
/* ������������������������� */
/******************************/

CUnit::CmdAblInfo			CUnit::m_stAllCmdAblInfo[CUnit::EndCmdAblKind] =
{
	//NullCmdAblKind,
	{false},
	
	//CancelCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			CancelIconUI,		//HPICTURE	hIcon;
			'C',				//BYTE		byHotkey;
			CancelCmdAbl,		//WORD		wParam;
			"ȡ��(C)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			NullCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		SelectPreCmd,		//UnitPreCmdState	eTargetState;
		CmdCanceled			//UnitHintKind		eHintKind;
	},

	//MoveCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			MoveIconUI,			//HPICTURE	hIcon;
			'M',				//BYTE		byHotkey;
			MoveCmdAbl,			//WORD		wParam;
			"�ƶ�(M)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			MoveCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignMoveTarget	//UnitHintKind		eHintKind;
	},
	//AttackCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			AttackIconUI,		//HPICTURE	hIcon;
			'A',				//BYTE		byHotkey;
			AttackCmdAbl,		//WORD		wParam;
			"����(A)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			AttackCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignAttackTarget	//UnitHintKind		eHintKind;
	},

	//StopCmdAbl,
	{
		true,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			StopIconUI,			//HPICTURE	hIcon;
			'O',				//BYTE		byHotkey;
			StopCmdAbl,			//WORD		wParam;
			"ֹͣ(O)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			StopCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		NullPreCmdState,	//UnitPreCmdState	eTargetState;
		NullUnitHint		//UnitHintKind		eHintKind;
	},

	//BuildCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			BuildIconUI,		//HPICTURE	hIcon;
			'B',				//BYTE		byHotkey;
			BuildCmdAbl,		//WORD		wParam;
			"����(B)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			NullCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		BuildPreCmd,		//UnitPreCmdState	eTargetState;
		NullUnitHint		//UnitHintKind		eHintKind;
	},
	//RepairCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			RepairIconUI,		//HPICTURE	hIcon;
			'R',				//BYTE		byHotkey;
			RepairCmdAbl,		//WORD		wParam;
			"����(R)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			RepairCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignRepairTarget	//UnitHintKind		eHintKind;
	},
	/*
	//DerepairCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			DerepairIconUI,		//HPICTURE	hIcon;
			'D',				//BYTE		byHotkey;
			DerepairCmdAbl,		//WORD		wParam;
			"���(D)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			DerepairCmd,		//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignDerepairTarget//UnitHintKind		eHintKind;
	},
	*/
	//HarvestCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			HarvestIconUI,		//HPICTURE	hIcon;
			'H',				//BYTE		byHotkey;
			HarvestCmdAbl,		//WORD		wParam;
			"�ɼ�(H)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			HarvestCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignHarvestTarget	//UnitHintKind		eHintKind;
	},
	//SaveCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			SaveIconUI,			//HPICTURE	hIcon;
			'S',				//BYTE		byHotkey;
			SaveCmdAbl,			//WORD		wParam;
			"��Ǯ(S)",			//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			SaveCmd,			//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignSaveTarget	//UnitHintKind		eHintKind;
	},
	//SetRallyPtCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			SetRallyPtIconUI,	//HPICTURE	hIcon;
			'R',				//BYTE		byHotkey;
			SetRallyPtCmdAbl,	//WORD		wParam;
			"ָ�����ϵص�(R)",	//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			SetRallyPtCmd,		//CmdType	eType;
			NULL,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignRallyTarget	//UnitHintKind		eHintKind;
	},

	//CreateVillagerCmdAbl,
	{
		true,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			VillagerIconUI,		//HPICTURE	hIcon;
			'V',				//BYTE		byHotkey;
			CreateVillagerCmdAbl,//WORD		wParam;
			"ũ��(V: 125)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			ProduceCmd,			//CmdType	eType;
			Villager,			//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		SelectPreCmd,		//UnitPreCmdState	eTargetState;
		NullUnitHint			//UnitHintKind		eHintKind;
	},
	//CreateAxemanCmdAbl,
	{
		true,				//bool				bCmdFull;
		5,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			AxemanIconUI,		//HPICTURE	hIcon;
			'A',				//BYTE		byHotkey;
			CreateAxemanCmdAbl,	//WORD		wParam;
			"����(A: 135)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			ProduceCmd,			//CmdType	eType;
			Axeman,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		SelectPreCmd,		//UnitPreCmdState	eTargetState;
		NullUnitHint		//UnitHintKind		eHintKind;
	},
	//CreateSwordmanCmdAbl,
	{
		true,				//bool				bCmdFull;
		5,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			SwordmanIconUI,		//HPICTURE	hIcon;
			'S',				//BYTE		byHotkey;
			CreateSwordmanCmdAbl,//WORD		wParam;
			"����(S: 135)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			ProduceCmd,			//CmdType	eType;
			Swordman,			//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		SelectPreCmd,		//UnitPreCmdState	eTargetState;
		NullUnitHint		//UnitHintKind		eHintKind;
	},
	//CreateCavalryCmdAbl,
	{
		true,				//bool				bCmdFull;
		7,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			CavalryIconUI,		//HPICTURE	hIcon;
			'C',				//BYTE		byHotkey;
			CreateCavalryCmdAbl,//WORD		wParam;
			"���(C: 310)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			ProduceCmd,			//CmdType	eType;
			Cavalry,			//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		SelectPreCmd,		//UnitPreCmdState	eTargetState;
		NullUnitHint			//UnitHintKind		eHintKind;
	},
	//CreateCrossbowCmdAbl,
	{
		true,				//bool				bCmdFull;
		7,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			CrossbowIconUI,		//HPICTURE	hIcon;
			'B',				//BYTE		byHotkey;
			CreateCrossbowCmdAbl,//WORD		wParam;
			"��(B: 300)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			ProduceCmd,			//CmdType	eType;
			Crossbow,			//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		SelectPreCmd,		//UnitPreCmdState	eTargetState;
		NullUnitHint			//UnitHintKind		eHintKind;
	},

	//BuildTowerCmdAbl,
	{
		false,				//bool				bCmdFull;
		5,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			TowerIconUI,		//HPICTURE	hIcon;
			'T',				//BYTE		byHotkey;
			BuildTowerCmdAbl,	//WORD		wParam;
			"����(T: 250)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			BuildCmd,			//CmdType	eType;
			Tower,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignBuildTarget	//UnitHintKind		eHintKind;
	},
	//BuildTownCmdAbl,
	{
		false,				//bool				bCmdFull;
		7,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			TownIconUI,			//HPICTURE	hIcon;
			'N',				//BYTE		byHotkey;
			BuildTownCmdAbl,	//WORD		wParam;
			"����(N: 500)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			BuildCmd,			//CmdType	eType;
			Town,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignBuildTarget	//UnitHintKind		eHintKind;
	},
	//BuildBarrackCmdAbl,
	{
		false,				//bool				bCmdFull;
		0,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			BarrackIconUI,		//HPICTURE	hIcon;
			'B',				//BYTE		byHotkey;
			BuildBarrackCmdAbl,	//WORD		wParam;
			"����(B: 400)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			BuildCmd,			//CmdType	eType;
			Barrack,			//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignBuildTarget	//UnitHintKind		eHintKind;
	},
	//BuildWorkshopCmdAbl,
	{
		false,				//bool				bCmdFull;
		7,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			WorkshopIconUI,		//HPICTURE	hIcon;
			'W',				//BYTE		byHotkey;
			BuildWorkshopCmdAbl,	//WORD		wParam;
			"����(W: 700)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			BuildCmd,			//CmdType	eType;
			Workshop,			//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignBuildTarget	//UnitHintKind		eHintKind;
	},
	//BuildStableCmdAbl,
	{
		false,				//bool				bCmdFull;
		5,					//BYTE				byTechLevel;
							//CmdIcon			stCmdIcon;
		{
			StableIconUI,		//HPICTURE	hIcon;
			'S',				//BYTE		byHotkey;
			BuildTowerCmdAbl,	//WORD		wParam;
			"����(S: 700)",		//char		sComment[COMMAND_ICON_COMMENT_LEN];
			NULL,				//bool		bEnable;
		},
							//CmdInfo			stCmdInfo;
		{
			BuildCmd,			//CmdType	eType;
			Stable,				//WORD		wParam;
			NULL,				//DWORD		dwParam;
			NULL,				//bool		bFirstInGroup;
		},

		CancelPreCmd,		//UnitPreCmdState	eTargetState;
		AssignBuildTarget	//UnitHintKind		eHintKind;
	}
};

//�������൥Ԫ�����д���״̬�������������������������������������е��±�
CUnit::CmdAblKind	CUnit::m_stAllLeafClassCmdAblInfo[CUnit::EndUnit - CUnit::NullUnit][EndPreCmdState][CMD_ICON_MAX_NUM - 1] =
{
	//NullUnit = EndNature,
	//	NullMobile = NullUnit,
	{{NullCmdAblKind}},

	//Villager,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			MoveCmdAbl,
			BuildCmdAbl,
			RepairCmdAbl,
			//DerepairCmdAbl,
			HarvestCmdAbl,
			SaveCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{
			BuildBarrackCmdAbl,
			BuildStableCmdAbl,
			BuildWorkshopCmdAbl,
			BuildTownCmdAbl,
			BuildTowerCmdAbl,
			CancelCmdAbl,
			NullCmdAblKind
		}
	},

	//			Axeman,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			MoveCmdAbl,
			AttackCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//			Swordman,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			MoveCmdAbl,
			AttackCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//			Cavalry,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			MoveCmdAbl,
			AttackCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//			Crossbow,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			MoveCmdAbl,
			AttackCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//	EndMobile,
	//	NullBuilding = EndMobile,
	{NullCmdAblKind},

	//		Tower,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			AttackCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//		Town,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			CreateVillagerCmdAbl,
			SetRallyPtCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//		Barrack,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			CreateAxemanCmdAbl,
			CreateSwordmanCmdAbl,
			SetRallyPtCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//		Workshop,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			CreateCrossbowCmdAbl,
			SetRallyPtCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	},

	//		Stable,
	{	
		//NullPreCmdState,
		{NullCmdAblKind},

		//SelectPreCmd,
		{
			CreateCavalryCmdAbl,
			SetRallyPtCmdAbl,
			NullCmdAblKind
		},

		//CancelPreCmd,
		{
			CancelCmdAbl,
			NullCmdAblKind
		},

		//BuildPreCmd,
		{NullCmdAblKind}
	}
};


//������״����Ľ�����ĵ�שռ�þ���
CUnit::BuildingOccupyMatrix CUnit::m_stAllBuildingShape[EndBuildingShapeKind] =
{
	//	NullBuildingShapeKind,
	{{false}},

	//	OneTileShape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
	},

	//	Diamond1Shape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, true , true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
	},

	//	Diamond2Shape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, true , true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
	},

	//	Diamond3Shape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, true , true , false, false, false, false},
		{false, true , true , true , true , true , true , false, false},
		{false, false, false, true , true , false, false, false, false},
		{false, false, false, false, false, false, false, false, false},
	}
};


//������״����Ľ������ڽ���ʱ�ĵ�שռ�ô����
CUnit::BuildingOccupyMatrix CUnit::m_stAllBuildingBigShape[EndBuildingShapeKind] =
{
	//	NullBuildingShapeKind,
	{{false}},

	//	OneTileShape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, false, true , true , true , false, false, false},
		{false, false, false, true , true , true , false, false, false},
		{false, false, false, true , true , true , false, false, false},
		{false, false, false, false, false, false, false, false, false},
	},

	//	Diamond1Shape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, true , true , true , true , false, false, false},
		{false, false, true , true , true , true , false, false, false},
		{false, false, true , true , true , true , false, false, false},
		{false, false, false, false, false, false, false, false, false},
	},

	//	Diamond2Shape,
	{
		{false, false, false, false, false, false, false, false, false},
		{false, false, true , true , true , true , false, false, false},
		{false, false, true , true , true , true , false, false, false},
		{false, false, true , true , true , true , false, false, false},
		{false, false, false, false, false, false, false, false, false},
	},

	//	Diamond3Shape,
	{
		{false, false, true , true , true , true , false, false, false},
		{true , true , true , true , true , true , true , true , false},
		{true , true , true , true , true , true , true , true , false},
		{true , true , true , true , true , true , true , true , false},
		{false, false, true , true , true , true , false, false, false},
	}
};




