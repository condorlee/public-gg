/*=============================================================================
 * Name			: IwSession.h
 * Project		: IcyWeapon
 * Function		: ��Ϸ��������ͻ���֮��Ի��������ܶ���ͷ�ļ�
 * Abbreviation	: Dp	= DirectPlay
				: Pkg	= Package
				: Ex	= Excess
 * Programmed	: Li Wenbin
 * Date			: 1999/11/03
******************************************************************************/

#if !defined(AFX_IWSESSION_H__E6FA8552_918D_11D3_908D_0000E83EE37C__INCLUDED_)
#define AFX_IWSESSION_H__E6FA8552_918D_11D3_908D_0000E83EE37C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "dpinterface.h"
#include "Player.h"

// �������ݰ������ͺ�
#define		ST_NULL			0x0000
#define		ST_COMMAND		0x0001
#define		ST_GAMEINFO		0x0002
#define		ST_PLAYERACTION	0x0003
#define		ST_MESSAGE		0x0004

#define		SF_NULL			0x0000
#define		SF_INCOMPLETE	0x0001
#define		SF_PLAYERLEFT	0x0002
#define		SF_NEWHOST		0x0004
#define		SF_REPLY		0x0008
#define		SF_PAUSE		0x0010
#define		SF_GAMEMSG		0x0020

// �������ݰ������������ݵĴ�С
#define		MAX_EXDATASIZE	sizeof(HUNIT)*_MAX_SELECTIONS
#define		_MAX_SESSIONMSG	MAX_EXDATASIZE-1


// ����ѡ����ʵ���Ϸ
#define		ID_GAMESESSION0	0x1000
#define		ID_GAMESESSION1	0x1001
#define		ID_GAMESESSION2	0x1002
#define		ID_GAMESESSION3	0x1003
#define		ID_GAMESESSION4	0x1004
#define		ID_GAMESESSION5	0x1005
#define		ID_GAMESESSION6	0x1006
#define		ID_GAMESESSION7	0x1007
#define		ID_GAMESESSION8	0x1008
#define		ID_GAMESESSION9	0x1009

#define		ID_REFRESHSESSION	0x1010
#define		ID_CREATESESSION	0x1011

// ���˵���ID���б�
#define	ID_SINGLEPLAYER	0x0100
#define	ID_MULTIPLAYER	0x0101
#define	ID_EXITTOSYSTEM	0x0102


// ��������Ի���״̬�궨�� NetSession state = NS
#define		NS_DEFAULT			0x0000
#define		NS_GAMESTART		0x0001
#define		NS_GAMEREADY		0x0002


/**************************** class CIwSession ******************************/
class CIwSession : public CNetSession
{
///////////////////////////////////////////////////////////////////////////////
// ��ط��Ͱ��Ľṹ����հ����麯������
private:
	struct SSessionPkg		/* ��������Session֮���ͨ�Ű� */
	{
		DWORD		m_dwType; // LoWord Is Type, and HiWord Is Flags
		DWORD		m_dwSize;
		int	m_idBuilder;
		union
		{
			struct SCmdPkg
			{
				UNIT_COMMAND	m_oUnitCmd;
				DWORD			m_dwUnits;
			} m_oCmdPkg;
			SGameInfo	m_oGameInfo;
			UINT	m_uMsgLen;
		};
		DWORD	m_dwExData[1];
	};
	virtual void OnReceive( CDpInterface *pDpNet, UINT uMsgCount );
	void	SendNetMsg( char *pMsg );


///////////////////////////////////////////////////////////////////////////////
// Interface to MainFrame
public:
	bool	PutPlayerCmd( SPlayerCommand& playCmd, int& id );
	bool	GetPlayerCmd( SPlayerCommand& playCmd, int& id );
	bool	BeginGame( GVFID idType );
	void	EndGame( );

	void	OnDefeat( );
	void	OnVictory( );

	GVF_INLINE	void	OnLocalPlayerOver( );
	GVF_INLINE	void	Broadcast( );
	GVF_INLINE	void	SendToHost( );

	GVF_INLINE	SGameInfo*		GetGameInfo( );
	GVF_INLINE	UINT			GetGamePlayerCount();
	GVF_INLINE	DWORD			GetISState();
	GVF_INLINE	void			SetNetState( DWORD state, bool bSet = true );
	GVF_INLINE	void			PutNetMsg( SSessionPkg* pPkg );

public:
	CIwSession();
	virtual ~CIwSession();

///////////////////////////////////////////////////////////////////////////////
// NetSession Operations about Networks
protected:
	bool	CreateSession( );
	bool	JoinSession( UINT index );

private:
	SSessionPkg*	m_lpPkgBuffer[2][_MAX_PLAYERS];
	UINT			m_uCmdPkgCount;
	UINT			m_uCrntBufferNum;


	SGameInfo		m_oGameInfo;
	DWORD			m_dwISState;

// inline session operations
	GVF_INLINE	void			SetISState( DWORD dwState, bool bSet = true );
	GVF_INLINE	SSessionPkg*	GetSelfBuffer();
	GVF_INLINE	void			InitCmdPkg();
	GVF_INLINE	UINT			GetNextBuffer();
	GVF_INLINE	SSessionPkg*	GetFreeBuffer();
	// GVF_INLINE	void			IncreaseCmdPkg( int  id );
	// GVF_INLINE	void			DecreaseCmdPkg( int& id );

public:
	GVF_INLINE	bool			IsCmdPkgFull( );
};

/**************************** Inline Function ********************************/
GVF_INLINE CIwSession::SSessionPkg*		
	CIwSession::GetSelfBuffer()							{
	return m_lpPkgBuffer[m_uCrntBufferNum]
		[IwGetLocalID()];								}

GVF_INLINE void CIwSession::Broadcast()					{
	IwGetDpNet()->Broadcast( (SDpDataPkg *)
		GetSelfBuffer() );								}

// GVF_INLINE void CIwSession::SendToHost( )				{
// 	m_dpNet.Send( m_dpNet.GetHostID(),
//	m_lpPkgBuffer[m_idSelf]	->m_dwSize,
//	m_lpPkgBuffer[m_idSelf] );						}

GVF_INLINE DWORD CIwSession::GetISState( )				{
	return m_dwISState;									}

GVF_INLINE void CIwSession::SetISState(
	DWORD state, bool bSet )							{
	if( bSet ) m_dwISState |= state;
	else	m_dwISState &= ~state;						}

GVF_INLINE SGameInfo* CIwSession::GetGameInfo()			{
	return &m_oGameInfo;								}

GVF_INLINE void CIwSession::InitCmdPkg( )				{
	m_uCmdPkgCount = 0;
	for( UINT u0 = 0; u0 < 2; u0 ++ )
		for( UINT u1 = 0; u1 < _MAX_PLAYERS; u1 ++ )
		{
			m_lpPkgBuffer[u0][u1]->m_dwType = MAKELONG( 
				ST_NULL,SF_NULL );
			m_lpPkgBuffer[u0][u1]->m_dwSize = sizeof( 
				SSessionPkg );
		}
	m_uCrntBufferNum = 0;
}


GVF_INLINE UINT CIwSession::GetGamePlayerCount()		{
	return GetGameInfo()->uPlayers;					}

GVF_INLINE UINT CIwSession::GetNextBuffer()				{
	if( m_uCrntBufferNum == 0 ) return 1;
	else return 0;										}

GVF_INLINE CIwSession::SSessionPkg*  CIwSession::
	GetFreeBuffer()										{
	if( LOWORD (m_lpPkgBuffer[m_uCrntBufferNum]
		[IwGetLocalID()]->m_dwType ) == ST_NULL )
		return m_lpPkgBuffer[m_uCrntBufferNum]
			[IwGetLocalID()];
	else
		return m_lpPkgBuffer[GetNextBuffer()]
		[IwGetLocalID()];								}


GVF_INLINE bool CIwSession::IsCmdPkgFull()				{
	if( GetGameInfo()->nType == GI_MULTICOMPUTER )
	{
		UINT count = 0;
		for( UINT u = 0; u < _MAX_PLAYERS; u ++ )
			if( m_lpPkgBuffer[m_uCrntBufferNum][u] 
				->m_dwType != MAKELONG(ST_NULL,SF_NULL) )
				count ++;
		if( IwGetDpNet()->GetPlayers() <= count )
			return true;
		else return false;
	}	
	else
		return (m_uCmdPkgCount == GetGameInfo()->
			uPlayers? true:false );					}


/******************************** class CGameMenu ****************************/
class CSessionDlg : public CDialog
{
	DECLARE_DIALOG ( CSessionDlg );
protected:
	proc_function( OnCreate );
	proc_function( OnNotify );
	virtual	void OnDraw( );
	void	RefreshSession( );
};

/*************************** class CGameConfigDlg ****************************/
#define	ID_STARTGAME		0x0110
#define ID_IAMREADY			0x0111

class CGameConfigDlg : public CDialog
{
	friend CIwSession;
	DECLARE_DIALOG( CGameConfigDlg );

protected:
	proc_function( OnCreate );
	proc_function( OnTimer );
	virtual	void OnDraw( );

private:
	CIwSession* m_pSession;
};

#endif // !defined(AFX_NETSESSION_H__E6FA8552_918D_11D3_908D_0000E83EE37C__INCLUDED_)
