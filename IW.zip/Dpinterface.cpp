/*=============================================================================
 *
 *	File		: DpInterface.cpp
 *	Programmed	: Li Wenbin
 *
******************************************************************************/
#include <objbase.h>
#include <initguid.h>
#include "stdafx.h"

static	char	g_szDefaultSessionName[] = "Noname Session";
static	char	g_szDefaultPlayerName[] = "Noname Player";

static BOOL FAR PASCAL DirectPlayEnumConnectionsCallback(LPCGUID lpguidSP,
						LPVOID lpConnection, DWORD dwConnectionSize,
						LPCDPNAME lpName, DWORD dwFlags, LPVOID lpContext)
{
	if( IsEqualGUID( *lpguidSP, DPSPGUID_TCPIP ) )	/* �����TCP/IPЭ�� */
	{
		LPDIRECTPLAYLOBBYA	lpDirectPlayLobbyA = NULL; 
		HRESULT	hr = DP_OK;
		LPVOID& lpConnectionBuffer = *((LPVOID *)lpContext);
		ASSERT( lpConnectionBuffer == NULL );

		// make space for connection shortcut
		lpConnectionBuffer = GlobalAllocPtr(GHND, dwConnectionSize);
		if (lpConnectionBuffer == NULL)
			goto MEMORYALLOC_FAILURE;
		// store pointer to connection shortcut in combo box
		memcpy(lpConnectionBuffer, lpConnection, dwConnectionSize);

		hr = DirectPlayLobbyCreate(NULL, &lpDirectPlayLobbyA, NULL, NULL, 0);
		if( FAILED(hr) )
			goto CREATELOBBY_FAILURE;

		hr = DPERR_BUFFERTOOSMALL;
		while( hr == DPERR_BUFFERTOOSMALL )
		{
			hr = lpDirectPlayLobbyA->CreateAddress( DPSPGUID_TCPIP, DPAID_INet,
				NULL, 0, lpConnectionBuffer, &dwConnectionSize );
			if( hr == DPERR_BUFFERTOOSMALL )
			{
				if( lpConnectionBuffer )
					GlobalFreePtr( lpConnectionBuffer );
				lpConnectionBuffer = GlobalAllocPtr(GHND, dwConnectionSize);
			}
		}
		if( FAILED(hr) )
			goto CREATEADDRESS_FAILURE;
		lpDirectPlayLobbyA->Release();
		lpDirectPlayLobbyA = NULL;
		return FALSE;

CREATEADDRESS_FAILURE:
		lpDirectPlayLobbyA->Release();
CREATELOBBY_FAILURE:
		GlobalFreePtr( lpConnectionBuffer );
MEMORYALLOC_FAILURE:
		return(TRUE);
	}
	/* ��ǰ������������Э���ʵ�� */
    return (TRUE);
}


bool CDpInterface::OpenConnection( )
{
	if( GetDpState() != DPS_DEFAULT )
		return ( GetDpState() & DPS_NETVALID );
	// Create an IDirectPlay3 interface
	HRESULT hr;
	m_dwDpState = DPS_NETINVALID;
	hr = CoCreateInstance(	CLSID_DirectPlay, NULL, CLSCTX_INPROC_SERVER, 
							IID_IDirectPlay3A, (LPVOID*)&m_lpDirectPlay);
	if( FAILED(hr) )
		return false;

	// Enumerating and Initializing the service Providers.
	m_lpDirectPlay->EnumConnections(&DPAPP_GUID, 
		DirectPlayEnumConnectionsCallback, &m_lpConnection, 0);
	if( m_lpConnection == NULL )
		return false;

	if( FAILED( m_lpDirectPlay->InitializeConnection( m_lpConnection, 0 ) ) )
		return false;
	else
	{
		m_dwDpState = DPS_NETVALID;
		return true;
	}
}


static BOOL FAR PASCAL EnumSessionsCallback( LPCDPSESSIONDESC2	lpSessionDesc,
					LPDWORD lpdwTimeOut, DWORD dwFlags, LPVOID lpContext)
{
	// see if last session has been enumerated
    if (dwFlags & DPESC_TIMEDOUT)
		return (FALSE);

	/* ���ָ��Ի��������������ָ�� */
	ASSERT( lpContext );
	CDpInterface* pInterface = (CDpInterface *)lpContext;
	pInterface->AddSession( lpSessionDesc );
	return TRUE;
}

HRESULT CDpInterface::EnumSessions( )
{
	ASSERT( m_lpDirectPlay );
	ASSERT( m_lpConnection );

	DPSESSIONDESC2	sessionDesc;
	HRESULT			hr;

	// fill the Session Description correct value
	ZeroMemory(&sessionDesc, sizeof(DPSESSIONDESC2));
	sessionDesc.dwSize = sizeof(DPSESSIONDESC2);
    sessionDesc.guidApplication = DPAPP_GUID;

	RemoveAllSessions( );
	hr = DPERR_CONNECTING;
	while( hr == DPERR_CONNECTING )
	{
		hr = m_lpDirectPlay->EnumSessions(&sessionDesc, 0, EnumSessionsCallback,
			this, DPENUMSESSIONS_AVAILABLE | DPENUMSESSIONS_RETURNSTATUS );
	}
	return (hr);
}


void CDpInterface::GetSessions( LPSTR& lpSessionName, DWORD &dwCount )
{
	/* �о����е�Sessions */
	if( FAILED( EnumSessions( ) ) )
		throw EXCEPTION(ErrorEnumSessions);
	dwCount = m_dwSessionCount;
	if( dwCount > 0 )
		lpSessionName = &(m_szSessionName[0][0]);
	else
		lpSessionName = NULL;
}

int CDpInterface::CreateSession( LPSTR lpszSessionName, LPSTR lpszPlayerName  )
{
	DPNAME				dpName;
	DPSESSIONDESC2		sessionDesc;
	HRESULT				hr;
	DWORD				dwSize ;

	ASSERT( m_lpDirectPlay );
	// host a new session
	ZeroMemory(&sessionDesc, sizeof(DPSESSIONDESC2));
	sessionDesc.dwSize = sizeof(DPSESSIONDESC2);
    sessionDesc.dwFlags = DPSESSION_MIGRATEHOST | DPSESSION_KEEPALIVE;
    sessionDesc.guidApplication = DPAPP_GUID;
    sessionDesc.dwMaxPlayers = _MAX_PLAYERS;
	sessionDesc.dwHost = DPID_UNKNOWN;	/* ������ID�� */

	m_idSelf = 0;
	if( !lpszSessionName )
	{
		dwSize = _MAX_DPNAME;
		if( !GetComputerName( m_oPlayers[m_idSelf].m_szName, &dwSize ) )
			strcpy( m_oPlayers[m_idSelf].m_szName, g_szDefaultSessionName );
		lpszSessionName = m_oPlayers[m_idSelf].m_szName;
	}
	else
		strcpy( m_oPlayers[m_idSelf].m_szName, lpszSessionName );

	sessionDesc.lpszSessionNameA = lpszSessionName;

	hr = DPERR_CONNECTING;
	while( hr == DPERR_CONNECTING )
		hr = m_lpDirectPlay->Open(&sessionDesc, DPOPEN_CREATE|DPOPEN_RETURNSTATUS);

	if( FAILED(hr) )
			throw EXCEPTION( ErrorOpenSession );

	// fill out name structure
	ZeroMemory(&dpName, sizeof(DPNAME));
	dpName.dwSize = sizeof(DPNAME);
	if( !lpszPlayerName )
	{
		dwSize = _MAX_DPNAME;
		if( !GetUserName( m_oPlayers[m_idSelf].m_szName, &dwSize ) )
			strcpy( m_oPlayers[m_idSelf].m_szName, g_szDefaultPlayerName );
		lpszPlayerName = m_oPlayers[m_idSelf].m_szName;
	}
	else
		strcpy( m_oPlayers[m_idSelf].m_szName, lpszPlayerName );
	dpName.lpszShortNameA = lpszPlayerName;
	dpName.lpszLongNameA = NULL;

	// create a player with this name
	hr = m_lpDirectPlay->CreatePlayer(&(m_oPlayers[m_idSelf].m_dpID), &dpName, 
							m_hSelfEvent, NULL, 0, 0);
	if (FAILED(hr))
	{
		m_lpDirectPlay->Close();
		throw EXCEPTION( ErrorCreatePlayer );
	}
	SetHost();
	m_dwDpState |= DPS_HAVEPLAYER;
	return m_idSelf;
}


int CDpInterface::JoinSession( UINT index, LPSTR lpszPlayerName )
{
	ASSERT( index < m_dwSessionCount );

	DPNAME				dpName;
	DPSESSIONDESC2		sessionDesc;
	HRESULT				hr;
	DWORD				dwSize ;


	// join existing session
	ZeroMemory(&sessionDesc, sizeof(DPSESSIONDESC2));
	sessionDesc.dwSize = sizeof(DPSESSIONDESC2);
    sessionDesc.guidInstance = m_aSessionGUID[index];
	// m_idSelf = GetSessionDesc()->dwCurrentPlayers;

	hr = m_lpDirectPlay->Open(&sessionDesc, DPOPEN_JOIN);
	if FAILED(hr)
		throw EXCEPTION( ErrorOpenSession );

	if( lpszPlayerName == NULL )
	{
		dwSize = _MAX_DPNAME;
		if( !GetUserName( m_oPlayers[m_idSelf].m_szName, &dwSize ) )
			strcpy( m_oPlayers[m_idSelf].m_szName, g_szDefaultPlayerName );
		lpszPlayerName = m_oPlayers[m_idSelf].m_szName;
	}
	else
		strcpy( m_oPlayers[m_idSelf].m_szName, lpszPlayerName );

	// fill out name structure
	ZeroMemory(&dpName, sizeof(DPNAME));
	dpName.dwSize = sizeof(DPNAME);
	dpName.lpszShortNameA = lpszPlayerName;
	dpName.lpszLongNameA = NULL;

	// create a player with this name
	ASSERT( m_hSelfEvent );
	hr = m_lpDirectPlay->CreatePlayer( &(m_oPlayers[m_idSelf].m_dpID), &dpName, 
							m_hSelfEvent, NULL, 0, 0);
	if FAILED(hr)
	{
		m_lpDirectPlay->Close();
		throw EXCEPTION( ErrorCreatePlayer );
	}
	m_idSelf = GetSessionDesc()->dwCurrentPlayers-1;
	m_oPlayers[m_idSelf] = m_oPlayers[0];

	// return connection info
	m_dwDpState |= DPS_HAVEPLAYER;
	return m_idSelf;
}

void CDpInterface::LeaveSession( )
{
	HRESULT hr;
	hr = m_lpDirectPlay->DestroyPlayer( GetSelfDPID() );
	if( FAILED(hr) )
		throw EXCEPTION( ErrorDestroyPlayer );

	m_dwDpState &= ~DPS_HAVEPLAYER;
	m_idSelf = 0;

	/* ȡ��Session����������Ϣ */
	if( GetSessionDesc()->dwCurrentPlayers == 0 )
		m_lpDirectPlay->Close();
}


void CDpInterface::CloseConnection( )
{
	if( m_lpDirectPlay )
	{
		m_lpDirectPlay->Release();
		m_lpDirectPlay = NULL;
	}
	if( m_lpConnection )
	{
		GlobalFreePtr( m_lpConnection );
		m_lpConnection = NULL;
	}
	m_dwDpState = DPS_DEFAULT;
}

///////////////////////////////////////////////////////////////////////////////
// Message Management
bool CDpInterface::DpSend( DPID idTo, DWORD dwSize, LPVOID lpData )
{
	// TRACE2( "Send: Size:%X, Type:%X!\xD\xA",dwSize, *((DWORD*)lpData) );
	ASSERT( GetDpState() & DPS_HAVEPLAYER );
	HRESULT hr;
	hr = m_lpDirectPlay->Send( GetSelfDPID(), idTo, 0, lpData, dwSize );
	if( FAILED(hr) )
		throw EXCEPTION( ErrorOnSend );
	return true;
}

bool CDpInterface::DpReceive( DPID& idFrom, DWORD &dwSize, LPVOID& lpData )
{
	ASSERT( GetDpState() & DPS_HAVEPLAYER );

	DPID idTo;	
	HRESULT hr;DWORD dwDataSize;
	DWORD	dwFlags = DPRECEIVE_ALL;

	while( true )
	{
		dwDataSize = m_dwBufferSize;
		if( idFrom != DPID_UNKNOWN )
			dwFlags |= DPRECEIVE_FROMPLAYER;
		hr = m_lpDirectPlay->Receive( &idFrom, &idTo,
			dwFlags, m_lpReceiveBuffer, &dwDataSize );

		// ���������̫С�Ļ�,�������
		if( FAILED(hr) )
		{
			if( hr == DPERR_BUFFERTOOSMALL )
			{
				// Resize the buffer;
				if( m_lpReceiveBuffer )
				{
					GlobalFreePtr(m_lpReceiveBuffer);
					m_lpReceiveBuffer = NULL;
				}
				m_lpReceiveBuffer =(LPBYTE)GlobalAllocPtr( GHND, dwDataSize );
				if( !m_lpReceiveBuffer )
					throw EXCEPTION( InsufficientMemory );
				m_dwBufferSize = dwDataSize;
				ASSERT( false );
				continue;
			}
			else if( hr == DPERR_NOMESSAGES )
			{
				// �� DirectPlay Com Object �����еĻ���
				// Sleep(1);
				return false;
			}
			else  // throw Exception 
				throw EXCEPTION( ErrorOnReceive );
		}

		// Process SysMsg by itself.
		if( idFrom == DPID_SYSMSG )
		{
			HandleSysMsg( (LPDPMSG_GENERIC)m_lpReceiveBuffer );
			printl("Handle A DirectPlay System Message: 0x%08X",*((DWORD*)m_lpReceiveBuffer) );
			continue;
		}
		else break;
	} // End while

	/* ���ܳ����Լ������ݰ� */
	dwSize = dwDataSize;
	lpData = m_lpReceiveBuffer;
	// TRACE2( "Receive: Size:%X, Type:%X\xD\xA",dwDataSize, *((DWORD*)lpData) );
	return true;
}

void CDpInterface::HandleSysMsg( LPDPMSG_GENERIC lpMsg )
{
	if( lpMsg->dwType == DPSYS_HOST )
		SetHost();

/*	switch( lpMsg->dwType )
	{
	case DPSYS_HOST:
	{
		DPSESSIONDESC2* pDesc = GetSessionDesc( );
		pDesc->dwHost = m_IDSelf;
		m_IDHost = m_IDSelf;
		m_lpDirectPlay->SetSessionDesc( pDesc, 0 );
		break;
	}
	case DPSYS_SETSESSIONDESC:
		LPDPMSG_SETSESSIONDESC lpSetSD = (LPDPMSG_SETSESSIONDESC) lpMsg;
		m_IDHost = lpSetSD->dpDesc.dwHost;
		ASSERT( m_IDHost != DPID_UNKNOWN );
		break;
	} */
}
///////////////////////////////////////////////////////////////////////////////
// DpInterface Helper Function
void	CDpInterface::AddSession( LPCDPSESSIONDESC2 lpSessionDesc )
{
	if( m_dwSessionCount >= _MAX_SESSIONS )
		return;
	m_aSessionGUID[m_dwSessionCount] = lpSessionDesc->guidInstance;
	strcpy( m_szSessionName[m_dwSessionCount], lpSessionDesc->lpszSessionNameA );
	m_dwSessionCount ++;
}


DPSESSIONDESC2*	CDpInterface::GetSessionDesc( void )
{
	ASSERT( m_lpDirectPlay );
	ASSERT( m_lpConnection );
	ASSERT( m_lpSessionDesc );

	DWORD dwSize = _MAX_SESSIONDESC_SIZE;
	HRESULT hr = DP_OK;
	do{
		hr = m_lpDirectPlay->GetSessionDesc( m_lpSessionDesc, &dwSize );
		if( FAILED(hr) )
		{
			if( hr == DPERR_BUFFERTOOSMALL )
			{
				GlobalFreePtr( m_lpSessionDesc );
				m_lpSessionDesc = (DPSESSIONDESC2 *)GlobalAllocPtr( GHND, dwSize );
				if( !m_lpSessionDesc )
					throw EXCEPTION( InsufficientMemory );
				ASSERT( false );
			}
			else throw EXCEPTION( GenericException );
		}
	}while( FAILED(hr) );
	return m_lpSessionDesc;
}


///////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
CDpInterface::CDpInterface()
{
	m_idSelf = 0;
	m_lpDirectPlay = NULL;
	m_lpConnection = NULL;
	m_dwSessionCount = 0;
	m_dwDpState = DPS_DEFAULT;
	for( UINT u = 0; u < _MAX_PLAYERS; u ++ )
	{
		m_oPlayers[u].m_dpID = DPID_UNKNOWN;
		m_oPlayers[u].m_szName[0] = '\x0';
	}

	m_lpSessionDesc =(DPSESSIONDESC2 *)GlobalAllocPtr( GHND,_MAX_SESSIONDESC_SIZE );
	m_lpReceiveBuffer = (LPBYTE)GlobalAllocPtr( GHND, _MAX_BUFFERSIZE );
	if( !(m_lpSessionDesc && m_lpReceiveBuffer) )
		throw EXCEPTION( InsufficientMemory );
	m_dwBufferSize = _MAX_BUFFERSIZE;
	m_hSelfEvent = CreateEvent(	NULL,		// no security
								FALSE,		// auto reset
								FALSE,		// initial event reset
								NULL);		// no name
	if( !m_hSelfEvent )
		throw EXCEPTION( ErrorCreateEvent );
}

CDpInterface::~CDpInterface()
{
	CloseConnection( );
	if( m_lpSessionDesc )
	{
		GlobalFreePtr( m_lpSessionDesc );
		m_lpSessionDesc = NULL;
	}
	if( m_lpReceiveBuffer )
	{
		GlobalFreePtr( m_lpReceiveBuffer );
		m_lpReceiveBuffer = NULL;
	}
	CloseHandle( m_hSelfEvent );
}