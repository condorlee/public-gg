/*=============================================================================
 * Name			: player.cpp
 * Project		: IcyWeapon
 * Function		: ���������ʵ���ļ�
 * Abbreviation	:
 * Programmed	: Li Wenbin 1999/09/20
******************************************************************************/

#include "stdafx.h"
#include "Player.h"
#include "MainFrame.h"

/******************************* class CPlayer *******************************/
///////////////////////////////////////////////////////////////////////////////
// Command Entries
void CPlayer::OnUnitCreated(HUNIT hUnit, DWORD dwParam)
{
}


void CPlayer::OnUnitDead( HUNIT hUnit, DWORD dwParam )
{
	// ��ѡ�е�Ԫ��ȥ��
	UINT u = 0;
	if( GetUnit(hUnit)->IsSelected() )
	{
		for( u = 0; u < m_uSelectedCount; u ++ )
			if( m_hSelected[u] == hUnit )
			{
				m_hSelected[u] = m_hSelected[m_uSelectedCount-1];
				m_uSelectedCount --;
				GetUnit( hUnit )->SetSelect( false,false ); // ȡ����Ԫ��ѡ��
				break;
			}
		ASSERT( !GetUnit(hUnit)->IsSelected() ); //��Ȼ�ܹ��ҵ������Ԫ
	}

#ifdef	_DEBUG
	else
	{
		for( u = 0; u < m_uSelectedCount; u ++ )
			if( m_hSelected[u] == hUnit )
				ASSERT( false ); // ��Ӧ����ѡ�����г���
	}
#endif

	// �ӱ�����ȥ��
	RemoveGroupUnit( hUnit );
}

///////////////////////////////////////////////////////////////////////////////
// Helper Function
void CPlayer::RemoveGroupUnit( HUNIT hUnit )
{
	GROUPID id = GetUnit( hUnit )->GetGroupId( );
	if( id != INVALID_GROUPID )
	{
		// �Ӹ�����ȥ��
		ASSERT( m_uGroupCount[id] > 0 );
		// �����ҵ�
		for( UINT u = 0; u < m_uGroupCount[id]; u ++ )
			if( GetGroup( id )[u] == hUnit )
				break;
		// ��Ȼ��Ӧ�����ҵõ�
		ASSERT( u < m_uGroupCount[id] );
		//�����һ����Ԫ�ĳ����еĵ�һ����Ԫ
		*(GetGroup(id)+u) = *(GetGroup(id)+m_uGroupCount[id]-1);
		m_uGroupCount[id] --;
		GetUnit( hUnit ) -> SetGroupId( INVALID_GROUPID );
	}
}


void CPlayer::SetGroup( GROUPID id, UINT uCount, HUNIT hUnits[] )
{
	// ���������ǰ��
	UINT u ;
	for( u = 0; u < m_uGroupCount[id]; u ++ )
		GetUnit( m_hGroups[id][u] ) -> SetGroupId( INVALID_GROUPID );
	m_uGroupCount[id] = 0;

	for( u = 0; u < uCount; u ++ )
	{
		RemoveGroupUnit( hUnits[u] );
		m_hGroups[id][m_uGroupCount[id]] = hUnits[u];
		m_uGroupCount[id] ++;
		GetUnit( hUnits[u] ) -> SetGroupId( id );
	}
}

void CPlayer::SelectUnits( RECT srect, bool bSelectComplete )
{
	// ���ԭ����ѡ�е�Ԫ
	for( UINT u = 0; u < m_uSelectedCount; u ++ )
		GetUnit( m_hSelected[u] )->SetSelect( false, false );

	m_uSelectedCount = CWorld::SelectUnits(srect, m_hSelected);

	for( u = 0; u < m_uSelectedCount; u ++ )
		GetUnit( m_hSelected[u] )->SetSelect( true, (u == 0) && bSelectComplete );
}

///////////////////////////////////////////////////////////////////////////////
// Construction/Destruction
CPlayer::CPlayer()
{
	// Init the Unit array.
	m_uSelectedCount = 0;
	for( UINT u = 0; u < _MAX_SELECTIONS; u ++ )
		m_hSelected[u] = NULL;

	// Init the Group Array;
	for( u = 0; u < _MAX_GROUPS; u ++ )
	{
		m_hGroups[u][0] = INVALID_HUNIT;
		m_uGroupCount[u] = 0;
	}
}

/******************************* class CHumanPlayer **************************/
///////////////////////////////////////////////////////////////////////////////
// Unit Selection
void CHumanPlayer::OnSelect( DWORD dwKeyState, RECT rect )
{
	SelectUnits( rect, !(dwKeyState&MK_LBUTTONDOWN) );
}


///////////////////////////////////////////////////////////////////////////////
// Command Entries
bool CHumanPlayer::OnKeyDown( DWORD dwKeyState, WPARAM vk )
{
	if( vk >= '0' && vk <= '9' )
	{
		UINT uCount, u;
		HUNIT* phUnit;

		if( dwKeyState & MK_CTRLDOWN )
		{
			if( GetSelectCount() <= 0 ) return true;
			if( GetUnit(*GetSelect() ) -> GetUnitSide() != GetPlayerID() )
				return true;
			if( GetSelectCount() )
				SetGroup( vk-'0', GetSelectCount(), GetSelect() );
			return true;
		}
		else
		{
			phUnit = GetGroup( vk-'0', &uCount );
			if( uCount <= 0 ) return true;

			if( !(dwKeyState&MK_SHIFTDOWN) )
			{	
				// ������е�ѡ�е�Ԫ
				for( u = 0; u < GetSelectCount(); u ++ )
					GetUnit( *( GetSelect()+u ) ) -> SetSelect(false,false);
				m_uSelectedCount = 0;
			}
			else 
			{
				// ȥ������ѡ�е���ͬ�ĵ�Ԫ
				for( u = 0; u < m_uSelectedCount; u ++ )
				{
					if( GetUnit( *(GetSelect()+u) )->GetGroupId() == 
						(GROUPID)(vk-'0') )
					{
						GetUnit( *(GetSelect()+u) )->SetSelect( false,false );
						*(GetSelect()+u) = *(GetSelect()+m_uSelectedCount-1);
						m_uSelectedCount --;
						u --; //��鱻�û��������ǲ��Ǿ�����ͬ�����
					}
				}
			}

			// �����еĵ�Ԫ���ӵ���ѡ�е�Ԫ��
			for( u = 0; u < uCount; u ++ )
			{
				ASSERT( GetUnit( *(phUnit+u) )->GetGroupId() ==
					(GROUPID)(vk-'0') );
				GetUnit( *(phUnit+u) ) -> SetSelect( true, 
					m_uSelectedCount == 0 );
				*( GetSelect()+m_uSelectedCount ) = *(phUnit+u);
				m_uSelectedCount ++;
			}

			// ���ALT�������µĻ�
			if( dwKeyState&MK_ALTDOWN )
			{
				int x = 0, y = 0;
				POINT pt;
				for( u = 0; u < m_uSelectedCount; u ++ )
				{
					pt = GetUnit( m_hSelected[u] ) -> GetTileCoord( );
					x += pt.x; y += pt.y;
				}
				x /= u; y /= u;
				IwGetMainFrame()->SetCenterTile( WORD_CO(x,y) );
			}
		} // End else
		return true;
	}
	else if( vk == ' ' )
	{
		// ����������
		IwGetMainFrame()->SetCenterTile( GetNextTown() );
		return true;
	}
	else return false;
}


bool CHumanPlayer::MsgProc(  MSG& msg, DWORD dwMKState, SPlayerCommand& playerCmd )
{
	ASSERT( !(dwMKState & MK_LBUTTONDOWN) );	// ȷ�����û�б�����
	// ��ʼ������
	playerCmd.m_oUnitCmd.eType =CUnit::NullCmd;
	playerCmd.m_uDestCount  = 0;
	m_nCursorType = CCursor::CommonCursor;
	CCursor::CursorKind nType = m_nCursorType;


	if( m_uSelectedCount <= 0 )	return false;
	if( GetUnit( m_hSelected[0] )->GetUnitSide() != GetPlayerID() )
		return false;	// ѡ�й��ӵĵ�Ԫ.
	bool bExecute = false;

	if( msg.message == VM_ICONCLK )
	{
		bExecute = true;
		for( UINT i = 0; i < m_uSelectedCount; i ++ )
		{
			if( !(GetUnit( m_hSelected[i] )->OnIconClick( msg.wParam, playerCmd.m_oUnitCmd)) )
				bExecute = false;
		}
		if( playerCmd.m_oUnitCmd.eType != CUnit::NullCmd && bExecute )
		{
			playerCmd.m_uDestCount = m_uSelectedCount;
			for( UINT u = 0; u < m_uSelectedCount; u ++ )
				playerCmd.m_hDestUnits[u] = m_hSelected[u];
		}
		else 
			playerCmd.m_uDestCount = 0;
		return true;
	}
	else 
	{
		CUnit::MsgInfo msgInfo;
		msgInfo.dwMKState = dwMKState;
		msgInfo.ptCursor = msg.pt;

		UNIT_COMMAND unitCmd;
		unitCmd.eType = CUnit::NullCmd;

		if( msg.message == WM_RBUTTONDOWN )
			bExecute = true;
		for( UINT u = 0; u < m_uSelectedCount; u ++ )
		{
			if( u == 0 )
				msgInfo.bFirstInGroup = true;
			else
				msgInfo.bFirstInGroup = false;
			if( !(GetUnit( m_hSelected[u] )->GetMsgCmd( msgInfo, unitCmd, bExecute,
				nType )) )
				unitCmd.eType = CUnit::NullCmd;

			ASSERT_RANGE(nType, CCursor::NullCursorKind, 
				CCursor::EndCursorKind);

			if( unitCmd.eType == CUnit::NullCmd ) continue;
			// ��һ����������ĵ�Ԫ.
			if( playerCmd.m_oUnitCmd.eType == CUnit::NullCmd )
			{
				playerCmd.m_oUnitCmd = unitCmd;
				playerCmd.m_uDestCount ++;
				playerCmd.m_hDestUnits[playerCmd.m_uDestCount-1] = m_hSelected[u];
				m_nCursorType = nType;

			}
			else if( unitCmd.eType == playerCmd.m_oUnitCmd.eType )
			{
				playerCmd.m_uDestCount ++;
				playerCmd.m_hDestUnits[playerCmd.m_uDestCount-1] = m_hSelected[u];
			}
			else;
		}
		if( !bExecute )
		{
			// �����������
			playerCmd.m_uDestCount = 0;
			playerCmd.m_oUnitCmd.eType = CUnit::NullCmd;
		}
		return true;
	}
	return true;
}

///////////////////////////////////////////////////////////////////////////////
// Command Icons
bool CHumanPlayer::GetCmdIcons( UINT& uCount,  SCmdIcon  aCmds[] )
{
	uCount = 0;
	if( m_uSelectedCount <= 0 )	return false;
	if( GetUnit( m_hSelected[0] )-> GetUnitSide() != GetPlayerID() ) 
		return false;
	else 
	{
		// ȡ���е�Ԫ��ͬ��CmdIcon
		SCmdIcon	cmds[_MAX_CMDICONS];
		UINT		uNum = 0;
		UINT		uValid[ _MAX_CMDICONS ];	/* �иõ�Ԫ����Ч�ļ��� */
		UINT		i,j;
		for( UINT u = 0; u < _MAX_CMDICONS; u++ )
			uValid[u] = 0;

		for( u = 0; u < m_uSelectedCount; u ++ )
		{
			if( u == 0 )
			{
				GetUnit( m_hSelected[u] ) -> GetCmdIcon( (int &)uCount, aCmds );
				for( i = 0; i < uCount; i ++ )	uValid[i] ++;
			}
			else
			{
				GetUnit( m_hSelected[u] ) -> GetCmdIcon( (int &)uNum, cmds );
				for( j = 0; j < uNum; j ++ )
					for( i = 0; i < uCount; i ++ )
					{
						/* �����������ͬ��ICON, ����ѭ���Լӿ��ٶ� */
						if( memcmp(&cmds[j], &aCmds[i], sizeof(SCmdIcon)) == 0){
							uValid[i] ++;
							break;
						}							
					}
			}			
		}
		// �ռ���ͬ��ICON
		i = 0;
		for( u = 0; u < uCount; u ++ )
		{
			if( uValid[u] == m_uSelectedCount )
			{
				aCmds[i] = aCmds[u];
				i ++;
			}
		}
		/* ��Ч��ICONS�� */
		uCount = i;		
		return true;
	}
}


