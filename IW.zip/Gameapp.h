/*=============================================================================
 * Name			: GameApp.h
 * Project		: IcyWeapon
 * Function		: ��Ϸ���������ͷ�ļ�.
 * Abbreviation	: GVF	Game View Frame
				: VT	View Message Type
 * Programmed	: Li Wenbin 1999/09/20
******************************************************************************/

#if !defined(AFX_GAMEAPP_H__E41362EF_FC91_4626_A90A_D992EAE865D9__INCLUDED_)
#define AFX_GAMEAPP_H__E41362EF_FC91_4626_A90A_D992EAE865D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#if !defined( _WINDOWS_ )
#include <windows.h>
#endif

#include "Exception.h"
#ifndef	ASSERT
#define	ASSERT		_ASSERT
#endif

#define	GVF_INLINE	__inline

/************************* GVF Messages **************************************/
#define	INVALID_MESSAGE		WM_NULL
// ����GVF Message����Ϣ����
typedef	UINT	VMT;
#define	VT_INVALID	0
#define	VT_CONTROL	1
#define	VT_MOUSE	2
#define	VT_KEYBOARD	3

// ��Ϸ���ڵ�״̬��
#define	VS_DEFAULT		0x0000	// ����ʱ���ڵ�״̬
#define	VS_CLOSE		0x0001	// �����Ѿ����ر�
#define	VS_HIDE			0x0002	// ���ڱ�����
#define	VS_VALIDPAINT	0x0004  // ���ڵ���ʾ������Ч
#define	VS_DISABLE		0x0008	// ���ڱ���ֹ, ���ÿؼ���
#define	VS_DYNAMIC		0x0010	// �����Ƕ�̬����

// VM Message
#define	VM_FIRST	WM_USER+1

#define	VM_ICONCLK	VM_FIRST+1	// �������е�CMDICON������
#define	VM_TIMER	VM_FIRST+2	// ��ʱ��Ϣ
#define	VM_CREATE	VM_FIRST+3	// ����һ���µ��Ӵ�
#define	VM_DESTROY	VM_FIRST+4	// �ͷ�һ���Ӵ�
#define	VM_PAINT	VM_FIRST+5	// ˢ���Ӵ�
#define	VM_NOTIFY	VM_FIRST+7	// wParam = Control ID
#define	VM_NETAWAKE	VM_FIRST+8	// ���������Ϣ����
#define	VM_QUIT		VM_FIRST+9	// ��Alt_F4�������ر�Ӧ�ó���

#define	VM_LAST		VM_QUIT

// Macro
#define	_MAX_VM_COUNT	(VM_LAST - VM_FIRST + 1)
#define GET_VMPOS( uMsg )	( uMsg - VM_FIRST )

#define	_MAX_KM_COUNT	(WM_KEYLAST - WM_KEYFIRST + 1)
#define GET_KMPOS( uMsg )	( uMsg - WM_KEYFIRST )

#define	_MAX_MM_COUNT	(WM_MOUSELAST - WM_MOUSEFIRST + 1)
#define GET_MMPOS( uMsg )	( uMsg - WM_MOUSEFIRST )

/****************************** GVF Overview *********************************/
class CGameApp;
GVF_INLINE	CGameApp*	GetApp();

struct CViewClass;

class CView;

class CFrame;
class CDialog;

class CControl;
class CButton;
class CCmdIcon;

typedef	UINT		HVIEW;
typedef	WPARAM		GVFID;
#define	INVALID_ID	UINT_MAX
#define	ID_CANCEL	0
#define	ID_OK		1

	
#define	_MAX_VIEW_COUNT			200
#define	_MAX_CHILD_VIEW_COUNT	50
#define	INVALID_HVIEW			0
#define	FIRST_HVIEW				1
#define	LAST_HVIEW				_MAX_VIEW_COUNT-1
#define	IS_VALIDHVIEW(hView)	((hView)>=FIRST_HVIEW&&(hView)<=LAST_HVIEW? \
									true:false)

#define	GameMain				WinMain
/****************************** class CNetSession ****************************/
class CDpInterface;
// Abstract class and only provide a interface
class CNetSession
{
public:
	virtual void OnReceive( CDpInterface* pDpNet, UINT MsgCount )=0;
};

/***************************** class CGameApp ********************************/
class CGameApp  
{
friend int WINAPI GameMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPTSTR lpCmdLine, int nCmdShow);
friend	CGameApp *GetApp();

///////////////////////////////////////////////////////////////////////////////
// Interface for Derived Class
protected:
	virtual	bool	InitInstance();
	virtual	bool	DestroyInstance();

	virtual	bool	InitGame();
	virtual	bool	StartGame();
	virtual	bool	DestroyGame();
	virtual	bool	ActivateApp( bool bActive );

	virtual	void	ForceQuit( );

public:
	virtual	void	RefreshScreen( ) = 0;
	virtual	void	OnViewValidate( HVIEW hView ); 

// Windows Application Data
protected:
	LPCSTR		m_lpszClassName;
	LPCSTR		m_lpszTitle;
	UINT		m_uIconID;
	UINT		m_uCursorID;

///////////////////////////////////////////////////////////////////////////////
// Views Management
public:
	CView*	CreateView( CView* pView = NULL,CViewClass *pClass = NULL,
		RECT *pRect = NULL, CFrame *pFather = NULL ); // ǰ������������һ��Ϊ����

	bool	DestroyView( CView *pView );
	bool	ActiveView( CView*	pView );
	void	SetCaptureView( HVIEW hView, bool bSet = true );

	GVF_INLINE	CView*	GetActiveView( );
	GVF_INLINE	CView*	GetView( HVIEW hView );
	GVF_INLINE	bool	SendGvfMsg( HVIEW hView, MSG& msg );
	GVF_INLINE	bool	SendGvfMsg( HVIEW hView, UINT message, WPARAM wParam = 0, LPARAM lParam = 0 );
	GVF_INLINE	bool	SendGroupMsg( HVIEW hView, UINT message, WPARAM wParam = 0, LPARAM lParam = 0 );
	GVF_INLINE	bool	SendGroupMsg( HVIEW hView, MSG& msg );

private:
	UINT	m_uViewCount;
	CView*	m_pViewArray[_MAX_VIEW_COUNT];
	CView*	m_pActiveView;
	HVIEW	m_hCaptureView;	/* Capture Mouse Input View */
	HVIEW	m_hFocusView;	/* Key Inputing Focus View Currently! */

///////////////////////////////////////////////////////////////////////////////
// Network Interface
public:
	GVF_INLINE	CDpInterface*	GetDpNet( );
	GVF_INLINE	bool			IsNetValid( );
	GVF_INLINE	void			SetSession( CNetSession* pSession );

private:
	CDpInterface	m_oDpNet;		// Game Network Interface
	CNetSession*	m_pGameSession;	// Game Session Pointer

///////////////////////////////////////////////////////////////////////////////
// Global Interface and Windows Application Data.
public:
	GVF_INLINE	HWND			GetMainWnd();
	GVF_INLINE	HINSTANCE		GetInstance();
	GVF_INLINE	bool			IsAppActive( );

private:
	bool	InitApp();
	bool	StartApp();
	bool	DestoryApp();

private:
	bool		m_bActiveApp;	// Is Game Application Activated ?
	HCURSOR		m_hCursor;		// Game Application Cursor
	HWND		m_hMainWnd;

	static	LPSTR		m_lpCmdLine;
	static	int			m_nCmdShow;
	static	HINSTANCE	m_hInstance;	
	static	CGameApp*	m_lpMainApp;

private:
	static	LRESULT	CALLBACK MainWndProc
		(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);


///////////////////////////////////////////////////////////////////////////////
// ��ʱ�������Ͳ�������
protected:
	UINT		m_dwTickCount;	/* TickCount */
	UINT		m_uTimerDelay;

public:
	GVF_INLINE	DWORD	GetTickCount();


///////////////////////////////////////////////////////////////////////////////
// Constructor and Destructor
public:
	CGameApp();
	virtual ~CGameApp();
};

/***************************** Some Inline Functions *************************/
// Some Get Function
GVF_INLINE DWORD CGameApp::GetTickCount( )			{
	return m_dwTickCount;							}

GVF_INLINE CGameApp* GetApp()						{
	ASSERT(CGameApp:: m_lpMainApp );
	return CGameApp::m_lpMainApp;					}

GVF_INLINE bool	CGameApp::IsAppActive( )			{
	return m_bActiveApp;							}

GVF_INLINE HWND CGameApp::GetMainWnd()				{
	ASSERT( m_hMainWnd );
	return m_hMainWnd;								}

GVF_INLINE HINSTANCE CGameApp::GetInstance()		{
	ASSERT( m_hInstance );
	return m_hInstance;								}

GVF_INLINE CView*	CGameApp::GetView(HVIEW hView)	{
	ASSERT( IS_VALIDHVIEW( hView ) );
	return m_pViewArray[hView];						}

GVF_INLINE CView*	CGameApp::GetActiveView( )		{
	if( IsAppActive() )
		return m_pActiveView;						
	return NULL;									}

GVF_INLINE CDpInterface* CGameApp::GetDpNet( )		{
	return &m_oDpNet;								}


GVF_INLINE bool CGameApp::IsNetValid( )				{
	return m_oDpNet.GetDpState() & DPS_HAVEPLAYER;	}

GVF_INLINE void CGameApp::SetSession( 
		 CNetSession *pSession )					{
	ASSERT( pSession != NULL );
	ASSERT( m_pGameSession == NULL );
	m_pGameSession = pSession;						}


/********************* Log File Debug Macros and Functions *******************/
// Log �ļ��ĵ��Ժ�ͺ���
#ifdef	_LOGDEBUG
void	printl( const char *, ... );
void	startlt( );
void	putlt( const char * szComment );
void	lwrite( void *lpData, int size );
#define	TRACE( string )	printl( "%s", (string) )

#else
GVF_INLINE	void	printl( const char *, ... )			{ };
GVF_INLINE	void	putlt( const char * szComment )		{ };
GVF_INLINE	void	lwrite( void *lpData, int size )	{ } ;
GVF_INLINE	void	startlt( )							{ }	;
#define	TRACE( string )	OutputDebugString( string )

#endif

#endif // !defined(AFX_GAMEAPP_H__E41362EF_FC91_4626_A90A_D992EAE865D9__INCLUDED_)
