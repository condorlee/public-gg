/*=============================================================================
 * Name			: GameApp.h
 * Project		: IcyWeapon
 * Function		: ��Ϸ���������ʵ���ļ�
 * Abbreviation	: UM - Unit Message.
 * Programmed	: Li Wenbin 1999/09/20
******************************************************************************/
#include "stdafx.h"
#include "View.h"
#include "Player.h"

/******************************* class GameApp *******************************/
///////////////////////////////////////////////////////////////////////////////
// Game World Function

bool CGameApp::InitGame()	{
	return true;			}

bool CGameApp::StartGame( )	{
	return true;			}

bool CGameApp::DestroyGame(){
	return true;			}



/******************************* View Function *******************************/
CView* CGameApp::CreateView( CView* pView, CViewClass* pClass, 
	RECT *pRect, CFrame *pFather )
{
	ASSERT( pClass || pView );
	
	HVIEW hView = INVALID_HVIEW;
	if( pView )	pClass = pView->GetViewClass();
	else
	{
		pView = NEW_VIEW( pClass ); // ��̬��������
		if( pView == NULL )
			throw EXCEPTION( ErrorNewObject );
		pView->m_dwState |= VS_DYNAMIC; 
	}
	
	// �ǼǴ��ڵ�ϵͳ��.
	for( hView = FIRST_HVIEW; hView <= LAST_HVIEW; hView ++ )
		if( m_pViewArray[hView] == NULL )	break;
	
	// ���뱣֤ϵͳ���ڵĸ�����Ҫ���
	ASSERT( hView <= LAST_HVIEW );
	m_pViewArray[hView] = pView;
	m_uViewCount ++;

	// ���ʵ�����Ϣ���浽���ڶ�����.
	pView->m_hSelf = hView;				// ���ھ��
	if( pRect )		pView->m_rcViewRect = *pRect; // ����λ��
	if( pFather )
	{
		pView->m_hFather=pFather->GetHView();	// ������ͣϢ
		pFather->AddChild( hView );
	}
	else
		pView->m_hFather = INVALID_HVIEW;

	// �����ڵ���Ϣ�Ǽǵ���Ϣ�ǼǱ��С��������Ļ���
	CViewClass* pbc = pClass;
	SMessageMap* pMap;
	while( pbc )
	{
		pMap = const_cast<SMessageMap *>(pbc->m_pMsgMapTable);
		ASSERT( pMap != NULL );
		while( pMap->uMsg != INVALID_MESSAGE )
		{
			pView->RegisterMsgMap( pMap );
			pMap ++;
		}
		pbc = const_cast<CViewClass *>(pbc->m_pBaseClass);
	}

	// ��ʼ���ɹ���Ϣ.
	pView->m_dwState = VS_DEFAULT;
	pView->m_nPicSide = 0;
	SendGvfMsg( pView->GetHView(), VM_CREATE );
	return pView;
}

void CGameApp::OnViewValidate( HVIEW hView )
{
	// У��ϵͳ��Ϣ
	if( m_hCaptureView == hView )
		if( (!GetView(hView)->IsValidView()) ||
			(GetView(hView)->GetState()&VS_DISABLE) )
				m_hCaptureView = INVALID_HVIEW;
}

bool CGameApp::DestroyView( CView *pView )
{
	ASSERT( pView );
	HVIEW hView = pView->GetHView();
	SendGvfMsg( hView, VM_DESTROY );

	// �����Ӹ�����ȥ��
	if( pView->GetFather() )
		pView->GetFather()->SubChild( hView );

	// ��ϵͳ�ǼǱ���ȥ��
	ASSERT( m_pViewArray[hView] );
	m_pViewArray[hView] = NULL;
	m_uViewCount --;

	// ɾ������
	if( pView->GetState( ) & VS_DYNAMIC )
		DELETE_VIEW( pView );
	return true;
}


void CGameApp::SetCaptureView( HVIEW hView, bool bSet )
{
	if( bSet )
	{
		// û�������Ĵ�������Capture
		ASSERT( m_hCaptureView == INVALID_HVIEW );
		m_hCaptureView = hView;
	}
	else
	{
		// ȷ���Լ��ľ����Ҫ�ͷŵľ��һ��
		// ASSERT( m_hCaptureView == hView );
		if( m_hCaptureView == hView )
			m_hCaptureView = INVALID_HVIEW;
	}
}


void CGameApp::ForceQuit( )
{
	for( HVIEW hView = FIRST_HVIEW; hView <= LAST_HVIEW; hView ++ )
	{
		if( m_pViewArray[hView] != NULL )
		{
			SendGvfMsg( hView, VM_QUIT );
			GetView( hView )->CloseView();
		}
	}
}

#define	FRAME_SEND( bFrame, hView, msg )	{if( bFrame )\
	SendGroupMsg( (hView), (msg) );			else		\
	SendGvfMsg( (hView), (msg) );						}

bool CGameApp::ActiveView( CView *pView )
{
	ASSERT( pView != NULL );
	HVIEW	hView = pView->GetHView();
	ASSERT( hView != INVALID_HVIEW );

	// �����ϴλ���Ӵ�
	CView *pLastActiveView = m_pActiveView;
	m_pActiveView = pView;
	// ��ʼ����ʱ��
	DWORD dwLastTickCount = m_dwTickCount;
	m_dwTickCount = 0;
	DWORD dwTimeCount = timeGetTime( );
	
	MSG		msg;
	bool	bFrame	= pView->IsKindOf( GET_VIEWCLASS(CFrame) );// �ǲ��Ǹ������Ӵ��ڵ��Ӵ�
	HVIEW	hChild = INVALID_HVIEW;

	//  ֻҪViewһֱ���ڻ״̬
	while ( pView->IsValidView() )
	{
		// ���̺���꼰������windows��Ϣ
		BOOL bGet = ::PeekMessage(&msg, NULL, 0, 0, PM_REMOVE );
		if( !bGet )	goto MAKE_VMMESSAGE;
		VMT msgType;
		if( msg.message == WM_SYSCOMMAND && msg.wParam == SC_CLOSE )
		{
			ForceQuit();
			continue;
		}
		msgType = pView->GetMessageType( msg.message );
		switch( msgType )
		{
			// ����������Ϣ
			case VT_MOUSE:
				if( m_hCaptureView != INVALID_HVIEW )
					SendGvfMsg( m_hCaptureView, msg );
				else if( bFrame )
				{
					// ��Ȼ�Ǿ����Ӵ��ڵ���ͼ
					hChild = ((CFrame*)pView)->GetChildFromPos( msg.pt );
					if( hChild != INVALID_HVIEW ) SendGvfMsg( hChild, msg );
					else SendGvfMsg( hView, msg );
				}
				else
					SendGvfMsg( hView, msg );
				break;

			// VM������Ϣ
			case VT_CONTROL:
				FRAME_SEND( bFrame, hView, msg );
				break;

			// ����Ǽ�����Ϣ
			case VT_KEYBOARD:
				if( msg.message == WM_SYSKEYUP || msg.message == WM_KEYUP
					|| (!(msg.lParam &(0x0001<<30))) )
				{
					
					if( m_hFocusView != INVALID_HVIEW )
						SendGvfMsg( m_hFocusView, msg );
					else
						SendGvfMsg( hView, msg );
				}

			// ������Windows��Ϣ, ����Ӧ.
			default:
				::TranslateMessage( &msg );
				::DispatchMessage( &msg );
		} // End Switch;
		continue;

MAKE_VMMESSAGE:
		// Network Message
		if( IsNetValid() && m_pGameSession != NULL )
		{
			UINT uMsgCount = GetDpNet()->GetMessageCount();
			if( uMsgCount )
				m_pGameSession->OnReceive( GetDpNet(), uMsgCount );
		}

		// Timer Message
		DWORD dwNewCount = timeGetTime();
		if( dwNewCount - dwTimeCount >= m_uTimerDelay)
		{
			msg.message = VM_TIMER;
			msg.wParam = m_dwTickCount;
			msg.lParam = dwNewCount;
			dwTimeCount = dwNewCount;			
			for( HVIEW hTemp = FIRST_HVIEW; hTemp <= LAST_HVIEW; hTemp ++ )
				if( m_pViewArray[hTemp] != NULL )
					SendGvfMsg( hTemp, msg );
			m_dwTickCount ++;
			continue;
		}
		// GVF��ˢ����Ϣ
		if( (!(pView->GetState() & VS_VALIDPAINT)) && (IsAppActive() ) )
		{
			// ����ˢ������,ͬʱˢ��ǰ������������.
			FRAME_SEND( bFrame, hView, VM_PAINT );
			RefreshScreen();

			FRAME_SEND( bFrame, hView, VM_PAINT );
			RefreshScreen();
			pView->InvalidPaint( false );
		}// End If Refresh;

	}// End while 

	m_pActiveView = pLastActiveView;
	m_dwTickCount = dwLastTickCount;
	return true;
}

/*********************** Interface face WINDOWS Application ******************/
bool CGameApp::InitApp()
{
	if( InitInstance() )
	{
		if( InitGame() )
			return true;
	}
	return false;
}

bool CGameApp::StartApp()
{
	return StartGame();
}

bool CGameApp::DestoryApp()
{
	if( DestroyGame( ) )
	{
		if( DestroyInstance() )
			return true;
	}
	return false;
}


// Register Window Class and create the main Wnd
bool CGameApp::InitInstance()
{
	// Register the windows class
	WNDCLASSEX wcex;
	m_hCursor = (HCURSOR)LoadImage(GetApp()->GetInstance(), MAKEINTRESOURCE(m_uCursorID), 
			IMAGE_CURSOR,0,0,0);
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.hInstance = m_hInstance;
	wcex.lpszClassName = m_lpszClassName;
	wcex.lpfnWndProc = MainWndProc;
	wcex.style = CS_VREDRAW|CS_HREDRAW|CS_DBLCLKS;
	wcex.hIcon = LoadIcon (m_hInstance, MAKEINTRESOURCE(m_uIconID));
	wcex.hIconSm = LoadIcon (m_hInstance, MAKEINTRESOURCE(m_uIconID));
	wcex.hCursor =  m_hCursor;
	wcex.lpszMenuName = NULL;
	wcex.cbClsExtra = 0 ;
	wcex.cbWndExtra = 0 ;
	wcex.hbrBackground = (HBRUSH)GetStockObject (NULL_BRUSH);
	if( !RegisterClassEx(&wcex) ) return false;

	// Create the main window
	m_hMainWnd = CreateWindowEx(
		0,
		m_lpszClassName,
		m_lpszTitle,
		WS_POPUP|WS_VISIBLE|WS_SYSMENU|WS_OVERLAPPED,
		0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN),
		NULL,NULL,
		m_hInstance,
		NULL);

	if( !m_hMainWnd )
		return false;
	
	SetFocus( m_hMainWnd );
	ShowWindow(m_hMainWnd, m_nCmdShow );
	UpdateWindow(m_hMainWnd);

	GetDpNet()->OpenConnection( );
	return true;
}

bool CGameApp::DestroyInstance()
{
	GetDpNet()->CloseConnection( );
	DestroyWindow( m_hMainWnd );
	PostQuitMessage( 0 );
	m_hMainWnd = NULL;
	return true;
}

bool CGameApp::ActivateApp( bool bActive )
{
#ifdef	_GDI_OUTPUT
	return m_bActiveApp = true;
#endif
	return m_bActiveApp = bActive;
}


/********************** Constructor and Destructor ***************************/
CGameApp::CGameApp(  )
{
	m_lpMainApp = this;
	m_lpszClassName = "Game Window Class";
	m_lpszTitle = "Standard Game";
	m_hMainWnd = NULL;
	m_pGameSession = NULL;

	m_bActiveApp = true;
	m_pActiveView = NULL;
	
	// ��ʼ��GVF View����Ϣ��.
	m_uViewCount = 0;
	for( int i = 0; i < _MAX_VIEW_COUNT; i ++ )
		m_pViewArray[i] = NULL;

	m_hCaptureView = INVALID_HVIEW;
	m_hFocusView = INVALID_HVIEW;
	m_uTimerDelay = 5;	// NT recommend value!
	m_dwTickCount = 0;
}

CGameApp::~CGameApp()
{
	m_lpMainApp = NULL;

#ifdef _DEBUG
	ASSERT( m_uViewCount == 0 );
#else
	for( int i = 0; i < _MAX_VIEW_COUNT; i ++ )
		if( m_pViewArray[i] )
			DELETE_VIEW ( m_pViewArray[i] );
#endif

}

/****************************** Global Variables *****************************/
CGameApp*	CGameApp::m_lpMainApp = NULL;
HINSTANCE	CGameApp::m_hInstance = NULL;
LPSTR		CGameApp::m_lpCmdLine = NULL;
int			CGameApp::m_nCmdShow = SW_SHOW;

/******************************* Global Function *****************************/
LRESULT CALLBACK CGameApp::MainWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch( message )
	{
	case WM_SETCURSOR:
		SetCursor( GetApp()->m_hCursor );
		return TRUE;

	case WM_ACTIVATEAPP:
		GetApp()->ActivateApp( wParam? true:false );
		return 0;

	// case WM_SYSKEYUP:
	// case WM_KEYDOWN:
	// case WM_KEYUP:
	// case WM_CHAR:
	// case WM_DEADCHAR:
	// case WM_SYSKEYDOWN:
	case WM_SYSKEYUP:
	case WM_SYSCHAR:
	case WM_SYSDEADCHAR:
	// case WM_NCACTIVATE:
		return 0;

	case WM_PAINT:
		if( GetApp()->m_pActiveView )
		GetApp()->m_pActiveView->InvalidPaint(true);
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
}

#ifdef _LOGDEBUG		// Start Log Debug function and variables

static char g_szLogFile[_MAX_PATH];
static DWORD g_dwStartLogTime = 0;
void printl( const char *format, ... )
{
	va_list args;						/* Argument list pointer	*/
	FILE* pLog = fopen( g_szLogFile, "a+b" );
	if( pLog )
	{
		va_start(args,format);			/* Initialize va_ functions	*/
		vfprintf( pLog, format,args);
		fputc('\r', pLog); fputc('\n', pLog);
		fclose( pLog );
	}
}


void startlt( )
{
	g_dwStartLogTime = timeGetTime();
}

void putlt( const char* szComment )
{
	printl( "%s: %d",szComment, timeGetTime()-g_dwStartLogTime );
}

void lwrite( void *lpData, int size )
{
	FILE* pLog = fopen( g_szLogFile, "a+b" );
	if( pLog )
	{
		fwrite( lpData, 1, size, pLog );
		fclose( pLog );
	}
}
#endif //LOGDEBUG



int WINAPI GameMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPTSTR lpCmdLine, int nCmdShow)
{
	if( FAILED( CoInitialize( NULL ) ) )
		return -1;

#ifdef	_LOGDEBUG
	sprintf( g_szLogFile, "%IW%d.LOG", timeGetTime());
#endif

	CGameApp *pApp = GetApp();
	pApp->m_hInstance = hInstance;
	pApp->m_lpCmdLine = lpCmdLine;
	pApp->m_nCmdShow = nCmdShow;	
	try
	{
		if( pApp->InitApp() )
			if( pApp->StartApp() )
				pApp->DestoryApp( );
	}

	catch( CException e )
	{		
		MessageBox( NULL, e.GetString(), "��Ϸ����", MB_OK|MB_ICONSTOP );
		pApp->DestroyInstance( );
	}
#ifndef	_DEBUG
	catch(...)
	{
		MessageBox( NULL, "����δ֪�Ĵ���", "��Ϸ����", MB_OK|MB_ICONSTOP);
		pApp->DestroyInstance( );
	}
#endif
	CoUninitialize( );
	return 0;
}


