/******************************************************************************
// Name			: Exception.h
// Project		: IcyWeapon
// Function		: �����쳣�Ļ���Ľӿڶ���
// Abbreviation	: Exception = Excpt.
// Programmed	: Li Wenbin 1999/09/20
// Modified-1st	: Li Wenbin 1999/10/11
******************************************************************************/

#if !defined(AFX_EXCEPTION_H__F7427AC4_757C_11D3_A68A_0000E83EE37C__INCLUDED_)
#define AFX_EXCEPTION_H__F7427AC4_757C_11D3_A68A_0000E83EE37C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/********************************** class CException *************************/
// Modified by Li.Wenbin At 10.11 1999
// ʹ��EXCEPTION�����׳��쳣��
// ʾ�� if( pView == NULL )	throw EXCEPTION( ErrorNewObject );

#ifdef _DEBUG
#define	EXCEPTION( uID )	CException( CException::uID, __FILE__, __LINE__ )
#else
#define EXCEPTION( uID )	CException( CException::uID );
#endif

#define	_MAX_EXCPTSTR_LEN	_MAX_PATH+2048
class CException			// IcyWeapon�����쳣��Ļ���
{
public:
	/************* Begin Exception ID ****************/
	enum	ExceptionID	{
		/* ȫ�ֵ��쳣ID�� */
		Success = 0,
		GenericException,
		ErrorNewObject,
		InsufficientMemory,

		/* �������쳣ID�� */
		InvalidPackageFormat,

		ErrorReadIndex,
		ErrorReadItem,
		ErrorReadFile,
		ErrorCreateFile,
		ErrorReadHeader,
		ErrorWriteHeader,		

		SubItemNameTooLong,
		IndexTableOver,

		/* Media ģ���쳣 */
		ErrorCreateFont,

		/* DirectX ģ���쳣 */
		GenericDdException,
		CannotCreateDD,
		CannotSetExclusiveMode,
		CannotSetVideoMode,
		CannotCreateFlipSurface,
		CannotGetBackBuffer,
		CannotLockSurface,
		CannotUnlockSurface,
		CannotFlipSurface,
		CannotGetBackSurfaceDC,
		CannotReleaseBackSurfaceDC,
		CannotRestoreVideoMode,
		CannotRestoreSurface,
		NeedHigherDXVersion,
		CannotSetPalette,

		GenericDsException,
		CannotCreateDS,
		CannotSetExclusiveSoundMode,
		CannotCreateSoundBuffer,
		CannotSetPrimaryFormat,
		CannotLockSoundBuffer,
		CannotPlaySound,
		CannotPlayMusic,

		/* DirectPlay���쳣 */
		ErrorCreateEvent,
		ErrorEnumSessions,
		ErrorTCPIPProtocol,
		ErrorInitConnection,

		ErrorCreatePlayer,
		ErrorOpenSession,
		ErrorSetSession,
		ErrorDestroyPlayer,
		ErrorOnSend,
		ErrorOnReceive,

		/* GVFģ���쳣 */
		TooManyChildView,

		/* SCENARIOģ���쳣 */
		ErrorReadScenarioFile,
		InvalidScenarioFileFmt,

		/* Episodeģ���쳣 */
		ErrorReadScript,
		ScriptTooLong,
		ScriptBadComment,
		ScriptInvalidChar,
		ScriptMissSeparator,
		ScriptTooManyWord,
		ScriptInvalidSign,
		ScriptSyntaxError,
		ScriptSemanticError,

		/* End Exception ID */
		EndOfExceptionID
	};
	/************** End Exception ID ****************/


protected:
	// ���������쳣��ID��
	// ID == 0 ��ʾδ֪���쳣
	UINT	m_uExceptionID;
	char	m_szDetail[_MAX_EXCPTSTR_LEN];

#ifdef	_DEBUG
	char	m_szFileName[_MAX_PATH];
	UINT	m_uLineNum;
#endif


// �ӿں���
public:
#ifdef _DEBUG
	CException( ExceptionID uExceptionID, LPCTSTR lpszExcptFile, int nLine);
#else
	CException( ExceptionID uExceptionID );
#endif

	// �����쳣�Ĵ�����Ϣ�ַ���
	char*	GetString();
};
#endif // !defined(AFX_EXCEPTION_H__F7427AC4_757C_11D3_A68A_0000E83EE37C__INCLUDED_)
