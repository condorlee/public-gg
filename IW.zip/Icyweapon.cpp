#include "stdafx.h"
#include "IwImp.h"
#include "MainFrame.h"
#include "World.h"

/************************** Game App Overrides *******************************/
CIcyWeaponApp theApp;
CMedia		CIcyWeaponApp::m_oMedia;
CWorld		CIcyWeaponApp::m_oWorld;
CMainFrame	CIcyWeaponApp::m_oMainFrame;
CPlayer*	CIcyWeaponApp::m_lpPlayers[_MAX_PLAYERS];
UINT		CIcyWeaponApp::m_uPlayerObjCount = 0;

bool CIcyWeaponApp::InitGame()
{
	CGameApp::InitGame( );
	m_oMedia.Init( GetMainWnd(), 800, 600 );

	RECT	rect = { 0,0,799,599 };
	CreateView( &m_oMainFrame,NULL,&rect,NULL );
	SetSession( m_oMainFrame.GetSession() );

	return true;
}

bool CIcyWeaponApp::StartGame()
{
	CGameApp::StartGame();
	return ActiveView( GetMainFrame() );
}

bool CIcyWeaponApp::DestroyGame()
{
	DestroyView( &m_oMainFrame );
	m_oMedia.Destroy();
	return CGameApp::DestroyGame( );
}
/************************** Paint Functions **********************************/
void CIcyWeaponApp::RefreshScreen()
{
	ShowCursor( false );
	m_oMedia.FlipSurface();
	ShowCursor( true );
}

/********************** Constructor and Destructor ***************************/
CIcyWeaponApp::CIcyWeaponApp( )
{
	m_lpszClassName = "IcyWeapon Window";
	m_lpszTitle = "IcyWeapon";
	m_uIconID = IDI_ICYWEAPON;
	m_uCursorID = IDC_ICYWEAPON;
	m_uTimerDelay = 1000/TICK_PER_SECOND;

	for( UINT u = 0; u < _MAX_PLAYERS; u ++ )
		m_lpPlayers[u] = NULL;
}
