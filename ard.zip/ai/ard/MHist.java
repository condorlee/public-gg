package ai.ard;

public class MHist {

}
