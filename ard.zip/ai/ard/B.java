package ai.ard;


import ai.ard.BEgo.Goal;
import ai.ard.aid.Proc;
import ai.ard.aid.S;
import ai.ard.aid.Proc.Type;

/*
 * Brain, the true Ardai himself, 
 * 		Ego		- the will / purpose / personality of Ardai
 * 		Cerebel - (L4) intuitive intelligence of the brain
 *		Cerebra - (L5) conceptual intelligence of the brain
 * 		Memory	- all things that Ardai knows / remembers
 * 		World	- the reality world, a special part of the memory
 * 			Virtual worlds - imagination, story, assumption (for thinking)  
 */
public class B {
	
	public void cogito() {
		wakeup();
		do {
			tiktok();
			bel.perceive();
			Goal[] goals = ego.getOpenGoals();
			goals = bra.ponder(goals);
			bel.perform(goals);
		} while (awake());
	}

	public void wakeup() {
		ego = BEgo.wakeup(this);
		bra = BBra.wakeup(this);
		bel = BBel.wakeup(this);
		body = bel.body;
		mem = M.wakeup(this);
		world = mem.world;
		awake = true;
	}
	public void goSleep(boolean passive) {}
	public long getTik() {return tik;}
	
	public Proc createCamProc() {return Proc.create(Type.CPU, CAM_PROC_CORE_PERCENT);}
		
	/* Use lastTikMs = tik * MSPT, instead of real last tik ms to avoid cumulative error */
	private void tiktok() {
		long lastTikMs = tik * MSPT;
		long ms = S.getMs();
		long tikMsRemain = MSPT - (ms - lastTikMs);
		
		if (tikMsRemain > 1) S.sleep(tikMsRemain - 1);
	}	
	private boolean awake() {return awake;}
	
	
	public final static int CPU_MIN_CORES = 4;
	public final static int CAM_PROC_CORE_PERCENT = 25;
	
	public static B create(String metaFile) {
		B brain = new B();
		brain.init(metaFile);
		return brain;
	}
	
	/* @work init() only do system level init. Logic init all done in wakeup() */
	private void init(String metaFile) {
		initTik();
	}
	/* Init at -1 tik to trigger 1st ticking immediately */
	private void initTik() {tik = S.getMs() / MSPT - 1;}

	long tik;
	boolean awake;

	BEgo ego;
	BBra bra;
	BBel bel;
	Body body;
	M mem;
	W world;

	public final static int TPS = 30;
	public final static int MSPT = 1000 / TPS;
	public final static int FPS = 5;
	public final static int TPF = W.TPS / FPS;
	
	
}









