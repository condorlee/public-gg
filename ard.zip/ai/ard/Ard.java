package ai.ard;

import org.slf4j.MDC;

import ai.ard.aid.*;


public class Ard {

	public static void main(String[] args) {
		MDC.put("logFileName", "ArdaiStart");
		L.info("Ardai started, arguments length: {}", args.length);

		CmdLineParams params = CmdLineParams.parse(args);
		Ard ardai = new Ard(params);
		try {
			ardai.init();
			ardai.mainFlow();
		}
		catch(Throwable e){
			L.exception("Exception in Ard.main()", e);
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			ardai.clear();
		}

	}
	
	private void mainFlow() {
		brain.cogito();
	}
	
	private void init() {
		initJni();
		int i = Codec.nDecJpg(null, 0, 0, null);
		System.out.println(i);
		cfg = Config.loadConfig(params.configFile);
		brain = B.create(cfg.brainMetaFile);
	}
	private void initJni() {S.loadLib(JNI_LIB_NAME);}
	private void clear() {}
	
	private final static String JNI_LIB_NAME = "ard_jni";
	
	
	
	public Ard(CmdLineParams params) {this.params = params;}

	private B brain;
	
	private Config cfg;
	private CmdLineParams params;
	
	public static class CmdLineParams {
		public String configFile;
		public static CmdLineParams parse(String[] args) {
			return null;
		}
	}
	public static class Config {
		public String brainMetaFile;
		
		public static Config loadConfig(String configFilePath) {
			Config cfg = new Config();
			cfg.load(configFilePath);
			return cfg;
		}
		
		public void load(String configFilePath) {}
		public void save(String configFilePath) {}
		
		public final static String DEF_FILE = ""; 
	}
	
	
	public final static boolean DEV = true;
}





