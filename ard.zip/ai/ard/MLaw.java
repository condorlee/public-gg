package ai.ard;

public class MLaw {

}
