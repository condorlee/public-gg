package ai.ard;

public class WVirt extends W {

}
