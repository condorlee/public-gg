package ai.ard;

import ai.ard.BEgo.Goal;

public class BBra {
	public static BBra wakeup(B brain) {return new BBra(brain);}

	public BBra(B brain) {init(brain);}
	private void init(B _brain) {brain = _brain;}
	
	/* Ego driven, world aware */
	public Goal[] ponder(Goal[] goals) {
		return null;
	}
	
	
	
	B brain;
}
