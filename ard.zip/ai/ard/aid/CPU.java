package ai.ard.aid;

import ai.ard.aid.L.Msg;
import ai.ard.dat.Nd;

public class CPU extends Proc {
	static int getCores() {return 6;}
	static int getReservedCores() {return 1;}
	static int getMinCores() {return 1;}
	
	CPU(int cores) {}

	public Nd mul(Nd d1, float f) {L.assertUni(Msg.Feature_need_support); return d1;}
	public Nd toI8(Nd d1) {L.assertUni(Msg.Feature_need_support); return d1;}
	
	public Nd toF32(Nd d1) {L.assertUni(Msg.Feature_need_support); return d1;}
	public Nd toI16(Nd d1) {L.assertUni(Msg.Feature_need_support); return d1;}
	
	public byte getMaxI8(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public byte getMinI8(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public short getMaxI16(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public short getMinI16(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public float getMaxF32(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public float getMinF32(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	
	public void normalize(Nd data, float min, float max) {
		L.assertUni(Msg.Feature_need_support);
	}
	
	public Nd mul(Nd d1, Nd d2) {L.assertUni(Msg.Feature_need_support); return d1;}
	public Nd dot(Nd d1, Nd d2) {L.assertUni(Msg.Feature_need_support); return d1;}
	
	
	/* GPU version can be, for example:
	 * 	1. Split the 512x512 frame to 64x64 pieces of 8x8 tiles / strokes = new int[512*512];
	 *	2. For the nth tile, basePondSeq = 64 * n, applying below flooding algorithm 
	 *	3. Check the border line pixels to build up long[] pondPond, where:
	 *		pondPond[i] = (pond1 << 32) + pond2, which means pond1 and pond2 are connected
	 *	4. Scan pondPond to build up ArrayList<I32List> lakes and int[] pond2Lake as:
	 *		lakes.get(n) contains all the ponds Ids which connected together, and named as lake#n
	 *		pond2Lake[i] = n means pond#i is part of lake#n
	 *		And by default lakes.n = n, pond2Lake[i] = i
	 *		For each pondPond[j] = [p, q]:
	 *			for qq in qLake: pLake += qq; pond2Lake[qq] = qLakeId;
	 *	5. Scan the 512x512 pixels, pond = strokes[y, x]; strokes[y, x] = pond2Lake[pond];
	 * Above step #2, #3, #5 can be done in GPU. Step #1, #4 can be done in CPU
	 */
	public Nd flooding(Nd d, float wave) {
		int pixelCount = d.size0() * d.size1();
		float[] pixels = d.getF32Buf();
		int width = d.size1();
		
		float negWave = -wave;
		Nd p2s = Nd.newNd(Nd.I32, d.sizes());
		int[] _p2s = p2s.getI32Buf();
		int[] hots = new int[pixelCount];
		int[] arounds = new int[4];
		int hotNum = 0, strokeId = 1;
		
		for (int rowEnd = pixelCount - 1; rowEnd > 0; rowEnd -= width) {
			int rowStart = rowEnd - width + 1;
			for (int p = rowEnd; p >= rowStart; p --) {
				if (_p2s[p] > 0) continue;
				_p2s[p] = strokeId ++;
				hots[hotNum ++] = p;
				
				while (hotNum > 0) {
					int hot = hots[hotNum --];
					float hotPixel = pixels[hot];
					int aroundNum = 0;
					int up = hot - width, dn = hot + width, lf = hot - 1, rt = hot + 1;
					
					if (up >= 0 && _p2s[up] == 0) arounds[aroundNum ++] = up;
					if (dn < pixelCount && _p2s[dn] == 0) arounds[aroundNum ++] = dn;
					if (lf >= rowStart && _p2s[lf] == 0) arounds[aroundNum ++] = lf;
					if (rt <= rowStart && _p2s[rt] == 0) arounds[aroundNum ++] = rt;
					for (int i = 0; i < aroundNum; i ++) {
						int around = arounds[i];
						if (_p2s[around] > 0) continue;
						float diff = pixels[around] - hotPixel;
						if (diff <= wave && diff >= negWave) {
							_p2s[around] = strokeId;
							hots[hotNum ++] = around;
						}
					}
				}
			}
		}
		
		return p2s;
	}
	
}


