package ai.ard.aid;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;




/* 
 * Log
 */
public class L {
	public static boolean DEV = true;
	
	public static int logLevel = L.HINT;

	public static int MONITOR_LEVEL = L.HINT;
	public static void setMonitorLevel(int monitorLevel){L.MONITOR_LEVEL = monitorLevel;}

	public static int ii = 0;
	public static void logIi() {
		L.ii ++;
		L.hint(ii + "");
	}
	
	/* Used as placeholder such as: 
	 * if (cond1) xxx;
	 * else if (cond2) Log.nop();
	 * else if (cond3) xxx; */
	public static void nop() {}
	
	/* Do nothing for smart breakpoint */
	public static void sb() {}

	/* 
	 * Fatal = Battery 0%  / No mem  / Red message until resolve, beep 3 / 15s until x
	 * Error = Battery 5%  / No Cam  / Red message, beep 3 / 1m, close to level 1 history
	 * Warn  = Battery 20% / No Mic  / Red message 15s, beep 3, expire to level 1 history
	 * Hint  = Battery 30% / No Gyro / Yellow message 5s, expire to level 1 history
	 * Info  = Battery 60% / No Baro / Black message 5s, expire to level 2 history
	 */
	public static void uiFatal(String msg) {uiMsg(msg, FATAL);}
	public static void uiError(String msg) {uiMsg(msg, ERROR);} 
	public static void uiWarn(String msg) {uiMsg(msg, WARN);} 
	public static void uiHint(String msg) {uiMsg(msg, HINT);} 
	public static void uiInfo(String msg) {uiMsg(msg, INFO);} 
	public static void uiMsg(String msg, int level) {}
	
	
	
	public static void setLogLevel(int level) {
		if (level <= NONE || level >= ALL) {
			L.logLevel = INFO;
			logger.warn("Set log level of SysLog, the logLevel {} is INVALID", level);
		} 
		else {
			L.logLevel = level;
			logger.info("Set log level of SysLog to {}", level);
		}
	}

	private static boolean DEV_DEBUG = false;
	public static void devDebug(){L.DEV_DEBUG = true;}
	/*
	 * 3 different styles of logger
	 * normal	- Normal logger
	 * noLf		- Mostly line normal logger, but does not automatically append line feed
	 * raw		- Raw logger, no any additional character, only log whatever message caller asks
	 * */
	public static int normal = 0;
	public static int noLf = 1;
	public static int raw = 2;

	public static Logger logger;
	
	static {
		L.logger = LoggerFactory.getLogger(L.class);
		
		System.out.println("Logger class: " + L.logger.getClass().getName());
		System.out.println("Logger of class: " + L.logger.getName());

		/* In this whole log file we will not include date in each line of log message, to save
		 * space and make browsing easier. So here we highlight current date, just once. */
		Date now = new Date(); 
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		
		String dateTag = "\n========================================"
				+ "========================================\n"
				+ "Log start at " + format.format(now)
				+ "\n========================================"
				+ "========================================";

		logger.warn(dateTag);
	}
	

	/* Note
	 * 1. We do not want to abort program because of a failed assert
	 * 
	/* 2. slf4j defines TRACE as even more detailed than DEBUG. This confuses us. So we change out
	 * TRACE to TRACK, meaning to track program logic flow information, more details than INFO but
	 * less details than DEBUG. Both TRACK and DEBUG maps to slf4j DEBUG level. */
	public final static int NONE = 0;
	public final static int FATAL = 1;
	public final static int ASSERT = 2;
	public final static int ERROR = 2;
	public final static int EXCEPTION = 2;
	public final static int WARN = 3;
	public final static int HINT = 4;
	public final static int INFO = 5;
	public final static int TRACK = 6;
	public final static int DEBUG = 7;
	public final static int ALL = 8;

	final static String[] levelNames = new String[] { "None", "Fatal",
			"Error/Assert/Exception/NeedStub", "Warn", "Hint", "Info", "Track", "Debug" };

	/* We may define extra markers for ASSERT and EXCEPTION and NEEDSTUB */
	static String[] levelStrings = new String[] {"" , "F ", "E ", "W ", "H ", "I ", "T ", "D "};
	static Marker[] levelMarkers;
	
	static {
		L.levelMarkers = new Marker[levelStrings.length];
		
		for (int i = 0; i < L.levelStrings.length; i ++)
			L.levelMarkers[i] = MarkerFactory.getMarker(L.levelStrings[i]);
	}

	public static void output(int level, int stackLevelOfs, boolean logCaller, Object message,
			Object... objects) 
	{
		if (level > logLevel) return;		
		String m = message instanceof String ? (String)message : String.valueOf(message); 
		String msg;
		Marker marker = L.levelMarkers[level];
		
		msg = L.formatPrefix(logCaller, m, stackLevelOfs);
		
		switch (level) {
		case L.TRACK: logger.debug(marker, msg, objects); break;
		case L.DEBUG: logger.debug(marker, msg, objects); break;
		case L.INFO: logger.info(marker, msg, objects); break;
		case L.HINT: logger.warn(marker, msg, objects); break;
		case L.WARN: logger.warn(marker, msg, objects); break;
		case L.ERROR: logger.error(marker, msg, objects); break;
		case L.FATAL: logger.error(marker, msg, objects); break;
		default: logger.error("Wrong log level {}", level);
		}
		
		if (level <= L.ERROR) {
			L.nop();
		}
	}
	
	/* If preparing the debug or track information cost CPU a lot, then logging logic can check if
	 * the related level of logging is enabled or not, to avoid wasting CPU time */
	public static boolean isDebugEnabled() {
		return L.logLevel >= L.DEBUG && logger.isDebugEnabled();
	}
	public static boolean isTrackEnabled() {
		return L.logLevel >= L.TRACK && logger.isDebugEnabled();
	}
	public static boolean isInfoEnabled() {
		return L.logLevel >= L.INFO && logger.isInfoEnabled();
	}

	public static void Assert(boolean condition, String msg, Object... objects) {
		if (!condition)
			output(ASSERT, 0, true, msg, objects);
	}
	public static void Assert(String msg, Object... objects) {
		output(ASSERT, 0, true, msg, objects);
	}
	public static void Assert(boolean condition, Msg msg, Object... objects) {
		if (!condition)
			output(ASSERT, 0, true, msg, objects);
	}
	public static void Assert(Msg msg, Object... objects) {
		output(ASSERT, 0, true, msg, objects);
	}

	public static void exception(String msg, Throwable e, Object... objects) {
		output(EXCEPTION, 0, true, msg + throwableToString(e), objects);
	}
	public static String throwableToString(Throwable e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		String s = sw.toString();
		
		return s;
	}

	public static void debug(int stackLevelOfs, boolean logCaller, String msg, Object... ps) {
		output(DEBUG, stackLevelOfs, logCaller, msg, ps);
	}
	public static void track(int stackLevelOfs, boolean logCaller, String msg, Object... ps) {
		output(TRACK, stackLevelOfs, logCaller, msg, ps);
	}

	public static void debug(Object msg, Object... ps) {output(L.DEBUG, 0, true, msg, ps);}
	public static void track(Object msg, Object... ps) {output(L.TRACK, 0, true, msg, ps);}
	public static void info(Object msg, Object... ps) {output(L.INFO, 0, true, msg, ps);}
	public static void warn(Object msg, Object... ps) {output(L.WARN, 0, true, msg, ps);}
	public static void hint(Object msg, Object... ps) {output(L.HINT, 0, true, msg, ps);}
	public static boolean hintUni(String msg) {return logUni(msg, L.HINT);}
	public static boolean hint5Uni(String msg) {return log5Uni(msg, L.HINT);}
	
	private static HashMap<String, Integer> uniLogged = new HashMap<String, Integer>();
	private static HashMap<String, HashSet<String>> nuniLogged =
			new HashMap<String, HashSet<String>>();
	private final static int MAX_LOG_CACHE = 16384;

	/*
	 * The below xxxOnce and xxxN methods are for logging with limited times
	 * For xxxUni - Log all unique s = message + "@" + loggerClass ":" lineNumber 
	 * For xxx5Uni - Log at most 5 unique s = message for the place "@" + loggerClass ":" lineNumber
	 */
	public static boolean infoUni(Object msg) {return logUni(msg.toString(), L.INFO);}
	public static boolean info5Uni(Object msg) {return log5Uni(msg.toString(), L.INFO);}
	public static boolean warnUni(Object msg) {return logUni(msg.toString(), L.WARN);}
	public static boolean warn5Uni(Object msg) {return log5Uni(msg.toString(), L.WARN);}
	public static boolean errorUni(Object msg) {return logUni(msg.toString(), L.ERROR);}
	public static boolean error5Uni(Object msg) {return log5Uni(msg.toString(), L.ERROR);}

	public static boolean au(boolean b) {
		if (b) return false;
		return L.logUni(Msg.Assert_failure.name(), L.ASSERT);
	}
	public static boolean au(Object msg) {
		return L.logUni(msg.toString(), L.ASSERT);
	}
	public static boolean assertUni(boolean b) {
		if (b) return false;
		return L.logUni(Msg.Assert_failure.name(), L.ASSERT);
	}
	public static boolean assertUni(Object msg) {
		return L.logUni(msg.toString(), L.ASSERT);
	}
	public static boolean assertUni(boolean b, Object msg) {
		if (b) return false;
		return L.logUni(msg.toString(), L.ASSERT);
	}
	public static boolean assert5Uni(Object msg) {
		return L.log5Uni(msg.toString(), L.ASSERT);
	}
	public static boolean assert5Uni(boolean b) {
		if (b) return false;
		return L.log5Uni(Msg.Assert_failure.name(), L.ASSERT);
	}
	public static boolean assert5Uni(boolean b, Object msg) {
		if (b) return false;
		return L.log5Uni(msg.toString(), L.ASSERT);
	}
	public static boolean exception5Uni(String msg, Throwable e) {
		return L.log5Uni(msg + throwableToString(e), L.EXCEPTION);
	}
	public static void flushLogNStat() {
		output(WARN, 0, true, "========== log stat ==========");
		for (String msgId : uniLogged.keySet())
			output(WARN, 0, false, "#" + uniLogged.get(msgId) + " - " + msgId);
	}
	private static boolean logUni(String msg, int level) {
		String msgId = msg + "@" + L.getPrefix();
		Integer i = uniLogged.get(msgId);
		if (i == null) {
			output(level, 0, true, msg);
			if (uniLogged.size() < MAX_LOG_CACHE)
				uniLogged.put(msgId, 1);
			return true;
		}
		else {
			uniLogged.put(msgId, i + 1);
			return false;
		}		
	}
	public static boolean log5Uni(String msg, int stackOfs, int level) {
		String prefix = L.getPrefix();
		HashSet<String> logged = nuniLogged.get(prefix);
		if (logged == null) {
			logged = new HashSet<String>();
			if (nuniLogged.size() < MAX_LOG_CACHE / 5)
				nuniLogged.put(prefix, logged);
		}
		if (logged.contains(msg) || logged.size() >= 5)
			return false;
		logged.add(msg);
		output(level, stackOfs, true, msg);
		return true;
	}
	private static boolean log5Uni(String msg, int level) {return log5Uni(msg, 1, level);}


	

	public static void error(String msg, Object... ps) {output(ERROR, 0, true, msg, ps);}
	public static void fatal(String msg, Object... ps) {output(FATAL, 0, true, msg, ps);}
	
	/* Decimilli second offset between System.nanoTime and calendar whole second */
	private static long DMS_OFS = 0;
	
	static {
		long l1 = System.nanoTime();
		long l2 = System.currentTimeMillis();
		
		DMS_OFS = l1 / 100000 % 10000 - l2 % 1000 * 10;
	}

	public static long getUs() {return System.nanoTime() / 1000;}
	public static long getDms() {return System.nanoTime() / 100000;}
	
	/* System.nanoTime() is precise but not at a whole second. So here we round it. Note that the
	 * round itself is as rough as System.currentTimeMillis() but the error is constant so it is
	 * complete OK to measure time elapsed between logging, for performance analysis purpose */
	private static String getRoundDmSecond() {
		String s = String.valueOf((System.nanoTime() / 100000 - DMS_OFS) % 10000);
		
		if (s.length() == 4) return s;
		else if (s.length() == 3) return "0" + s;
		else if (s.length() == 2) return "00" + s;
		else return "000" + s;
	}
	
	/*
	 * T 22:46:43.2967 Ana.java:844 - Application log content
	 * Where slf4j create the prefix before the '.' and this method append the prefix before the '-'
	 * after the '.'
	 * */
	private static String formatPrefix(boolean logCaller, String msg, int levelOfs) {
		StringBuffer sb = new StringBuffer(msg.length() + 64);
		
		if (L.DEV_DEBUG)
			sb.append('.').append(L.getRoundDmSecond()).append(' ');
		else
			sb.append(' ');
		
		if (logCaller) {
			/* Caller information */
			StackTraceElement[] stes = Thread.currentThread().getStackTrace();
			
			/* Some caller, such as Rm.logCurrentOp() has additional wrap to log API. So we have 
			 * "levelOfs" parameter to allow adjusting to print the real logging caller information */
			for (int i = 4 + levelOfs; i < stes.length; i++) {
				String className = stes[i].getClassName();
				if (!className.equals(L.class.getName())) {
					sb.append(className, className.lastIndexOf('.') + 1, className.length())
							.append(":").append(stes[i].getLineNumber()).append(" - ");
					break;
				}
			}
		}
		
		sb.append(msg);

		return sb.toString();
	}
	private static String getPrefix() {
		StackTraceElement[] stes = Thread.currentThread().getStackTrace();
		StringBuffer sb = new StringBuffer(128);
		
		for (int i = 3; i < stes.length; i++) {
			String className = stes[i].getClassName();
			if (!className.equals(L.class.getName())) {
				sb.append(className, className.lastIndexOf('.') + 1, className.length())
						.append(":").append(stes[i].getLineNumber());
				break;
			}
		}
		return sb.toString();
	}
	
	static SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss.SSS"); 

	/* Format like: 22:46:43.296 */
	public static String getCurrentTimeString() {return format.format(new Date());}


	public static enum Msg {
		BeginParam,
			Param_bad_count,
			Param_bad_state,
			Param_bad_type,
			Param_bad_value,
			Param_null_value,
		EndParam,
		BeginMethodCall,
			Method_call_shall_not_happen,
			Method_need_overridden,
			Method_call_wrong_order,
		EndMethodCall,
		BeginSys,
			Assert_failure,
			Impossible,
			Unlikely,
			Wrong_execution_flow,
			Feature_not_support,
			Feature_need_support,
			Logic_need_review,
			Env_not_set,
			Design_flaw,
			Dfd_failed,
		EndSys,
		BeginHw,
			Sensor_not_detected,
			Actor_not_detected,
		EndHw,
		EndMsg;
		
		private static String[] msgCache = null;		
		static {
			boolean obfuscated = !EndMsg.superToString().equals("EndMsg");
			Msg.msgCache = new String[Msg.EndMsg.ordinal()];
	
			/* If enum Msg is obfuscated, then we log "MSG#123#" as message. Otherwise log the enum
			 * name itself like "Incorrect_parameters_to_call_this_method" */
			for (int i = 0; i < msgCache.length; i ++) {
				msgCache[i] = obfuscated ? "MSG#" + i + "#" : Msg.values()[i].superToString();
				msgCache[i] = msgCache[i].replaceAll("-", " ");
			}
		}
		  
		@Override
		public String toString() {return msgCache[this.ordinal()];}
		public String superToString() {return super.toString();}
	}
	
	
	public static class NotSupported extends RuntimeException {
		private static final long serialVersionUID = -8266393033233151217L;
	}
}






