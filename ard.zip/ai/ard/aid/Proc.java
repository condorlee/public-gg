package ai.ard.aid;

import ai.ard.aid.L.Msg;
import ai.ard.dat.Nd;

/*
 * Processor Unit = CPU / GPU
 */
public abstract class Proc {
	
	/* @enhance Support dynamic processor allocation */
	public static enum Type {
		CPU,
		GPU;
	}
	
	private static int getCores(Type type) {
		if (type == Type.CPU) return CPU.getCores();
		else if (type == Type.GPU) return GPU.getCores();
		else {L.assertUni(false); return 1;}
	}
	private static int getReservedCores(Type type) {
		if (type == Type.CPU) return CPU.getReservedCores();
		else if (type == Type.GPU) return GPU.getReservedCores();
		else {L.assertUni(false); return 1;}
	}
	private static int getMinCores(Type type) {
		if (type == Type.CPU) return CPU.getMinCores();
		else if (type == Type.GPU) return GPU.getMinCores();
		else {L.assertUni(false); return 1;}
	}
	
	public static Proc create(Type type, int corePercent) {
		int totalCores = Proc.getCores(type);
		int reservedCores = Proc.getReservedCores(type);
		int maxAvailableCores = totalCores - reservedCores;
		int minCores = Proc.getMinCores(type);
		int procCores = (totalCores * corePercent + 50) / 100;
		
		if (procCores > maxAvailableCores) procCores = totalCores - reservedCores;
		if (procCores < minCores) procCores = minCores;
		
		switch (type) {
		case CPU: return new CPU(procCores);
		case GPU: return new GPU(procCores);
		default: L.assertUni(Msg.Impossible); return new CPU(procCores);
		}
	}

	
	public abstract Nd mul(Nd d1, float f);
	public abstract Nd toI8(Nd d1);

	public abstract byte getMaxI8(Nd data);
	public abstract byte getMinI8(Nd data);
	public abstract short getMaxI16(Nd data);
	public abstract short getMinI16(Nd data);
	public abstract float getMaxF32(Nd data);
	public abstract float getMinF32(Nd data);
	
	public abstract void normalize(Nd data, float min, float max);
	
	public abstract Nd mul(Nd d1, Nd d2);
	public abstract Nd dot(Nd d1, Nd d2);

	public abstract Nd flooding(Nd d1, float wave);

	
}




