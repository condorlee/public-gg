package ai.ard.aid;

import ai.ard.aid.L.Msg;
import ai.ard.dat.Nd;

public class GPU extends Proc {
	static int getCores() {return 1920;}
	static int getReservedCores() {return 1920 / 10;}
	static int getMinCores() {return 1920 / 10;}
	
	public GPU(int cores) {}
	
	public Nd mul(Nd d1, float f) {L.assertUni(Msg.Feature_need_support); return d1;}
	public Nd toI8(Nd d1) {L.assertUni(Msg.Feature_need_support); return d1;}
	
	public byte getMaxI8(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public byte getMinI8(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}	
	public short getMaxI16(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public short getMinI16(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public float getMaxF32(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}
	public float getMinF32(Nd data) {L.assertUni(Msg.Feature_need_support); return 0;}

	public void normalize(Nd data, float min, float max) {
		L.assertUni(Msg.Feature_need_support);
	}
	
	public Nd mul(Nd d1, Nd d2) {L.assertUni(Msg.Feature_need_support); return d1;}
	public Nd dot(Nd d1, Nd d2) {L.assertUni(Msg.Feature_need_support); return d1;}
	
	public Nd flooding(Nd d1, float wave) {L.assertUni(Msg.Feature_need_support); return d1;}


}


