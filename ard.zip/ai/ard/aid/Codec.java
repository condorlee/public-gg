package ai.ard.aid;

import ai.ard.dat.YuvBmp;

public class Codec {

	public static YuvBmp decJpg(byte[] jpg) {return decJpg(jpg, 0, jpg.length);}
	public static YuvBmp decJpg(byte[] jpg, int ofs, int size) {
		int[] wh = new int[2];
		byte[] buf = null;//_decJpg(jpg, ofs, size, wh);
		return YuvBmp.create(buf, wh[0], wh[1]);
	}
	
	public static native int nDecJpg(byte[] buf, int ofs, int size, int[] wh); 
	
}
