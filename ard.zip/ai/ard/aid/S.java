package ai.ard.aid;

import java.nio.file.Paths;

import ai.ard.aid.L.Msg;

/* 
 * System
 */
public class S {
	public static long getMs() {return System.currentTimeMillis();}
	public static String getCurrentDir() {
		if (currentDir == null) currentDir = Paths.get(".").toAbsolutePath().normalize().toString();
		return currentDir;
	}
	public static void sleep(long ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			L.exception5Uni(Msg.Logic_need_review.name(), e);
		}
	}
	public static void loadLib(String name) {System.loadLibrary(name);}
	
	private static String currentDir = null;
}
