package ai.ard;

import ai.ard.obj.Obj;

/*
 * The (real) world. It contains:
 * 		WMap	- world map (of earth surface)
 * 		WSpot	- the near place where Ardai is at
 *		Body	- the body of Ardai
 *  WVirt is the sub class for virtual worlds
 */
public class W {

	public int getTik() {return 0;}
	
	public void update(Obj[] objs) {}
	
	public WMap map;
	public WSpot spot;
	public Body body;
	
	
	public final static int TPS = 30;
}
