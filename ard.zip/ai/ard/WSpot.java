package ai.ard;

public class WSpot {
	Body body;
}
