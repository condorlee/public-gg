package ai.ard;

/*
 * Map 
 */
public class M {

	public static M wakeup(B brain) {return new M(brain);}
	
	private M(B brain) {init(brain);}
	private void init(B _brain) {
		brain = _brain;
		initMru();
	}
	
	/* Regardless of MRU or not, Mem should provide unified API for caller to access memory data */
	private void initMru() {
		initLaw();
		initHistory();
		initWorld();
	}
	private void initLaw() {
	}	
	private void initHistory() {
	}
	private void initWorld() {
	}
	
	MHist history;
	MLaw law;
	W world;
	B brain;
}
