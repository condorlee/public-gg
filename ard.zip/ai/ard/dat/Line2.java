package ai.ard.dat;

/* 
 * A straight or curve line in 2D plane
 * Curve line has a valid middle point to control the curve. Straight line ignores middle point.
 */
public class Line2 {
	public Line2(int x0, int y0, int x1, int y1, int x2, int y2) {init(x0, y0, x1, y1, x2, y2);}
	public Line2(byte[] co2s) {init(co2s[0], co2s[1], co2s[2], co2s[3], co2s[4], co2s[5]);}
	public void init(int x0, int y0, int x1, int y1, int x2, int y2) {
		this.x0 = x0; this.y0 = y0;
		this.x1 = x1; this.y1 = y1;
		this.x2 = x2; this.y2 = y2;
	}

	public boolean isCurve() {return x1 >= D.MIN_X;}
	public boolean isStraight() {return x1 < D.MIN_X;}
	
	public int x0, y0, x1, y1, x2, y2;
	
	public final static int X = 0;
	public final static int Y = 1;
	public final static int S = 0;
	public final static int M = 1;
	public final static int E = 2;
	public final static int BYTES = Co2.BYTES * 3;
}
