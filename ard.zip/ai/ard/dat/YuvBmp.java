package ai.ard.dat;

import ai.ard.aid.L;

public class YuvBmp {

	public static YuvBmp create(int w, int h) {return new YuvBmp(null, w, h);} 
	public static YuvBmp create(byte[] buf, int w, int h) {return new YuvBmp(buf, w, h);}
	
	private YuvBmp(byte[] buf, int w, int h) {
		width = w;
		height = h;
		nd = Nd.newNd(buf, Nd.I8, w, h, Yuv.BYTES);
		bytes = nd.totalSize();
		L.au(buf == null || buf.length == bytes);
	}
	
	public Yuv getPixelYuv(int x, int y) {return new Yuv(getPixelBytes(x, y));}
	public byte getPixelY(int y, int x) {return nd.getI8(x + Yuv.Y, y);}
	public byte getPixelU(int y, int x) {return nd.getI8(x + Yuv.U, y);}
	public byte getPixelV(int y, int x) {return nd.getI8(x + Yuv.V, y);}
	public byte[] getPixelBytes(int x, int y) {return nd.getI8s(x + Yuv.V, y, Yuv.BYTES);}
	public int getOfs(int x, int y) {return nd.ofs(x, y);}
	public byte[] getBmpBytes() {return nd.getI8Buf();}
	
	Nd nd;
	public int width, height;
	public int bytes;
}
