package ai.ard.dat;

/*
 * Outline of an visual element in 2D plane
 */
public class Outline2 {

	public Outline2(Line2[] _lines) {
		nd = Nd.newNd(Nd.I8, OUTLINE_LINE_BYTES, _lines.length);
		lines = _lines.length;
	}
	
	public Line2 getLine(int line) {
		int ofs = line * OUTLINE_LINE_BYTES;
		/* Line's end point shared with next line's start point. Last line is wrapped to [0] */
		if (line < lines - 1) return new Line2(nd.getI8s(ofs, Line2.BYTES));
		else {
			byte[] bytes = nd.getI8s(ofs, Line2.BYTES - Co2.BYTES);
			byte[] lastBytes = nd.getI8s(0, Co2.BYTES);
			return new Line2(bytes[0], bytes[1], bytes[2], bytes[3], lastBytes[0], lastBytes[1]);
		}
	}
	
	public int lines;
	Nd nd;

	/* Adjacent lines in outline shares 1 point */
	public final static int OUTLINE_LINE_BYTES = Line2.BYTES - Co2.BYTES;
}
