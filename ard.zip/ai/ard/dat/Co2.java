package ai.ard.dat;

/*
 * Small data structure like Yuv, Co2, Co3, Line2, Line 3, directly define Java fields as individual
 * object for simplicity.
 * When used in big data, such as in YuvBmp, Outline, the buf byte[] can be visited as ofs + X, Y, Z 
 */
public class Co2 {
	public Co2() {x = y = 0;}
	public Co2(byte x, byte y) {init(x, y);}
	public Co2(byte[] xy) {init(xy);}
	
	public byte x, y;
	public void init(byte x, byte y) {this.x = x; this.y = y;}
	public void init(byte[] xy) {init(xy[0], xy[1]);}
	
	public final static int X = 0;
	public final static int Y = 1;
	public final static int BYTES = 2;
}





