package ai.ard.dat;

public class Rect2 {
	public Rect2(int x0, int y0, int x1, int y1) {init(x0, y0, x1, y1);}
	public Rect2(byte[] co2s) {init(co2s[0], co2s[1], co2s[2], co2s[3]);}
	public void init(int x0, int y0, int x1, int y1) {
		this.x0 = x0; this.y0 = y0;
		this.x1 = x1; this.y1 = y1;
	}

	public int x0, y0, x1, y1;
	
	public final static int LF = 0;
	public final static int TOP = 1;
	public final static int RT = 0;
	public final static int BT = 1;
	public final static int BYTES = 4;
}
