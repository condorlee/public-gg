package ai.ard.dat;

import ai.ard.Ard;
import ai.ard.aid.L;
import ai.ard.aid.Proc;
import ai.ard.aid.L.Msg;

/* 
 * N dimension array = Tensor 
 */
public class Nd {
	/* In Java there is no F16. But during processing F16 is used by default. */
	public static enum Type {I8, I16, I32, F32};
	
	public final static Type I8 = Type.I8;
	public final static Type I16 = Type.I16;
	public final static Type I32 = Type.I32;
	public final static Type F32 = Type.F32;
	public final static Type DEFAULT_TYPE = I8;
	
	public final static Proc.Type DEFAULT_PROC_TYPE = Proc.Type.CPU;	
	public final static int DEFAULT_PROC_CORE_USAGE_PERCENTAGE = 80;
	
	public final static int PROC_CORE_RESERVE_1 = 101;
	public final static int PROC_CORE_RESERVE_2 = 102;
	public final static int PROC_CORE_RESERVE_3 = 103;
	public final static int PROC_CORE_RESERVE_4 = 104;
	
	public final static float NORM_MIN = 0;
	public final static float NORM_MAX = 1;
	
	public static void staticInit() {
		staticInit(Nd.DEFAULT_PROC_TYPE, Nd.DEFAULT_PROC_CORE_USAGE_PERCENTAGE);
	}
	public static void staticInit(Proc.Type procType, int coreUsagePercent) {
		Nd.proc = Proc.create(procType, coreUsagePercent);
	}
	private static Proc proc;

	public static Nd newNd(int...sizes) {return new Nd(sizes);}
	public static Nd newNd(Type type, int...sizes) {return new Nd(type, sizes);}
	public static Nd newNd(Object buf, Type type, int...sizes) {return new Nd(buf, type, sizes);}
	public static Nd new1d(int x) {return new Nd(x);}
	public static Nd new1d(Type type, int x) {return new Nd(type, x);}
	public static Nd new2d(Type type, int x, int y) {return new Nd(type, y, x);}
	public static Nd new3d(Type type, int x, int y, int z) {return new Nd(type, y, x, z);}
	
	private Nd(int...sizes) {init(null, DEFAULT_TYPE, sizes);}
	private Nd(Type type, int...sizes) {init(null, type, sizes);}
	private Nd(Object buf, Type type, int...sizes) {init(buf, type, sizes);}
	public Nd clone() {
		Nd t = new Nd(type, sizes);
		t.copyFrom(this);
		return t;
	}
	public void copyFrom(Nd from) {
		L.au(this.type == from.type);
		Object data = from._nd;
		int length0, length1;
		
		if (Ard.DEV) {
			switch (this.type) {
			case I8: length1 = ((byte[])data).length; length0 = ((byte[])this._nd).length; break;
			case I16: length1 = ((short[])data).length; length0 = ((byte[])this._nd).length; break;
			case I32: length1 = ((int[])data).length; length0 = ((byte[])this._nd).length; break;
			case F32: length1 = ((float[])data).length; length0 = ((byte[])this._nd).length; break;
			default: L.assertUni(Msg.Impossible); length0 = length1 = 0; break;
			}
			L.au(length0 == length1);
		}
		System.arraycopy(this._nd, 0, data, 0, length0);
	}
	
	private void init(Object buf, Type _type, int..._sizes) {
		if (buf != null) _nd = buf;
		type = _type;
		sizes = _sizes;
		totalSize = 1;
		for (int size : _sizes) totalSize *= size;
		switch (_type) {
		case I8: if (buf == null) _nd = new byte[totalSize]; L.au(buf instanceof byte[]); break;
		case I16: if (buf == null) _nd = new short[totalSize]; L.au(buf instanceof short[]); break;
		case I32: if (buf == null) _nd = new int[totalSize]; L.au(buf instanceof int[]); break;
		case F32: if (buf == null) _nd = new float[totalSize]; L.au(buf instanceof float[]); break;
		}
	}
	
	Type type;
	int[] sizes;
	Object _nd;
	private int totalSize;
	
	public Type type() {return type;}
	public int dims() {return sizes.length;}
	public int size0() {return sizes[0];}
	public int size1() {return sizes[1];}
	public int size2() {return sizes[2];}
	public int size(int dim) {return sizes[dim];}
	public int[] sizes() {return sizes;}
	public int totalSize() {return totalSize;}
	
	public byte[] getI8Buf() {return (byte[])this._nd;}
	public short[] getI16Buf() {return (short[])this._nd;}
	public int[] getI32Buf() {return (int[])this._nd;}
	public float[] getF32Buf() {return (float[])this._nd;}
	
	public byte getI8(int x) {return getI8Buf()[x];}
	public byte getI8(int x, int y) {return getI8Buf()[ofs(x, y)];}
	public byte getI8(int x, int y, int z) {return getI8Buf()[ofs(x, y, z)];}
	public byte[] getI8s(int x, int size) {
		byte[] buf = new byte[size];
		System.arraycopy(getI8Buf(), x, buf, 0, size);
		return buf;
	}
	public byte[] getI8s(int x, int y, int size) {
		byte[] buf = new byte[size];
		System.arraycopy(getI8Buf(), ofs(x, y), buf, 0, size);
		return buf;
	}
	
	public short getI16(int x) {return getI16Buf()[x];}
	public short getI16(int x, int y) {return getI16Buf()[ofs(x, y)];}
	public short getI16(int x, int y, int z) {return getI16Buf()[ofs(x, y, z)];}
	public short[] getI16s(int x, int size) {
		short[] buf = new short[size];
		System.arraycopy(getI16Buf(), x, buf, 0, size);
		return buf;
	}
	public short[] getI16s(int x, int y, int size) {
		short[] buf = new short[size];
		System.arraycopy(getI16Buf(), ofs(x, y), buf, 0, size);
		return buf;
	}
	
	public int ofs(int x, int y) {return y * sizes[0] + x;}
	public int ofs(int x, int y, int z) {return z * sizes[0] + y * sizes[1] + x;}
	
	public int getI32(int y, int x) {return getI32Buf()[ofs(y, x)];}
	public float getF32(int y, int x) {return getF32Buf()[ofs(y, x)];}
	
	public void setI8(int x, byte v) {
		L.au(dims() == 1);
		getI8Buf()[x] = v;
	}
	public void setI8(int x, int y, byte v) {
		L.au(dims() == 2);
		getI8Buf()[ofs(x, y)] = v;
	}
	public void setI8s(int ofs, byte[] values) {
		System.arraycopy(values, 0, getI8Buf(), ofs, values.length);
	}

	public Nd mul(float f) {return Nd.proc.mul(this, f);}
	public Nd toI8() {return Nd.proc.toI8(this);}
	
	public float getMaxF32() {return Nd.proc.getMaxF32(this);}
	public float getMinF32() {return Nd.proc.getMinF32(this);}
	public float getMaxI16() {return Nd.proc.getMaxI16(this);}
	public float getMinI16() {return Nd.proc.getMinI16(this);}
	
	public void normalizeF() {Nd.proc.normalize(this, Nd.NORM_MIN, Nd.NORM_MAX);}
	public void normalizeF(float min, float max) {Nd.proc.normalize(this, min, max);}

}




