package ai.ard.dat;


public class Co3 {
	public Co3() {x = y = z = 0;}
	public Co3(byte x, byte y, byte z) {init(x, y, z);}
	public Co3(byte[] xyz) {init(xyz);}
	
	public byte x, y, z;
	public void init(byte x, byte y, byte z) {this.x = x; this.y = y; this.z = z;}
	public void init(byte[] xyz) {init(xyz[0], xyz[1], xyz[2]);}
	
	public final static int X = 0;
	public final static int Y = 1;
	public final static int Z = 2;
	public final static int BYTES = 3;
}





