package ai.ard.dat;


/*
 * Basic data types
 */
public class D {
	public final static int MIN_X = 0; 
	public final static int MIN_Y = 0;
	
	public final static int INVALID = -2;			// Invalid count / offset / boolean / etc. data
	
	/* To provide direct access to Nd internal buffer, instead of copying / recreate */
	public static class i8Ptr {byte[] buf; int p;}
	public static class i16Ptr {short[] buf; int p;}
	public static class i32Ptr {int[] buf; int p;}
	public static class f32Ptr {float[] buf; int p;}

	/* Fast HashSet for short */
	public static class SHashSet {
		
	}
}








