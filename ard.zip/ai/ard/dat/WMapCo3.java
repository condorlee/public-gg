package ai.ard.dat;


public class WMapCo3 extends Co3 {
	public WMapCo3() {super();}
	public WMapCo3(byte x, byte y, byte z) {super(x, y, z);}
	public WMapCo3(byte[] xyz) {super(xyz);}
	
}





