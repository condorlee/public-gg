package ai.ard.dat;

public class Yuv {
	public Yuv() {y = u = v = 0;}
	public Yuv(byte y, byte u, byte v) {init(y, u, v);}
	public Yuv(byte[] yuv) {init(yuv);}
	
	public byte y, u, v;
	public byte l() {return y;}
	public byte b() {return u;}
	public byte r() {return v;}
	public void init(byte y, byte u, byte v) {this.y = y; this.u = u; this.v = v;}
	public void init(byte[] yuv) {init(yuv[0], yuv[1], yuv[2]);}
	
	public final static int Y = 0;
	public final static int U = 1;
	public final static int V = 2;
	public final static int L = 0;
	public final static int B = 1;
	public final static int R = 2;
	public final static int BYTES = 3;
}





