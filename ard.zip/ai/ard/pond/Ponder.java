package ai.ard.pond;

/*
 * Make decision in about 5s
 * For complex problems, such as: how to go to Walgreens, how to fold all clothes into the case
 */
public class Ponder {

}
