package ai.ard.pond;

/*
 * Make decision in about .5s
 * For in spot task, such as: someone is calling, to turn in road cross
 */
public class Think {

}
