package ai.ard.pond;

/*
 * Make decision in about .1s
 * For urgent challenge, such as: shoes flying over, grabbing cup from table
 * It may rob processor core from lower priority tasks
 */
public class React {

}
