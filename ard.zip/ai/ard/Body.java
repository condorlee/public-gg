package ai.ard;


import java.util.ArrayList;

import ai.ard.aid.L;
import ai.ard.aid.L.Msg;
import ai.ard.perc.*;
import ai.ard.perf.*;

public class Body {
	
	public static Body wakeup(B brain) {return new Body(brain);}
	
	public Body(B brain) {init(brain);}
	private void init(B brain) {
		Sensor[] sensors = detectSensors(brain);
		Actor[] actors = detectActors(brain);
		initIOer(sensors, actors);		
	}
	
	private Sensor[] detectSensors(B brain) {
		ArrayList<Sensor> sensors = new ArrayList<Sensor>();
		sensors.add(Cam.create(brain));
		return (Sensor[])sensors.toArray();
	}
	private Actor[] detectActors(B brain) {return null;}
	private void initIOer(Sensor[] _sensors, Actor[] _actors) {
		for (Sensor sensor : _sensors) {
			switch (sensor.getClass().getSimpleName()) {
			case "Accel": accel = sensor.tAccel(); break;
			case "Baro": baro = sensor.tBaro(); break;
			case "Cam": cam = sensor.tCam(); break;
			case "GPS": gps = sensor.tGPS(); break;
			case "Gyro": gyro = sensor.tGyro(); break;
			case "Presso": presso = sensor.tPresso(); break;
			case "Mic": mic = sensor.tMic(); break;
			case "Inno": inno = sensor.tInno(); break;
			case "Thermo": thermo = sensor.tThermo(); break;
			}
		}
		sensors = new Sensor[] {accel, baro, cam, gps, gyro, presso, mic, inno, thermo};
		for (int i = 0; i < sensors.length; i ++)
			if (sensors[i] == null)
				L.uiMsg(Msg.Sensor_not_detected + "" + sensorNames[i], sensorImportance[i]);
		
		for (Actor actor : _actors) {
			switch (actor.getClass().getSimpleName()) {
			case "Walker": walker = actor.tWalker(); break;
			case "Operator": operator = actor.tOperator(); break;
			case "Speaker": speaker = actor.tSpeaker(); break;
			}
		}
		actors = new Actor[] {walker, operator, speaker};
		for (int i = 0; i < actors.length; i ++)
			if (actors[i] == null)
				L.uiMsg(Msg.Actor_not_detected + "" + actorNames[i], actorImportance[i]);		
	}
	
	long tik;
	boolean awake;

	Accel accel;		// Important
	Baro baro;			// May
	Cam cam;			// Must
	Gyro gyro;			// Important
	GPS gps;			// May
	Presso presso;		// Nice
	Mic mic;			// Must
	Inno inno;			// Important
	Thermo thermo;		// Nice
	Sensor[] sensors;
	
	final static String[] sensorNames = new String[] {"Accel", "Baro", "Cam", "Gyro", "GPS",
			"Presso", "Mic", "Inno", "Thermo"};
	final static int[] sensorImportance = new int[] {L.WARN, L.INFO, L.ERROR, L.WARN, L.INFO,
			L.HINT, L.ERROR, L.WARN, L.HINT};
	
	Operator operator;
	Speaker speaker;
	Walker walker;
	Actor[] actors;
	static String[] actorNames = new String[] {"Operator", "Speaker", "Walker"};
	static int[] actorImportance = new int[] {L.HINT, L.ERROR, L.WARN};
	
}









