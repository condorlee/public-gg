package ai.ard.perf;

import ai.ard.W;

public class Speaker extends Actor {

	public void perceive(W world) {
		
	}

	public static Speaker create() {
		return new Speaker();
	}
}

