package ai.ard.perf;


public class Actor {

	public Walker tWalker() {return (Walker)this;}
	public Operator tOperator() {return (Operator)this;}
	public Speaker tSpeaker() {return (Speaker)this;}

}
