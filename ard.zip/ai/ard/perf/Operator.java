package ai.ard.perf;

import ai.ard.W;

public class Operator extends Actor {

	public void perceive(W world) {
		
	}

	public static Operator create() {
		return new Operator();
	}
}




