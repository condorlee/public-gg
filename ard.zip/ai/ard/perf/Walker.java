package ai.ard.perf;

import ai.ard.W;

public class Walker extends Actor {

	public void perceive(W world) {
		
	}

	public static Walker create() {
		return new Walker();
	}
}

