package ai.ard;

import ai.ard.BEgo.Goal;
import ai.ard.obj.Obj;
import ai.ard.perc.Cam;
import ai.ard.perc.ve.Feature;
import ai.ard.perc.ve.Stroke;

/*
 * Provide perceive and perform capability with intuitive level intelligence (L4)
 */
public class BBel {

	public static BBel wakeup(B brain) {return new BBel(brain);}

	
	public void perceive() {
		look();			// cam
		listen();		// mic
		locate();		// gps, gyro
		feel();			// self, mano, baro, thermo
	}
	public void perform(Goal[] goals) {}

	
	private boolean look() {
		Cam cam = body.cam;
		boolean visible = cam.startFrame(brain);
		if (visible) {
			Stroke[] strokes = cam.getStrokes();
			Feature[] features;
			Obj[] objs;
			int match1k, nFeature;
			
			/* @work Retry need change stroke combination & match parameter */
			do {
				features = cam.tryComposeFeatures(strokes);
				nFeature = features.length;
				objs = new Obj[nFeature];
				match1k = 0;
			
				for (int i = 0; i < nFeature; i ++)
					match1k += features[i].perceive1k(brain.mem, objs, i);
			} 
			while (match1k < nFeature * MATCH1K_OK);
			
			/* Add, remove, update objects in the world */
			brain.world.update(objs);			
		}
		cam.endFrame();
		return visible;
	}
	private void listen() {}
	private void locate() {}
	private void feel() {}
	
	
	
	private BBel(B brain) {init(brain);}
	private void init(B _brain) {
		brain = _brain;
		body = Body.wakeup(brain);
	}

		
	private B brain;
	public Body body;	
	
	public static final int SEE_MOTION = 10;
	public static final int MATCH1K_OK = 800;
}












