package ai.ard;

import ai.ard.dat.*;
import ai.ard.obj.*;



public class BEgo {
	public static BEgo wakeup(B brain) {return new BEgo(brain);}

	/* All not closed goals are open goals, not just "Open" goals */
	public Goal[] getOpenGoals() {return null;} 
	
	
	/* Goal is a data class. Goal related logic is handled in Cerebra */
	public static class Goal {
		public void start() {status = Status.Doing;}
		public void split(Goal[] _subs) {status = Status.Split; subs = _subs;}
		public void done() {status = Status.Done;}
		
		/* Split - Only "Action" goals can be directly translated to actions for Actor. Other level
		 * 			of goals need be analyzed, split into sub goals.
		 * Eased - For libido and other long term goals. It means the goal temporarily eased.
		 * 			For example libido "Keep battery capacity" can never be set to Done or Close.
		 * 			Instead, it always switching between the two status: "Eased", "Split"
		 * Done  - finished as planned (actions), such as find charger, plug, wait for 30 minutes
		 * 		vs
		 * Close - verified as success (status), such as check battery >= 90%. */
		public static enum Status {Open,  Split, Doing,  Eased, Pause, Defer,  Done, Close;}
		public static enum Level {
			Libido,		// Basic need - Ensure self safety
			Strategy,	// What - Drive the wild dog out of the house
			Tactic,		// How - Go around to back side / get a stick / approach slowly / beat it 
			Action;		// Exact steps - Raise the stick high / swing down towards the dog
		}
		public static enum Urgency {
			Instant,	// <=.1s - duck to avoid shoes, 
			Now,		// <=.5s - turn right
			Ontime,		// <= 5s - give me the cup
			Awhile,		// <=60s - charge battery, go to restroom
			Sometime;	// > 60s - buy a car, get a college degree
		}
		public static enum Importance {
			Fatal,		// battery 0%, SSD error, car hitting
			Critical,	// battery 5%, no camera
			Important,	// battery 20%, no speaker
			Useful,		// battery 30%, no gyro
			Favor;		// battery 60%, no baro
		}
		
		Status status;
		Level level;
		Urgency urgency;
		Importance importance;
		
		Obj obj;
		Goal[] subs;
		
		public static class ChangeProp extends Goal {
			Prop prop;
			Elem value;
		}
		public static class ChangePose extends Goal {
			Prop prop;
			Elem value;
		}
		public static class ChangeRelation extends Goal {
			Obj target;
			Relation relation;
		}
		public static class Move extends Goal {}
		public static class MoveAbs extends Move {
			WMapCo3 wmapCo3;
		}
		public static class MoveRelation extends Move {
			Obj against;
			Relation relation;
		}
		
	}
	
	
	public final static Goal[] LIBIDO = new Goal[] {
		new Goal(),
		new Goal()
	};
	
	
	private BEgo(B brain) {init(brain);}
	private void init(B _brain) {
		brain = _brain;
	}

	B brain;

}










