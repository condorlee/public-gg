package ai.ard.perc;

import java.io.File;
import java.io.FileInputStream;

import ai.ard.B;
import ai.ard.aid.Codec;
import ai.ard.aid.L;
import ai.ard.aid.Proc;
import ai.ard.aid.S;
import ai.ard.dat.Nd;
import ai.ard.dat.YuvBmp;
import ai.ard.perc.ve.*;

/*
 * Provide vision with (L1~L3) non intelligent, geometric picture process capability
 */
public class Cam extends Sensor {
	
	public boolean startFrame(B brain) {
		frameId = getFrameId();
		rawBmp = getBmp();
		bmp = normalizeBmp(lastRawBmp);
		motBmp = detectMot(bmp, lastBmp, lastMotBmp);
		return frameVisible();
	}
	/* @improve Create a thread to read 30fps mjpeg from camera, decode, keep 5fps or  */
	public boolean frameVisible() {return frameId > lastFrame || motVisible(motBmp);}
	public void endFrame() {
		lastRawBmp = rawBmp;
		lastBmp = bmp;
		lastMotBmp = motBmp;
		lastFrame = frameId;
	}

	private long getFrameId() {return brain.getTik() / B.TPF;}
	
	/* @hot Capture a frame from camera hardware */
	private YuvBmp getBmp() {
		int id = fishEye.getFrameHead();
		return id < 0 ? null : Codec.decJpg(jpgs, jpgOfs[id], jpgSize[id]);
	}
	
	/* @work Reduce frame color */
	private YuvBmp normalizeBmp(YuvBmp yuv) {return yuv;}

	/* None = 0, Invisible = 1, Tiny <= 3, Small <= 10, Medium <= 30, Big <= 100, Pov = 101
	 * > 100 means Pov change + motion detected in old view field */
	private boolean motVisible(YuvBmp mot) {return getMot1k(mot) >= MOT_VISIBLE100;}
	private int getMot1k(YuvBmp mot) {return 1000;}
	private YuvBmp detectMot(YuvBmp yuv, YuvBmp last, YuvBmp lastCared) {return yuv;}
	
	public final static int MOT_NONE = 0;
	public final static int MOT_INVISIBLE = 1;
	public final static int MOT_TINY = 3;
	public final static int MOT_SMALL = 10;
	public final static int MOT_MEDIUM = 30;
	public final static int MOT_BIG = 100;
	public final static int MOT_POV = 101;
	public final static int MOT_VISIBLE100 = MOT_SMALL + 1;
		
	
	public Stroke[] getStrokes() {
		Stroke[] strokes = fillStrokes(bmp);
		for (Stroke stroke : strokes) stroke.vectorize();
		return strokes;
	}
	/* @work */
	public Feature[] tryComposeFeatures(Stroke[] strokes) {
		int nStrokes = strokes.length;
		for (int i = 0; i < nStrokes; i ++) {
			getTouchStrokes(strokes, i);
		}
		return null;
	}
	private Stroke[] getTouchStrokes(Stroke[] strokes, int i) {
		return null;
	}
	
	/* @work */
	private Stroke[] fillStrokes(YuvBmp bmp) {return null;}
	
	
	
	public static Cam create(B brain) {return new Cam(brain);}
	public Cam(B _brain) {
		brain = _brain;
		proc = brain.createCamProc();
		
		pixelMap = Nd.new2d(Nd.I16, CAM_X_PIXEL, CAM_Y_PIXEL);
		tileMap = Nd.new2d(Nd.I16, CAM_X_GRIDS, CAM_Y_GRIDS);
		
		/* 120MB cache of mjpg in _Cam, 10s*30fps*400k */
		jpgs = new byte[JPG_AVG_SIZE * _CAM_CACHE_FRAMES];
		jpgMs = new long[_CAM_CACHE_FRAMES];
		jpgOfs = new int[_CAM_CACHE_FRAMES];
		jpgSize = new int[_CAM_CACHE_FRAMES];
		fishEye = _Cam.create(0);
		fishEye.setVideoParam(CAM_X_PIXEL, CAM_Y_PIXEL, CAM_FPS);
		fishEye.startVideo(jpgs, jpgMs, jpgOfs, jpgSize);
	}
	
	private YuvBmp lastRawBmp, lastBmp, lastMotBmp, rawBmp, bmp, motBmp;
	private long lastFrame, frameId;
	
	/* fishEye 170d // dual 65d*2, long 13d, close, tele 2.5d, dark, motion, night, 360 170d*3 */
	private _Cam fishEye;
	private byte[] jpgs;
	private long[] jpgMs;
	private int[] jpgOfs, jpgSize;
	
	public Nd pixelMap;
	public Nd tileMap;

	public B brain;
	public Proc proc;
	
	public static final int CAM_X_PIXEL = 1920;
	public static final int CAM_Y_PIXEL = 1080;
	public static final int CAM_FPS = B.TPS;					// 1 frame / tick is the ideal case

	static final int GRID_W = 20;
	static final int GRID_H = 20;
	static final int CAM_X_GRIDS = CAM_X_PIXEL / GRID_W;
	static final int CAM_Y_GRIDS = CAM_Y_PIXEL / GRID_H;
	static final int CAM_GRIDS = CAM_X_GRIDS * CAM_Y_GRIDS;		// 5184 grids for logical mapping 
	
	static final int CUDA_GRID_W = 20;
	static final int CUDA_GRID_H = 27;
	static final int CUDA_X_GRIDS = CAM_X_PIXEL / CUDA_GRID_W;
	static final int CUDA_Y_GRIDS = CAM_Y_PIXEL / CUDA_GRID_H;
	static final int CUDA_GRIDS = CUDA_X_GRIDS * CUDA_Y_GRIDS;	// 3840 grids = nvidia 3060m cores 

	private final static int _CAM_CACHE_SECONDS = 10;
	private final static int _CAM_CACHE_FRAMES = CAM_FPS * _CAM_CACHE_SECONDS;
	private final static int JPG_AVG_SIZE = 400*1024;
	
	
	
	private static class _Cam {		
		public static _Cam create(int id) {return new _Cam(id);}
			
		public int setVideoParam(int _w, int _h, int _fps) {w = _w; h = _h; fps = _fps; return 1;}
		/* Interface:
		 * 		jpgMs[i] is a mutex between caller/callee. > 0 means the frame jpgs[i] is ready. 
		 * Callee:
		 * 		startVideo() launches a rt priority thread to keep recording video frames from WebCam
		 * 		device, store to jpgs[i], rotationally.
		 * 		Even if next frame jpgMs[i] > 0 (means it is not consumed yet), it is still overwritten.
		 * Caller (class Cam):
		 *		Should allocate jpgs = byte[120M], jpgMs|Ofs|Size[300], for 10s video buffer.
		 */
		public int startVideo(byte[] _jpgs, long[] _jpgMs, int[] _jpgOfs, int[] _jpgSize) {
			jpgs = _jpgs; jpgMs = _jpgMs; jpgOfs = _jpgOfs; jpgSize = _jpgSize;
			maxFrame = _jpgs.length;
			frameHead = -1;
			frameTail = 0;
			return 1;
		}
		public int endVideo() {return 1;}
		
		public int getFrameHead() {
			int r;
			if ((r = stubFrame()) >= 0) return r;;
			return jpgMs[frameHead] > 0 ? frameHead : -1;
		}
		private String[] stubFrames = new String[] {"korean_teddy.jpg", "remington_mary.jpg"};
		private int stubFrame() {
			String base = S.getCurrentDir(), name = stubFrames[0];
			String fullPath = base + File.separatorChar + name;
			try {
				FileInputStream fis = new FileInputStream(new File(fullPath));
				int size = fis.read(jpgs);
				fis.close();
				jpgMs[0] = S.getMs();
				jpgOfs[0] = 0;
				jpgSize[0] = size;
			} catch (Exception e) {
				e.printStackTrace();
				return -1;
			}
			return 0;
		}
		public int getFrameTail() {return jpgMs[frameTail] > 0 ? frameTail : -1;}
		public void releaseFrameTail() {
			L.au(jpgMs[frameTail] > 0);
			jpgMs[frameTail] = 0;
			frameTail = (frameTail + 1) % maxFrame; 
		}
		
		private _Cam(int _id) {id = _id;}
		private int id, w, h, fps;
		private byte[] jpgs;
		private long[] jpgMs; 
		private int[] jpgOfs, jpgSize;	
		private int maxFrame, frameHead, frameTail;
		
		private native int _startVideo();
		private native int _getPic();
	}

	
}







