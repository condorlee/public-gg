package ai.ard.perc;


public class Accel extends Sensor {
	
	public void perceive() {
		
	}

	public static Accel create() {
		return new Accel();
	}
}




