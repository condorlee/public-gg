package ai.ard.perc;


public class Baro extends Sensor {
	
	public void perceive() {
		
	}

	public static Baro create() {
		return new Baro();
	}
}




