package ai.ard.perc;

/*
 * Inner sensor of Ardai, such as battery percent, arm position, body direction, etc. 
 */
public class Inno extends Sensor {
	
	public static Inno create() {
		return new Inno();
	}
	
	
	public int getBatteryPercent() {return battery;}
	private int battery;
}




