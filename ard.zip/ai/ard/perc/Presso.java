package ai.ard.perc;


public class Presso extends Sensor {
	
	public void perceive() {
		
	}

	public static Presso create() {
		return new Presso();
	}
}




