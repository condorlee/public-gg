package ai.ard.perc;

import ai.ard.W;

public class GPS extends Sensor {
	
	public void perceive(W world) {
		
	}

	public static GPS create() {
		return new GPS();
	}
}




