package ai.ard.perc;

import ai.ard.W;

public class Thermo extends Sensor {
	
	public void perceive(W world) {
		
	}

	public static Thermo create() {
		return new Thermo();
	}
}




