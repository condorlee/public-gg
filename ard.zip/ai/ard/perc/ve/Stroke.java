package ai.ard.perc.ve;

import ai.ard.dat.*;
import ai.ard.dat.D.SHashSet;

/*
 * Stroke is the minimum element in a view
 * It is a block of pixels of same / similar / gradient colors
 */
public class Stroke extends VE {
	public enum Type {Flat, Gradient;}	
	
	/* Cam.pixelMap has physically accurate range of this element */
	public Outline2 outline2;	// Logically accurate range of this element
	public Co2[] grids;			// The grids (20*20p) this element touches, for L1 test of elements
	public Co2[] gridsPixel;	// A typical pixel of each grid
	public Yuv[] gridsColor;	// Average color of each grid for gradient stroke
	
	
	public Outline2 inline2;	// Optional, for VE that contains holes (other VEs)
	public Co2[] inGrids;
	public Co2[] inGridsPixel;

	public SHashSet edgePixels;	// Record Stroke edge pixels during filling, consumed during outline 
	
	public void vectorize() {trackLines(); filterLines();}
	
	/* @work */
	private void trackLines() {}
	private void filterLines() {}

}












