package ai.ard.perc.ve;

import ai.ard.M;
import ai.ard.obj.Obj;

/*
 *	Feature use below fields to store aggregation result of strokes[i].* 
 *		color, area, range, center, cg
 */
public class Feature extends VE {
	
	public static Feature newFeature(Type type, VE[] ves) {
		Feature feature = new Feature(type, ves);
		return feature;
	}
	
	public static enum Type {
		Touching;
	}
	
	/* @work */
	public int perceive1k(M mem, Obj[] objs, int i) {
		return 1000;
	}
	
	
	private Feature(Type type, VE[] ves) {
	}
	
	/* The strokes and sub features, that compose this feature */
	VE[] ves;

}
