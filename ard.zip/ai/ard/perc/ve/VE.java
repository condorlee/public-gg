package ai.ard.perc.ve;

import ai.ard.dat.Co2;
import ai.ard.dat.Rect2;
import ai.ard.dat.Yuv;

/*
 * Base class of all visual elements 
 */
public class VE {
	public short id;			// unique ID (with in a scope, such as stroke / feature in a frame)
	public Yuv color;			// Mean color of the whole visual element
	public int area;			// Total pixels
	public Rect2 range;			// Outer rectangle, for quick rough test of elements relationship
	public Co2 center;
	public Co2 cg;				// cg => central define UP direction for the visual element

}











