package ai.ard.perc;

import ai.ard.W;

public class Gyro extends Sensor {
	
	public void perceive(W world) {
		
	}

	public static Gyro create() {
		return new Gyro();
	}
}




