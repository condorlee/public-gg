package ai.ard.perc;

import ai.ard.W;

public class Mic extends Sensor {
	
	public void perceive(W world) {
		
	}

	public static Mic create() {
		return new Mic();
	}
}




