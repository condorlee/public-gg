package ai.ard.perc;

public abstract class Sensor {

	public Accel tAccel() {return (Accel)this;}
	public Baro tBaro() {return (Baro)this;}
	public Cam tCam() {return (Cam)this;}
	public GPS tGPS() {return (GPS)this;}
	public Gyro tGyro() {return (Gyro)this;}
	public Presso tPresso() {return (Presso)this;}
	public Mic tMic() {return (Mic)this;}
	public Inno tInno() {return (Inno)this;}
	public Thermo tThermo() {return (Thermo)this;}
	
}
